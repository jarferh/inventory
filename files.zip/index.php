<?php
require_once 'config/config.php';
require_once 'classes/Database.php';
require_once 'classes/Session.php';
require_once 'classes/Auth.php';
require_once 'classes/Inventory.php';
require_once 'classes/Sales.php';

Session::init();

if (!Session::isLoggedIn()) {
    header('Location: login.php');
    exit();
}

$inventory = new Inventory();
$sales = new Sales();

// Get dashboard data
$lowStockProducts = $inventory->getLowStockProducts();
$dailySales = $sales->getDailySales();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - <?= SITE_NAME ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="container">
        <?php include 'includes/header.php'; ?>
        
        <div class="dashboard">
            <div class="dashboard-stats">
                <div class="stat-card">
                    <h3>Today's Sales</h3>
                    <p class="amount">KES <?= number_format($dailySales['total'] ?? 0, 2) ?></p>
                    <p class="count"><?= $dailySales['count'] ?? 0 ?> transactions</p>
                </div>
                
                <div class="stat-card">
                    <h3>Low Stock Alerts</h3>
                    <p class="count"><?= count($lowStockProducts) ?> products</p>
                    <a href="modules/inventory/low-stock.php" class="btn">View Details</a>
                </div>
            </div>
            
            <div class="dashboard-actions">
                <a href="modules/pos/index.php" class="action-btn">
                    <i class="fas fa-cash-register"></i>
                    <span>New Sale</span>
                </a>
                
                <a href="modules/inventory/add.php" class="action-btn">
                    <i class="fas fa-box"></i>
                    <span>Add Product</span>
                </a>
                
                <a href="modules/reports/sales.php" class="action-btn">
                    <i class="fas fa-chart-bar"></i>
                    <span>Sales Report</span>
                </a>
            </div>
            
            <?php if (!empty($lowStockProducts)): ?>
            <div class="low-stock-alert">
                <h3>Low Stock Alert</h3>
                <table>
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>Current Stock</th>
                            <th>Reorder Level</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($lowStockProducts as $product): ?>
                        <tr>
                            <td><?= htmlspecialchars($product['name']) ?></td>
                            <td><?= $product['stock_quantity'] ?></td>
                            <td><?= $product['reorder_level'] ?></td>
                            <td>
                                <a href="modules/inventory/edit.php?id=<?= $product['id'] ?>" 
                                   class="btn btn-small">Update Stock</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
        </div>
        
        <?php include 'includes/footer.php'; ?>
    </div>
    
    <script src="assets/js/script.js"></script>
</body>
</html>