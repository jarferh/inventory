<?php
if (!defined('SITE_NAME')) {
    exit('Direct script access denied.');
}
?>
<header class="header">
    <div class="header-content">
        <div class="logo">
            <h1><?= SITE_NAME ?></h1>
        </div>
        
        <div class="user-info">
            <span>Welcome, <?= htmlspecialchars(Session::get('username')) ?></span>
            <div class="dropdown">
                <button class="btn dropdown-toggle">
                    <i class="fas fa-user"></i>
                </button>
                <div class="dropdown-menu">
                    <a href="profile.php">Profile</a>
                    <a href="logout.php">Logout</a>
                </div>
            </div>
        </div>
    </div>
    
    <nav class="main-nav">
        <ul>
            <li><a href="index.php">Dashboard</a></li>
            <li><a href="modules/pos/index.php">POS</a></li>
            <li><a href="modules/inventory/list.php">Inventory</a></li>
            <li><a href="modules/reports/index.php">Reports</a></li>
            <?php if (Session::get('role') === 'admin'): ?>
            <li><a href="modules/settings/index.php">Settings</a></li>
            <?php endif; ?>
        </ul>
    </nav>
</header>