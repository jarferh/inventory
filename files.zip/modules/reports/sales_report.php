<?php
require_once '../../config/config.php';
require_once '../../classes/Database.php';
require_once '../../classes/Session.php';
require_once '../../classes/Reports.php';

Session::init();

if (!Session::isLoggedIn()) {
    header('Location: ../../login.php');
    exit();
}

$currentDateTime = '2025-02-16 14:51:37';
$currentUser = 'musty131311';

$reports = new Reports();

// Default to last 30 days if no date range specified
$endDate = $currentDateTime;
$startDate = date('Y-m-d', strtotime('-30 days', strtotime($currentDateTime)));

if (isset($_GET['start_date']) && isset($_GET['end_date'])) {
    $startDate = $_GET['start_date'];
    $endDate = $_GET['end_date'];
}

$salesData = $reports->getSalesReport($startDate, $endDate);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sales Report - <?= SITE_NAME ?></title>
    <link rel="stylesheet" href="../../assets/css/style.css">
    <link rel="stylesheet" href="../../assets/css/reports.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="container">
        <?php include '../../includes/header.php'; ?>
        
        <div class="content">
            <div class="content-header">
                <h2>Sales Report</h2>
                <div class="export-buttons">
                    <button onclick="exportToPDF()" class="btn">Export PDF</button>
                    <button onclick="exportToExcel()" class="btn">Export Excel</button>
                </div>
            </div>
            
            <div class="report-filters">
                <form method="GET" class="filters-grid">
                    <div class="form-group">
                        <label for="start_date">Start Date</label>
                        <input type="date" id="start_date" name="start_date" 
                               value="<?= $startDate ?>" class="form-control">
                    </div>
                    
                    <div class="form-group">
                        <label for="end_date">End Date</label>
                        <input type="date" id="end_date" name="end_date" 
                               value="<?= $endDate ?>" class="form-control">
                    </div>
                    
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary">Apply Filter</button>
                    </div>
                </form>
            </div>
            
            <div class="report-summary">
                <?php
                $totalSales = 0;
                $totalTransactions = 0;
                foreach ($salesData as $sale) {
                    $totalSales += $sale['total_amount'];
                    $totalTransactions += $sale['total_transactions'];
                }
                ?>
                <div class="summary-grid">
                    <div class="summary-box">
                        <h4>Total Sales</h4>
                        <p class="amount">KES <?= number_format($totalSales, 2) ?></p>
                    </div>
                    
                    <div class="summary-box">
                        <h4>Total Transactions</h4>
                        <p class="amount"><?= $totalTransactions ?></p>
                    </div>
                    
                    <div class="summary-box">
                        <h4>Average Transaction</h4>
                        <p class="amount">KES <?= $totalTransactions ? number_format($totalSales / $totalTransactions, 2) : '0.00' ?></p>
                    </div>
                </div>
            </div>
            
            <div class="chart-container">
                <canvas id="salesChart"></canvas>
            </div>
            
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Transactions</th>
                            <th>Total Sales</th>
                            <th>Average Sale</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($salesData as $sale): ?>
                        <tr>
                            <td><?= date('Y-m-d', strtotime($sale['sale_date'])) ?></td>
                            <td><?= $sale['total_transactions'] ?></td>
                            <td>KES <?= number_format($sale['total_amount'], 2) ?></td>
                            <td>KES <?= number_format($sale['average_sale'], 2) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <script>
    // Prepare data for chart
    const salesData = {
        labels: <?= json_encode(array_column($salesData, 'sale_date')) ?>,
        datasets: [{
            label: 'Daily Sales',
            data: <?= json_encode(array_column($salesData, 'total_amount')) ?>,
            borderColor: '#3498db',
            backgroundColor: 'rgba(52, 152, 219, 0.1)',
            fill: true
        }]
    };

    // Create sales chart
    const ctx = document.getElementById('salesChart').getContext('2d');
    new Chart(ctx, {
        type: 'line',
        data: salesData,
        options: {
            responsive: true,
            plugins: {
                title: {
                    display: true,
                    text: 'Daily Sales Trend'
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return 'KES ' + value.toLocaleString();
                        }
                    }
                }
            }
        }
    });

    // Export functions
    function exportToPDF() {
        window.location.href = 'export_pdf.php?' + new URLSearchParams({
            type: 'sales',
            start_date: '<?= $startDate ?>',
            end_date: '<?= $endDate ?>'
        });
    }

    function exportToExcel() {
        window.location.href = 'export_excel.php?' + new URLSearchParams({
            type: 'sales',
            start_date: '<?= $startDate ?>',
            end_date: '<?= $endDate ?>'
        });
    }
    </script>
</body>
</html>