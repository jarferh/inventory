<?php
require_once '../../config/config.php';
require_once '../../classes/Database.php';
require_once '../../classes/Session.php';
require_once '../../classes/Reports.php';

Session::init();

if (!Session::isLoggedIn()) {
    header('Location: ../../login.php');
    exit();
}

$currentDateTime = '2025-02-16 14:50:02';
$currentUser = 'musty131311';

$reports = new Reports();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports Dashboard - <?= SITE_NAME ?></title>
    <link rel="stylesheet" href="../../assets/css/style.css">
    <link rel="stylesheet" href="../../assets/css/reports.css">
</head>
<body>
    <div class="container">
        <?php include '../../includes/header.php'; ?>
        
        <div class="content">
            <h2>Reports Dashboard</h2>
            
            <div class="reports-grid">
                <div class="report-card" onclick="location.href='sales_report.php'">
                    <i class="fas fa-chart-line"></i>
                    <h3>Sales Report</h3>
                    <p>View detailed sales analysis and trends</p>
                </div>
                
                <div class="report-card" onclick="location.href='inventory_report.php'">
                    <i class="fas fa-box"></i>
                    <h3>Inventory Report</h3>
                    <p>Stock levels and movement analysis</p>
                </div>
                
                <div class="report-card" onclick="location.href='financial_report.php'">
                    <i class="fas fa-money-bill-wave"></i>
                    <h3>Financial Report</h3>
                    <p>Revenue, expenses, and profit analysis</p>
                </div>
                
                <div class="report-card" onclick="location.href='supplier_report.php'">
                    <i class="fas fa-truck"></i>
                    <h3>Supplier Report</h3>
                    <p>Supplier performance and order history</p>
                </div>
            </div>
            
            <div class="quick-stats">
                <h3>Quick Statistics (Last 30 Days)</h3>
                <?php $stats = $reports->getQuickStats(); ?>
                
                <div class="stats-grid">
                    <div class="stat-box">
                        <h4>Total Sales</h4>
                        <p class="amount">KES <?= number_format($stats['total_sales'], 2) ?></p>
                        <p class="count"><?= $stats['sales_count'] ?> transactions</p>
                    </div>
                    
                    <div class="stat-box">
                        <h4>Top Selling Products</h4>
                        <ul class="top-items">
                            <?php foreach ($stats['top_products'] as $product): ?>
                            <li>
                                <span class="item-name"><?= htmlspecialchars($product['name']) ?></span>
                                <span class="item-count"><?= $product['quantity'] ?> units</span>
                            </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                    
                    <div class="stat-box">
                        <h4>Low Stock Alerts</h4>
                        <p class="count"><?= $stats['low_stock_count'] ?> products</p>
                        <a href="../inventory/low_stock.php" class="btn btn-small">View Details</a>
                    </div>
                    
                    <div class="stat-box">
                        <h4>Pending Orders</h4>
                        <p class="count"><?= $stats['pending_orders'] ?> orders</p>
                        <p class="amount">KES <?= number_format($stats['pending_amount'], 2) ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="../../assets/js/reports.js"></script>
</body>
</html>