<?php
require_once '../../config/config.php';
require_once '../../classes/Database.php';
require_once '../../classes/Session.php';
require_once '../../classes/Reports.php';
require_once '../../lib/PhpSpreadsheet/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

Session::init();

if (!Session::isLoggedIn()) {
    exit('Unauthorized access');
}

$currentDateTime = '2025-02-16 14:51:37';
$currentUser = 'musty131311';

$reports = new Reports();
$type = $_GET['type'] ?? '';
$startDate = $_GET['start_date'] ?? date('Y-m-d', strtotime('-30 days'));
$endDate = $_GET['end_date'] ?? date('Y-m-d');

$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();

// Set document properties
$spreadsheet->getProperties()
    ->setCreator($currentUser)
    ->setLastModifiedBy($currentUser)
    ->setTitle(SITE_NAME . ' - ' . ucfirst($type) . ' Report')
    ->setCreated(strtotime($currentDateTime));

switch ($type) {
    case 'sales':
        $salesData = $reports->getSalesReport($startDate, $endDate);
        
        // Header
        $sheet->setCellValue('A1', SITE_NAME);
        $sheet->setCellValue('A2', 'Sales Report');
        $sheet->setCellValue('A3', "Period: $startDate to $endDate");
        
        // Column headers
        $sheet->setCellValue('A5', 'Date');
        $sheet->setCellValue('B5', 'Transactions');
        $sheet->setCellValue('C5', 'Total Sales');
        $sheet->setCellValue('D5', 'Average Sale');
        
        // Data
        $row = 6;
        $totalSales = 0;
        foreach ($salesData as $sale) {
            $sheet->setCellValue('A' . $row, $sale['sale_date']);
            $sheet->setCellValue('B' . $row, $sale['total_transactions']);
            $sheet->setCellValue('C' . $row, $sale['total_amount']);
            $sheet->setCellValue('D' . $row, $sale['average_sale']);
            
            $totalSales += $sale['total_amount'];
            $row++;
        }
        
        // Summary
        $row += 2;
        $sheet->setCellValue('A' . $row, 'Total Sales:');
        $sheet->setCellValue('B' . $row, $totalSales);
        
        // Formatting
        $sheet->getColumnDimension('A')->setWidth(15);
        $sheet->getColumnDimension('B')->setWidth(15);
        $sheet->getColumnDimension('C')->setWidth(15);
        $sheet->getColumnDimension('D')->setWidth(15);
        
        $sheet->getStyle('C6:D' . ($row-2))->getNumberFormat()
            ->setFormatCode('KES #,##0.00');
        break;
        
    // Add more report types here
}

// Set headers for download
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="' . $type . '_report.xlsx"');
header('Cache-Control: max-age=0');

$writer = new Xlsx($spreadsheet);
$writer->save('php://output');