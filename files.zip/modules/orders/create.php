<?php
require_once '../../config/config.php';
require_once '../../classes/Database.php';
require_once '../../classes/Session.php';
require_once '../../classes/Order.php';
require_once '../../classes/Supplier.php';
require_once '../../classes/Inventory.php';

Session::init();

if (!Session::isLoggedIn()) {
    header('Location: ../../login.php');
    exit();
}

$supplier = new Supplier();
$suppliers = $supplier->getAllSuppliers();

$inventory = new Inventory();
$products = $inventory->getAllProducts();

$currentDateTime = '2025-02-16 14:44:29'; // Using provided UTC time
$currentUser = 'musty131311'; // Using provided login
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Purchase Order - <?= SITE_NAME ?></title>
    <link rel="stylesheet" href="../../assets/css/style.css">
</head>
<body>
    <div class="container">
        <?php include '../../includes/header.php'; ?>
        
        <div class="content">
            <h2>Create Purchase Order</h2>
            
            <form id="purchase-order-form" method="POST" action="process_order.php">
                <div class="order-header">
                    <div class="form-group">
                        <label for="supplier_id">Select Supplier</label>
                        <select id="supplier_id" name="supplier_id" class="form-control" required>
                            <option value="">Choose Supplier</option>
                            <?php foreach ($suppliers as $sup): ?>
                            <option value="<?= $sup['id'] ?>"><?= htmlspecialchars($sup['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Order Date</label>
                        <input type="text" value="<?= $currentDateTime ?>" readonly class="form-control">
                    </div>
                    
                    <div class="form-group">
                        <label>Created By</label>
                        <input type="text" value="<?= htmlspecialchars($currentUser) ?>" readonly class="form-control">
                    </div>
                </div>
                
                <div class="order-items">
                    <h3>Order Items</h3>
                    <table id="order-items-table" class="table">
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Quantity</th>
                                <th>Unit Price</th>
                                <th>Subtotal</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr id="item-row-template" style="display: none;">
                                <td>
                                    <select name="items[0][product_id]" class="form-control product-select" required>
                                        <option value="">Select Product</option>
                                        <?php foreach ($products as $prod): ?>
                                        <option value="<?= $prod['id'] ?>" 
                                                data-price="<?= $prod['unit_price'] ?>">
                                            <?= htmlspecialchars($prod['name']) ?>
                                        </option>
                                        <?php endforeach; ?>
                                    </select>
                                </td>
                                <td>
                                    <input type="number" name="items[0][quantity]" 
                                           class="form-control quantity-input" min="1" required>
                                </td>
                                <td>
                                    <input type="number" name="items[0][unit_price]" 
                                           class="form-control price-input" step="0.01" required>
                                </td>
                                <td>
                                    <span class="subtotal">0.00</span>
                                </td>
                                <td>
                                    <button type="button" class="btn btn-danger remove-item">Remove</button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    
                    <button type="button" id="add-item" class="btn btn-secondary">Add Item</button>
                </div>
                
                <div class="order-summary">
                    <div class="summary-row">
                        <span>Subtotal:</span>
                        <span id="total-subtotal">0.00</span>
                    </div>
                    <div class="summary-row">
                        <span>VAT (16%):</span>
                        <span id="total-vat">0.00</span>
                    </div>
                    <div class="summary-row total">
                        <span>Total:</span>
                        <span id="total-amount">0.00</span>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="notes">Order Notes</label>
                    <textarea id="notes" name="notes" class="form-control"></textarea>
                </div>
                
                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">Create Order</button>
                    <a href="list.php" class="btn">Cancel</a>
                </div>
            </form>
        </div>
    </div>
    
    <script src="../../assets/js/orders.js"></script>
</body>
</html>