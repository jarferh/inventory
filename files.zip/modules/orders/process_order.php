<?php
require_once '../../config/config.php';
require_once '../../classes/Database.php';
require_once '../../classes/Session.php';
require_once '../../classes/Order.php';
require_once '../../classes/Audit.php';

Session::init();

if (!Session::isLoggedIn()) {
    header('Content-Type: application/json');
    die(json_encode(['success' => false, 'message' => 'Unauthorized access']));
}

$currentDateTime = '2025-02-16 14:46:22'; // Using provided UTC time
$currentUser = 'musty131311'; // Using provided login

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $order = new Order();
        $audit = new Audit();
        
        // Prepare order data
        $orderData = [
            'supplier_id' => $_POST['supplier_id'],
            'notes' => $_POST['notes'],
            'total_amount' => calculateTotalAmount($_POST['items']),
            'items' => formatOrderItems($_POST['items']),
            'created_at' => $currentDateTime,
            'created_by' => $currentUser
        ];
        
        // Create the order
        $orderId = $order->createOrder($orderData);
        
        // Log the action
        $audit->log(
            Session::get('user_id'),
            'order_created',
            "Purchase order #{$orderId} created for supplier #{$orderData['supplier_id']}"
        );
        
        header('Content-Type: application/json');
        echo json_encode([
            'success' => true,
            'order_id' => $orderId,
            'message' => 'Order created successfully'
        ]);
        
    } catch (Exception $e) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
    }
}

function calculateTotalAmount($items) {
    $total = 0;
    foreach ($items as $item) {
        $total += $item['quantity'] * $item['unit_price'];
    }
    return $total;
}

function formatOrderItems($items) {
    $formatted = [];
    foreach ($items as $item) {
        if (!empty($item['product_id']) && !empty($item['quantity'])) {
            $formatted[] = [
                'product_id' => $item['product_id'],
                'quantity' => $item['quantity'],
                'unit_price' => $item['unit_price'],
                'subtotal' => $item['quantity'] * $item['unit_price']
            ];
        }
    }
    return $formatted;
}