<?php
require_once '../../config/config.php';
require_once '../../classes/Database.php';
require_once '../../classes/Session.php';
require_once '../../classes/Auth.php';
require_once '../../classes/Inventory.php';
require_once '../../classes/Sales.php';

Session::init();

if (!Session::isLoggedIn()) {
    header('Location: ../../login.php');
    exit();
}

$inventory = new Inventory();
$products = $inventory->getAllProducts();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>POS - <?= SITE_NAME ?></title>
    <link rel="stylesheet" href="../../assets/css/style.css">
</head>
<body>
    <div class="pos-container">
        <div class="products-section">
            <div class="search-bar">
                <input type="text" id="product-search" placeholder="Search products...">
            </div>
            
            <div class="products-grid">
                <?php foreach ($products as $product): ?>
                <div class="product-card" data-id="<?= $product['id'] ?>" 
                     data-name="<?= htmlspecialchars($product['name']) ?>"
                     data-price="<?= $product['unit_price'] ?>"
                     data-stock="<?= $product['stock_quantity'] ?>">
                    <h4><?= htmlspecialchars($product['name']) ?></h4>
                    <p class="price">KES <?= number_format($product['unit_price'], 2) ?></p>
                    <p class="stock">Stock: <?= $product['stock_quantity'] ?></p>
                    <button class="add-to-cart-btn">Add to Cart</button>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        
        <div class="cart-section">
            <h2>Current Sale</h2>
            
            <div class="cart-items">
                <!-- Cart items will be dynamically added here -->
            </div>
            
            <div class="cart-summary">
                <div class="subtotal">
                    <span>Subtotal:</span>
                    <span class="amount">KES 0.00</span>
                </div>
                <div class="tax">
                    <span>VAT (16%):</span>
                    <span class="amount">KES 0.00</span>
                </div>
                <div class="total">
                    <span>Total:</span>
                    <span class="amount">KES 0.00</span>
                </div>
            </div>
            
            <div class="payment-section">
                <input type="text" id="customer-name" placeholder="Customer Name">
                <select id="payment-method">
                    <option value="cash">Cash</option>
                    <option value="card">Card</option>
                    <option value="mobile_money">Mobile Money</option>
                </select>
                
                <button id="complete-sale" class="btn btn-primary">Complete Sale</button>
                <button id="cancel-sale" class="btn btn-danger">Cancel</button>
            </div>
        </div>
    </div>
    
    <script src="../../assets/js/pos.js"></script>
</body>
</html>