<?php
require_once '../../config/config.php';
require_once '../../classes/Database.php';
require_once '../../classes/Session.php';
require_once '../../classes/Supplier.php';

Session::init();

if (!Session::isLoggedIn()) {
    header('Location: ../../login.php');
    exit();
}

$supplier = new Supplier();
$suppliers = $supplier->getAllSuppliers();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Suppliers - <?= SITE_NAME ?></title>
    <link rel="stylesheet" href="../../assets/css/style.css">
</head>
<body>
    <div class="container">
        <?php include '../../includes/header.php'; ?>
        
        <div class="content">
            <div class="content-header">
                <h2>Suppliers</h2>
                <a href="add.php" class="btn btn-primary">Add New Supplier</a>
            </div>
            
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Contact Person</th>
                            <th>Phone</th>
                            <th>Email</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($suppliers as $sup): ?>
                        <tr>
                            <td><?= htmlspecialchars($sup['name']) ?></td>
                            <td><?= htmlspecialchars($sup['contact_person']) ?></td>
                            <td><?= htmlspecialchars($sup['phone']) ?></td>
                            <td><?= htmlspecialchars($sup['email']) ?></td>
                            <td>
                                <span class="badge <?= $sup['status'] ? 'badge-success' : 'badge-danger' ?>">
                                    <?= $sup['status'] ? 'Active' : 'Inactive' ?>
                                </span>
                            </td>
                            <td>
                                <div class="action-buttons">
                                    <a href="edit.php?id=<?= $sup['id'] ?>" 
                                       class="btn btn-small btn-primary">Edit</a>
                                    <a href="view.php?id=<?= $sup['id'] ?>" 
                                       class="btn btn-small">View</a>
                                    <button onclick="deleteSupplier(<?= $sup['id'] ?>)" 
                                            class="btn btn-small btn-danger">Delete</button>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <script>
    function deleteSupplier(id) {
        if (confirm('Are you sure you want to delete this supplier?')) {
            fetch('delete.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ id: id })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                } else {
                    alert('Error: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred while deleting the supplier');
            });
        }
    }
    </script>
</body>
</html>