<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'agrovet_system');

define('SITE_NAME', 'Agrovet System');
define('SITE_URL', 'http://localhost/agrovet');

define('SESSION_NAME', 'agrovet_session');
define('SESSION_LIFETIME', 7200); // 2 hours

define('TIMEZONE', 'UTC');
date_default_timezone_set(TIMEZONE);

// Error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Security
define('HASH_COST', 12); // For password hashing