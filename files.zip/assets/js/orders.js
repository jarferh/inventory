document.addEventListener('DOMContentLoaded', function() {
    const orderForm = document.getElementById('purchase-order-form');
    const itemsTable = document.getElementById('order-items-table');
    const addItemBtn = document.getElementById('add-item');
    let itemCounter = 0;
    
    // Add new item row
    addItemBtn.addEventListener('click', function() {
        const template = document.getElementById('item-row-template');
        const newRow = template.cloneNode(true);
        newRow.style.display = '';
        newRow.id = '';
        
        // Update name attributes
        const inputs = newRow.querySelectorAll('[name]');
        inputs.forEach(input => {
            input.name = input.name.replace('[0]', `[${itemCounter}]`);
        });
        
        itemsTable.querySelector('tbody').appendChild(newRow);
        itemCounter++;
        
        // Initialize event listeners for the new row
        initializeRowEvents(newRow);
        updateTotals();
    });
    
    // Initialize first row
    addItemBtn.click();
    
    function initializeRowEvents(row) {
        // Product selection change
        const productSelect = row.querySelector('.product-select');
        const priceInput = row.querySelector('.price-input');
        
        productSelect.addEventListener('change', function() {
            const option = this.options[this.selectedIndex];
            priceInput.value = option.dataset.price || '';
            updateRowTotal(row);
        });
        
        // Quantity change
        const quantityInput = row.querySelector('.quantity-input');
        quantityInput.addEventListener('input', function() {
            updateRowTotal(row);
        });
        
        // Price change
        priceInput.addEventListener('input', function() {
            updateRowTotal(row);
        });
        
        // Remove row
        const removeBtn = row.querySelector('.remove-item');
        removeBtn.addEventListener('click', function() {
            if (itemsTable.querySelectorAll('tbody tr').length > 1) {
                row.remove();
                updateTotals();
            }
        });
    }
    
    function updateRowTotal(row) {
        const quantity = parseFloat(row.querySelector('.quantity-input').value) || 0;
        const price = parseFloat(row.querySelector('.price-input').value) || 0;
        const subtotal = quantity * price;
        
        row.querySelector('.subtotal').textContent = subtotal.toFixed(2);
        updateTotals();
    }
    
    function updateTotals() {
        let subtotal = 0;
        
        document.querySelectorAll('.subtotal').forEach(element => {
            subtotal += parseFloat(element.textContent) || 0;
        });
        
        const vat = subtotal * 0.16;
        const total = subtotal + vat;
        
        document.getElementById('total-subtotal').textContent = subtotal.toFixed(2);
        document.getElementById('total-vat').textContent = vat.toFixed(2);
        document.getElementById('total-amount').textContent = total.toFixed(2);
    }
    
    // Form submission
    orderForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        if (!validateForm()) {
            return;
        }
        
        const formData = new FormData(this);
        
        fetch('process_order.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Order created successfully!');
                window.location.href = `view.php?id=${data.order_id}`; ▋