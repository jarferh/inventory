document.addEventListener('DOMContentLoaded', function() {
    // SKU Generator
    const nameInput = document.getElementById('name');
    const skuInput = document.getElementById('sku');
    const categorySelect = document.getElementById('category');
    
    if (nameInput && skuInput && categorySelect) {
        const generateSKU = () => {
            const category = categorySelect.value.substring(0, 3).toUpperCase();
            const name = nameInput.value.substring(0, 3).toUpperCase();
            const random = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
            skuInput.value = `${category}-${name}-${random}`;
        };
        
        nameInput.addEventListener('change', generateSKU);
        categorySelect.addEventListener('change', generateSKU);
    }
    
    // Form Validation
    const form = document.querySelector('form');
    if (form) {
        form.addEventListener('submit', function(e) {
            const unitPrice = parseFloat(document.getElementById('unit_price').value);
            const stockQuantity = parseInt(document.getElementById('stock_quantity').value);
            const reorderLevel = parseInt(document.getElementById('reorder_level').value);
            
            let isValid = true;
            let errorMessage = '';
            
            if (unitPrice <= 0) {
                errorMessage += 'Unit price must be greater than 0\n';
                isValid = false;
            }
            
            if (stockQuantity < 0) {
                errorMessage += 'Stock quantity cannot be negative\n';
                isValid = false;
            }
            
            if (reorderLevel < 0) {
                errorMessage += 'Reorder level cannot be negative\n';
                isValid = false;
            }
            
            if (reorderLevel > stockQuantity) {
                errorMessage += 'Warning: Reorder level is higher than current stock\n';
            }
            
            if (!isValid) {
                e.preventDefault();
                alert(errorMessage);
            }
        });
    }
    
    // Image Preview (if adding product images)
    const imageInput = document.getElementById('product_image');
    const imagePreview = document.getElementById('image_preview');
    
    if (imageInput && imagePreview) {
        imageInput.addEventListener('change', function() {
            const file = this.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    imagePreview.src = e.target.result;
                    imagePreview.style.display = 'block';
                };
                reader.readAsDataURL(file);
            }
        });
    }
});