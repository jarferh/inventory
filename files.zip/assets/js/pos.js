document.addEventListener('DOMContentLoaded', function() {
    const cart = {
        items: [],
        subtotal: 0,
        tax: 0,
        total: 0
    };
    
    // Add to Cart
    document.querySelectorAll('.add-to-cart-btn').forEach(button => {
        button.addEventListener('click', function() {
            const product = this.parentElement;
            const productId = product.dataset.id;
            const productName = product.dataset.name;
            const productPrice = parseFloat(product.dataset.price);
            const stock = parseInt(product.dataset.stock);
            
            if (stock <= 0) {
                alert('Product out of stock!');
                return;
            }
            
            addToCart(productId, productName, productPrice);
        });
    });
    
    // Product Search
    document.getElementById('product-search').addEventListener('input', function() {
        const searchTerm = this.value.toLowerCase();
        
        document.querySelectorAll('.product-card').forEach(card => {
            const productName = card.dataset.name.toLowerCase();
            card.style.display = productName.includes(searchTerm) ? 'block' : 'none';
        });
    });
    
    // Complete Sale
    document.getElementById('complete-sale').addEventListener('click', function() {
        if (cart.items.length === 0) {
            alert('Cart is empty!');
            return;
        }
        
        const customerName = document.getElementById('customer-name').value;
        if (!customerName) {
            alert('Please enter customer name');
            return;
        }
        
        const paymentMethod = document.getElementById('payment-method').value;
        
        const saleData = {
            customer_name: customerName,
            payment_method: paymentMethod,
            total_amount: cart.total,
            items: cart.items
        };
        
        // Send to server
        fetch('process.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(saleData)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Sale completed successfully!');
                window.location.href = `receipt.php?id=${data.sale_id}`;
            } else {
                alert('Error: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while processing the sale');
        });
    });
    
    // Cancel Sale
    document.getElementById('cancel-sale').addEventListener('click', function() {
        if (confirm('Are you sure you want to cancel this sale?')) {
            clearCart();
        }
    });
    
    function addToCart(productId, productName, productPrice) {
        const existingItem = cart.items.find(item => item.product_id === productId);
        
        if (existingItem) {
            existingItem.quantity++;
            existingItem.subtotal = existingItem.quantity * productPrice;
        } else {
            cart.items.push({
                product_id: productId,
                name: productName,
                unit_price: productPrice,
                quantity: 1,
                subtotal: productPrice
            });
        }
        
        updateCartDisplay();
    }
    
    function updateCartDisplay() {
        const cartItems = document.querySelector('.cart-items');
        cartItems.innerHTML = '';
        
        cart.subtotal = 0;
        
        cart.items.forEach(item => {
            cart.subtotal += item.subtotal;
            
            const itemElement = document.createElement('div');
            itemElement.className = 'cart-item';
            itemElement.innerHTML = `
                <span class="item-name">${item.name}</span>
                <div class="item-quantity">
                    <button class="qty-btn minus">-</button>
                    <span>${item.quantity}</span>
                    <button class="qty-btn plus">+</button>
                </div>
                <span class="item-price">KES ${item.subtotal.toFixed(2)}</span>
                <button class="remove-btn">×</button>
            `;
            
            cartItems.appendChild(itemElement);
        });
        
        cart.tax = cart.subtotal * 0.16;
        cart.total = cart.subtotal + cart.tax;
        
        document.querySelector('.subtotal .amount').textContent = 
            `KES ${cart.subtotal.toFixed(2)}`;
        document.querySelector('.tax .amount').textContent = 
            `KES ${cart.tax.toFixed(2)}`;
        document.querySelector('.total .amount').textContent = 
            `KES ${cart.total.toFixed(2)}`;
    }
    
    function clearCart() {
        cart.items = [];
        cart.subtotal = 0;
        cart.tax = 0;
        cart.total = 0;
        updateCartDisplay();
    }
});