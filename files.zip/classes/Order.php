<?php
class Order {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    public function createOrder($data) {
        try {
            $this->db->getConnection()->beginTransaction();
            
            // Insert main order
            $sql = "INSERT INTO purchase_orders (
                        supplier_id, 
                        user_id, 
                        order_number, 
                        total_amount, 
                        notes, 
                        status
                    ) VALUES (?, ?, ?, ?, ?, ?)";
            
            $orderNumber = $this->generateOrderNumber();
            
            $this->db->query($sql, [
                $data['supplier_id'],
                Session::get('user_id'),
                $orderNumber,
                $data['total_amount'],
                $data['notes'],
                'pending'
            ]);
            
            $orderId = $this->db->lastInsertId();
            
            // Insert order items
            foreach ($data['items'] as $item) {
                $sql = "INSERT INTO purchase_order_items (
                            order_id,
                            product_id,
                            quantity,
                            unit_price,
                            subtotal
                        ) VALUES (?, ?, ?, ?, ?)";
                
                $this->db->query($sql, [
                    $orderId,
                    $item['product_id'],
                    $item['quantity'],
                    $item['unit_price'],
                    $item['quantity'] * $item['unit_price']
                ]);
            }
            
            $this->db->getConnection()->commit();
            return $orderId;
            
        } catch (Exception $e) {
            $this->db->getConnection()->rollBack();
            throw $e;
        }
    }
    
    private function generateOrderNumber() {
        return 'PO-' . date('Ymd') . '-' . rand(1000, 9999);
    }
    
    public function getOrder($id) {
        $sql = "SELECT po.*, 
                       s.name as supplier_name,
                       u.username as created_by
                FROM purchase_orders po
                LEFT JOIN suppliers s ON po.supplier_id = s.id
                LEFT JOIN users u ON po.user_id = u.id
                WHERE po.id = ?";
        
        $stmt = $this->db->query($sql, [$id]);
        $order = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($order) {
            $sql = "SELECT poi.*, p.name as product_name
                    FROM purchase_order_items poi
                    LEFT JOIN products p ON poi.product_id = p.id
                    WHERE poi.order_id = ?";
            
            $stmt = $this->db->query($sql, [$id]);
            $order['items'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
        }
        
        return $order;
    }
    
    public function updateOrderStatus($id, $status) {
        $validStatuses = ['pending', 'approved', 'received', 'cancelled'];
        
        if (!in_array($status, $validStatuses)) {
            throw new Exception('Invalid order status');
        }
        
        $sql = "UPDATE purchase_orders SET status = ? WHERE id = ?";
        return $this->db->query($sql, [$status, $id]);
    }
    
    public function receiveOrder($id, $items) {
        try {
            $this->db->getConnection()->beginTransaction();
            
            foreach ($items as $item) {
                // Update inventory
                $sql = "UPDATE products 
                        SET stock_quantity = stock_quantity + ?
                        WHERE id = ?";
                
                $this->db->query($sql, [
                    $item['received_quantity'],
                    $item['product_id']
                ]);
                
                // Update order item
                $sql = "UPDATE purchase_order_items 
                        SET received_quantity = ?
                        WHERE id = ?";
                
                $this->db->query($sql, [
                    $item['received_quantity'],
                    $item['id']
                ]);
            }
            
            // Update order status
            $this->updateOrderStatus($id, 'received');
            
            $this->db->getConnection()->commit();
            return true;
            
        } catch (Exception $e) {
            $this->db->getConnection()->rollBack();
            throw $e;
        }
    }
    
    public function getAllOrders($filters = []) {
        $sql = "SELECT po.*,
                       s.name as supplier_name,
                       u.username as created_by,
                       COUNT(poi.id) as total_items
                FROM purchase_orders po
                LEFT JOIN suppliers s ON po.supplier_id = s.id
                LEFT JOIN users u ON po.user_id = u.id
                LEFT JOIN purchase_order_items poi ON po.id = poi.order_id";
        
        $params = [];
        $where = [];
        
        if (!empty($filters['status'])) {
            $where[] = "po.status = ?";
            $params[] = $filters['status'];
        }
        
        if (!empty($filters['supplier_id'])) {
            $where[] = "po.supplier_id = ?";
            $params[] = $filters['supplier_id'];
        }
        
        if (!empty($filters['date_from'])) {
            $where[] = "DATE(po.created_at) >= ?";
            $params[] = $filters['date_from'];
        }
        
        if (!empty($filters['date_to'])) {
            $where[] = "DATE(po.created_at) <= ?";
            $params[] = $filters['date_to'];
        }
        
        if (!empty($where)) {
            $sql .= " WHERE " . implode(" AND ", $where);
        }
        
        $sql .= " GROUP BY po.id ORDER BY po.created_at DESC";
        
        $stmt = $this->db->query($sql, $params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}