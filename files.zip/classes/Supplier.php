<?php
class Supplier {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    public function getAllSuppliers() {
        $sql = "SELECT * FROM suppliers ORDER BY name";
        $stmt = $this->db->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function getSupplier($id) {
        $sql = "SELECT * FROM suppliers WHERE id = ?";
        $stmt = $this->db->query($sql, [$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    public function addSupplier($data) {
        $sql = "INSERT INTO suppliers (name, contact_person, phone, email, address) 
                VALUES (?, ?, ?, ?, ?)";
        
        return $this->db->query($sql, [
            $data['name'],
            $data['contact_person'],
            $data['phone'],
            $data['email'],
            $data['address']
        ]);
    }
    
    public function updateSupplier($id, $data) {
        $sql = "UPDATE suppliers 
                SET name = ?, 
                    contact_person = ?, 
                    phone = ?, 
                    email = ?, 
                    address = ? 
                WHERE id = ?";
        
        return $this->db->query($sql, [
            $data['name'],
            $data['contact_person'],
            $data['phone'],
            $data['email'],
            $data['address'],
            $id
        ]);
    }
    
    public function deleteSupplier($id) {
        // First check if supplier has any associated orders
        $sql = "SELECT COUNT(*) FROM purchase_orders WHERE supplier_id = ?";
        $stmt = $this->db->query($sql, [$id]);
        $count = $stmt->fetchColumn();
        
        if ($count > 0) {
            throw new Exception('Cannot delete supplier with existing orders');
        }
        
        $sql = "DELETE FROM suppliers WHERE id = ?";
        return $this->db->query($sql, [$id]);
    }
    
    public function getSupplierOrders($id, $limit = 10) {
        $sql = "SELECT po.*, 
                       COUNT(poi.id) as total_items,
                       SUM(poi.quantity * poi.unit_price) as total_amount
                FROM purchase_orders po
                LEFT JOIN purchase_order_items poi ON po.id = poi.order_id
                WHERE po.supplier_id = ?
                GROUP BY po.id
                ORDER BY po.created_at DESC
                LIMIT ?";
        
        $stmt = $this->db->query($sql, [$id, $limit]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
} ▋