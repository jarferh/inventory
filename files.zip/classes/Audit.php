<?php
class Audit {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    public function log($userId, $action, $details) {
        $sql = "INSERT INTO audit_log (user_id, action, details, ip_address) 
                VALUES (?, ?, ?, ?)";
        
        return $this->db->query($sql, [
            $userId,
            $action,
            $details,
            $_SERVER['REMOTE_ADDR']
        ]);
    }
    
    public function getAuditLogs($startDate = null, $endDate = null, $userId = null) {
        $params = [];
        $sql = "SELECT al.*, u.username 
                FROM audit_log al 
                LEFT JOIN users u ON al.user_id = u.id 
                WHERE 1=1";
        
        if ($startDate) {
            $sql .= " AND DATE(al.created_at) >= ?";
            $params[] = $startDate;
        }
        
        if ($endDate) {
            $sql .= " AND DATE(al.created_at) <= ?";
            $params[] = $endDate;
        }
        
        if ($userId) {
            $sql .= " AND al.user_id = ?";
            $params[] = $userId;
        }
        
        $sql .= " ORDER BY al.created_at DESC";
        
        $stmt = $this->db->query($sql, $params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}