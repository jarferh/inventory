<?php
class Reports {
    private $db;
    private $currentDateTime;
    
    public function __construct() {
        $this->db = Database::getInstance();
        $this->currentDateTime = '2025-02-16 14:50:02';
    }
    
    public function getQuickStats() {
        $thirtyDaysAgo = date('Y-m-d', strtotime('-30 days', strtotime($this->currentDateTime)));
        
        return [
            'total_sales' => $this->getTotalSales($thirtyDaysAgo),
            'sales_count' => $this->getSalesCount($thirtyDaysAgo),
            'top_products' => $this->getTopProducts($thirtyDaysAgo),
            'low_stock_count' => $this->getLowStockCount(),
            'pending_orders' => $this->getPendingOrdersCount(),
            'pending_amount' => $this->getPendingOrdersAmount()
        ];
    }
    
    public function getSalesReport($startDate, $endDate) {
        $sql = "SELECT 
                    DATE(created_at) as sale_date,
                    COUNT(*) as total_transactions,
                    SUM(total_amount) as total_amount,
                    AVG(total_amount) as average_sale
                FROM sales 
                WHERE created_at BETWEEN ? AND ?
                GROUP BY DATE(created_at)
                ORDER BY sale_date DESC";
        
        $stmt = $this->db->query($sql, [$startDate, $endDate]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function getInventoryReport() {
        $sql = "SELECT 
                    p.*,
                    COALESCE(SUM(si.quantity), 0) as total_sold,
                    COALESCE(SUM(si.quantity * si.unit_price), 0) as revenue
                FROM products p
                LEFT JOIN sale_items si ON p.id = si.product_id
                LEFT JOIN sales s ON si.sale_id = s.id
                WHERE s.created_at >= DATE_SUB(?, INTERVAL 30 DAY)
                    OR s.created_at IS NULL
                GROUP BY p.id
                ORDER BY total_sold DESC";
        
        $stmt = $this->db->query($sql, [$this->currentDateTime]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function getFinancialReport($startDate, $endDate) {
        $data = [
            'sales' => $this->getSalesData($startDate, $endDate),
            'expenses' => $this->getExpensesData($startDate, $endDate),
            'purchases' => $this->getPurchasesData($startDate, $endDate)
        ];
        
        $data['profit'] = $data['sales']['total'] - $data['expenses']['total'] - $data['purchases']['total'];
        
        return $data;
    }
    
    public function getSupplierReport($supplierId = null, $startDate = null, $endDate = null) {
        $params = [];
        $sql = "SELECT 
                    s.id,
                    s.name as supplier_name,
                    COUNT(po.id) as total_orders,
                    SUM(po.total_amount) as total_amount,
                    AVG(po.total_amount) as average_order,
                    MAX(po.created_at) as last_order
                FROM suppliers s
                LEFT JOIN purchase_orders po ON s.id = po.supplier_id";
        
        if ($supplierId) {
            $sql .= " WHERE s.id = ?";
            $params[] = $supplierId;
        }
        
        if ($startDate) {
            $sql .= $supplierId ? " AND" : " WHERE";
            $sql .= " po.created_at >= ?";
            $params[] = $startDate;
        }
        
        if ($endDate) {
            $sql .= " AND po.created_at <= ?";
            $params[] = $endDate;
        }
        
        $sql .= " GROUP BY s.id ORDER BY total_amount DESC";
        
        $stmt = $this->db->query($sql, $params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    private function getTotalSales($startDate) {
        $sql = "SELECT COALESCE(SUM(total_amount), 0) as total 
                FROM sales 
                WHERE created_at >= ?";
        
        $stmt = $this->db->query($sql, [$startDate]);
        return $stmt->fetchColumn();
    }
    
    private function getSalesCount($startDate) {
        $sql = "SELECT COUNT(*) FROM sales WHERE created_at >= ?";
        $stmt = $this->db->query($sql, [$startDate]);
        return $stmt->fetchColumn();
    }
    
    private function getTopProducts($startDate, $limit = 5) {
        $sql = "SELECT 
                    p.name,
                    SUM(si.quantity) as quantity
                FROM products p
                JOIN sale_items si ON p.id = si.product_id
                JOIN sales s ON si.sale_id = s.id
                WHERE s.created_at >= ?
                GROUP BY p.id
                ORDER BY quantity DESC
                LIMIT ?";
        
        $stmt = $this->db->query($sql, [$startDate, $limit]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    private function getLowStockCount() {
        $sql = "SELECT COUNT(*) FROM products 
                WHERE stock_quantity <= reorder_level";
        
        $stmt = $this->db->query($sql);
        return $stmt->fetchColumn();
    }
    
    private function getPendingOrdersCount() {
        $sql = "SELECT COUNT(*) FROM purchase_orders 
                WHERE status = 'pending'";
        
        $stmt = $this->db->query($sql);
        return $stmt->fetchColumn();
    }
    
    private function getPendingOrdersAmount() {
        $sql = "SELECT COALESCE(SUM(total_amount), 0) 
                FROM purchase_orders 
                WHERE status = 'pending'";
        
        $stmt = $this->db->query($sql);
        return $stmt->fetchColumn();
    }
    
    private function getSalesData($startDate, $endDate) {
        $sql = "SELECT 
                    COUNT(*) as total_transactions,
                    SUM(total_amount) as total,
                    AVG(total_amount) as average,
                    MAX(total_amount) as highest,
                    MIN(total_amount) as lowest
                FROM sales 
                WHERE created_at BETWEEN ? AND ?";
        
        $stmt = $this->db->query($sql, [$startDate, $endDate]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    private function getExpensesData($startDate, $endDate) {
        $sql = "SELECT 
                    COUNT(*) as total_transactions,
                    SUM(amount) as total,
                    AVG(amount) as average
                FROM expenses 
                WHERE date BETWEEN ? AND ?";
        
        $stmt = $this->db->query($sql, [$startDate, $endDate]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    private function getPurchasesData($startDate, $endDate) {
        $sql = "SELECT 
                    COUNT(*) as total_orders,
                    SUM(total_amount) as total,
                    AVG(total_amount) as average
                FROM purchase_orders 
                WHERE created_at BETWEEN ? AND ? 
                AND status != 'cancelled'";
        
        $stmt = $this->db->query($sql, [$startDate, $endDate]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}