<?php
class Auth {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    public function login($username, $password) {
        $sql = "SELECT * FROM users WHERE username = ?";
        $stmt = $this->db->query($sql, [$username]);
        
        if ($user = $stmt->fetch(PDO::FETCH_ASSOC)) {
            if (password_verify($password, $user['password'])) {
                // Update last login
                $this->db->query(
                    "UPDATE users SET last_login = NOW() WHERE id = ?",
                    [$user['id']]
                );
                
                // Set session
                Session::set('user_id', $user['id']);
                Session::set('username', $user['username']);
                Session::set('role', $user['role']);
                Session::regenerate();
                
                return true;
            }
        }
        return false;
    }
    
    public function register($data) {
        $hashedPassword = password_hash($data['password'], PASSWORD_BCRYPT, ['cost' => HASH_COST]);
        
        $sql = "INSERT INTO users (username, password, email, full_name, role) 
                VALUES (?, ?, ?, ?, ?)";
        
        return $this->db->query($sql, [
            $data['username'],
            $hashedPassword,
            $data['email'],
            $data['full_name'],
            $data['role']
        ]);
    }
    
    public function logout() {
        Session::destroy();
    }
}