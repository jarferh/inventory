<?php
class Sales {
    private $db;
    private $inventory;
    
    public function __construct() {
        $this->db = Database::getInstance();
        $this->inventory = new Inventory();
    }
    
    public function createSale($data) {
        try {
            $this->db->getConnection()->beginTransaction();
            
            // Insert main sale record
            $sql = "INSERT INTO sales (invoice_number, customer_name, total_amount, 
                    payment_method, user_id) VALUES (?, ?, ?, ?, ?)";
            
            $this->db->query($sql, [
                $this->generateInvoiceNumber(),
                $data['customer_name'],
                $data['total_amount'],
                $data['payment_method'],
                Session::get('user_id')
            ]);
            
            $saleId = $this->db->lastInsertId();
            
            // Insert sale items
            foreach ($data['items'] as $item) {
                $sql = "INSERT INTO sale_items (sale_id, product_id, quantity, 
                        unit_price, subtotal) VALUES (?, ?, ?, ?, ?)";
                
                $this->db->query($sql, [
                    $saleId,
                    $item['product_id'],
                    $item['quantity'],
                    $item['unit_price'],
                    $item['quantity'] * $item['unit_price']
                ]);
                
                // Update inventory
                $this->inventory->updateStock(
                    $item['product_id'], 
                    $item['quantity'], 
                    'subtract'
                );
            }
            
            $this->db->getConnection()->commit();
            return $saleId;
            
        } catch (Exception $e) {
            $this->db->getConnection()->rollBack();
            throw $e;
        }
    }
    
    private function generateInvoiceNumber() {
        return 'INV-' . date('Ymd') . '-' . rand(1000, 9999);
    }
    
    public function getSale($id) {
        $sql = "SELECT s.*, si.*, p.name as product_name 
                FROM sales s 
                JOIN sale_items si ON s.id = si.sale_id 
                JOIN products p ON si.product_id = p.id 
                WHERE s.id = ?";
        
        $stmt = $this->db->query($sql, [$id]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function getDailySales($date = null) {
        $date = $date ?? date('Y-m-d');
        
        $sql = "SELECT SUM(total_amount) as total, COUNT(*) as count 
                FROM sales 
                WHERE DATE(created_at) = ?";
        
        $stmt = $this->db->query($sql, [$date]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}