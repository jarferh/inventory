                </div>
                <div class="card-footer bg-transparent border-0">
                    <div class="row text-center">
                        <div class="col-4">
                            <h6 class="text-muted mb-1">Weekly Sales</h6>
                            <h5 class="mb-0">KES <?= number_format($weeklyTrend['total_sales'], 2) ?></h5>
                        </div>
                        <div class="col-4">
                            <h6 class="text-muted mb-1">Avg. Daily Sales</h6>
                            <h5 class="mb-0">KES <?= number_format($weeklyTrend['average_daily'], 2) ?></h5>
                        </div>
                        <div class="col-4">
                            <h6 class="text-muted mb-1">Growth</h6>
                            <h5 class="mb-0 <?= $weeklyTrend['growth'] >= 0 ? 'text-success' : 'text-danger' ?>">
                                <?= number_format(abs($weeklyTrend['growth']), 1) ?>%
                            </h5>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Top Products -->
        <div class="col-12 col-xl-4">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-header bg-transparent border-0">
                    <h5 class="mb-0">Top Products</h5>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="bg-light">
                                <tr>
                                    <th>Product</th>
                                    <th>Sales</th>
                                    <th>Revenue</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($reports->getTopProducts(5) as $product): ?>
                                <tr>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="product-icon bg-light rounded p-2 me-2">
                                                <i class="fas fa-box text-primary"></i>
                                            </div>
                                            <div>
                                                <h6 class="mb-0"><?= htmlspecialchars($product['name']) ?></h6>
                                                <small class="text-muted"><?= htmlspecialchars($product['category']) ?></small>
                                            </div>
                                        </div>
                                    </td>
                                    <td><?= $product['quantity'] ?></td>
                                    <td>KES <?= number_format($product['revenue'], 2) ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Activity & Low Stock -->
    <div class="row g-4">
        <!-- Recent Transactions -->
        <div class="col-12 col-xl-8">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-transparent border-0 d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Recent Transactions</h5>
                    <a href="/reports/sales" class="btn btn-sm btn-primary">View All</a>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="bg-light">
                                <tr>
                                    <th>Invoice</th>
                                    <th>Customer</th>
                                    <th>Products</th>
                                    <th>Amount</th>
                                    <th>Status</th>
                                    <th>Time</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recentTransactions as $transaction): ?>
                                <tr>
                                    <td>
                                        <a href="/sales/invoice/<?= $transaction['id'] ?>" class="text-primary fw-medium">
                                            #<?= $transaction['invoice_number'] ?>
                                        </a>
                                    </td>
                                    <td><?= htmlspecialchars($transaction['customer_name']) ?></td>
                                    <td><?= $transaction['item_count'] ?> items</td>
                                    <td>KES <?= number_format($transaction['total_amount'], 2) ?></td>
                                    <td>
                                        <span class="badge bg-<?= getStatusColor($transaction['payment_status']) ?>">
                                            <?= ucfirst($transaction['payment_status']) ?>
                                        </span>
                                    </td>
                                    <td><?= getTimeAgo($transaction['created_at']) ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Low Stock Alert -->
        <div class="col-12 col-xl-4">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-transparent border-0 d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Low Stock Alert</h5>
                    <a href="/inventory/low-stock" class="btn btn-sm btn-danger">View All</a>
                </div>
                <div class="card-body p-0">
                    <div class="list-group list-group-flush">
                        <?php foreach ($lowStockItems as $item): ?>
                        <div class="list-group-item">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="mb-1"><?= htmlspecialchars($item['name']) ?></h6>
                                    <small class="text-muted">
                                        Category: <?= htmlspecialchars($item['category']) ?>
                                    </small>
                                </div>
                                <div class="text-end">
                                    <div class="stock-indicator <?= getStockIndicatorClass($item) ?>">
                                        <?= $item['stock_quantity'] ?>/<?= $item['reorder_level'] ?>
                                    </div>
                                    <a href="/inventory/restock/<?= $item['id'] ?>" class="btn btn-sm btn-outline-primary mt-2">
                                        Restock
                                    </a>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
function getStatusColor($status) {
    return match($status) {
        'completed' => 'success',
        'pending' => 'warning',
        'failed' => 'danger',
        default => 'secondary'
    };
}

function getTimeAgo($datetime) {
    $timestamp = strtotime($datetime);
    $currentTimestamp = strtotime('2025-02-16 15:07:45'); // Using provided timestamp
    $diff = $currentTimestamp - $timestamp;
    
    if ($diff < 60) {
        return 'Just now';
    } elseif ($diff < 3600) {
        $minutes = floor($diff / 60);
        return $minutes . ' min ago';
    } elseif ($diff < 86400) {
        $hours = floor($diff / 3600);
        return $hours . ' hours ago';
    } else {
        return date('M d, Y', $timestamp);
    }
}

function getStockIndicatorClass($item) {
    $ratio = $item['stock_quantity'] / $item['reorder_level'];
    if ($ratio <= 0.25) {
        return 'danger';
    } elseif ($ratio <= 0.5) {
        return 'warning';
    }
    return 'success';
}
?>

<!-- Add this before </body> -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
// Sales Trend Chart
const ctx = document.getElementById('salesTrendChart').getContext('2d');
new Chart(ctx, {
    type: 'line',
    data: {
        labels: <?= json_encode(array_column($weeklyTrend['daily_data'], 'date')) ?>,
        datasets: [{
            label: 'Sales',
            data: <?= json_encode(array_column($weeklyTrend['daily_data'], 'amount')) ?>,
            borderColor: '#0d6efd',
            backgroundColor: 'rgba(13, 110, 253, 0.1)',
            fill: true,
            tension: 0.4,
            pointRadius: 4,
            pointBackgroundColor: '#ffffff',
            pointBorderColor: '#0d6efd',
            pointBorderWidth: 2
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                display: false
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                grid: {
                    display: true,
                    drawBorder: false
                },
                ticks: {
                    callback: function(value) {
                        return 'KES ' + value.toLocaleString();
                    }
                }
            },
            x: {
                grid: {
                    display: false
                }
            }
        }
    }
});
</script>

<?php include '../includes/footer.php'; ?>