<?php
class Backup {
    private $db;
    private $currentDateTime = '2025-02-16 16:05:09';
    private $currentUser = 'musty131311';
    private $backupPath = 'backups/';

    public function __construct() {
        $this->db = Database::getInstance();
        $this->ensureBackupDirectory();
    }

    private function ensureBackupDirectory() {
        if (!file_exists($this->backupPath)) {
            mkdir($this->backupPath, 0755, true);
        }
    }

    public function createBackup($includeFiles = true) {
        try {
            $backupId = $this->logBackupStart();
            $filename = $this->generateBackupFilename();

            // Create backup directory for this specific backup
            $backupDir = $this->backupPath . $filename . '/';
            mkdir($backupDir, 0755, true);

            // Backup database
            $dbBackupFile = $this->backupDatabase($backupDir);

            // Backup files if requested
            $filesBackupFile = null;
            if ($includeFiles) {
                $filesBackupFile = $this->backupFiles($backupDir);
            }

            // Create backup manifest
            $manifest = $this->createManifest($dbBackupFile, $filesBackupFile);
            file_put_contents($backupDir . 'manifest.json', json_encode($manifest, JSON_PRETTY_PRINT));

            // Create ZIP archive
            $zipFile = $this->createZipArchive($backupDir, $filename);

            // Update backup log
            $this->logBackupCompletion($backupId, $zipFile);

            // Cleanup temporary files
            $this->cleanup($backupDir);

            return [
                'backup_id' => $backupId,
                'filename' => $zipFile,
                'size' => filesize($this->backupPath . $zipFile),
                'manifest' => $manifest
            ];
        } catch (Exception $e) {
            $this->logBackupError($backupId ?? null, $e->getMessage());
            error_log("Backup failed: " . $e->getMessage());
            throw new Exception("Backup creation failed");
        }
    }

    private function backupDatabase($backupDir) {
        $filename = 'database.sql';
        $tables = $this->getTables();
        
        $output = "-- Database Backup\n";
        $output .= "-- Generated: " . $this->currentDateTime . "\n\n";

        foreach ($tables as $table) {
            $output .= $this->getTableCreateStatement($table) . "\n\n";
            $output .= $this->getTableData($table) . "\n\n";
        }

        file_put_contents($backupDir . $filename, $output);
        return $filename;
    }

    private function getTables() {
        $stmt = $this->db->query("SHOW TABLES");
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    }

    private function getTableCreateStatement($table) {
        $stmt = $this->db->query("SHOW CREATE TABLE `$table`");
        $row = $stmt->fetch();
        return $row['Create Table'] . ";";
    }

    private function getTableData($table) {
        $output = "";
        $stmt = $this->db->query("SELECT * FROM `$table`");
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $values = array_map(function($value) {
                return $value === null ? 'NULL' : $this->db->quote($value);
            }, $row);
            $output .= "INSERT INTO `$table` VALUES (" . implode(",", $values) . ");\n";
        }
        return $output;
    }

    private function backupFiles($backupDir) {
        $filename = 'files.zip';
        $zip = new ZipArchive();
        
        if ($zip->open($backupDir . $filename, ZipArchive::CREATE | ZipArchive::OVERWRITE) === true) {
            $this->addFilesToZip($zip, 'uploads/');
            $zip->close();
            return $filename;
        }
        
        throw new Exception("Could not create files backup archive");
    }

    private function addFilesToZip($zip, $path, $relativePath = '') {
        $handler = opendir($path);
        while ($file = readdir($handler)) {
            if ($file == '.' || $file == '..') continue;

            $filePath = $path . $file;
            $zipPath = $relativePath . $file;

            if (is_file($filePath)) {
                $zip->addFile($filePath, $zipPath);
            } elseif (is_dir($filePath)) {
                $zip->addEmptyDir($zipPath);
                $this->addFilesToZip($zip, $filePath . '/', $zipPath . '/');
            }
        }
        closedir($handler);
    }

    private function createManifest($dbFile, $filesFile) {
        return [
            'version' => '1.0',
            'timestamp' => $this->currentDateTime,
            'created_by' => $this->currentUser,
            'files' => [
                'database' => $dbFile,
                'files' => $filesFile
            ],
            'system_info' => [
                'php_version' => PHP_VERSION,
                'os' => PHP_OS,
                'server' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown'
            ]
        ];
    }

    private function createZipArchive($sourceDir, $filename) {
        $zipFile = $filename . '.zip';
        $zip = new ZipArchive();
        
        if ($zip->open($this->backupPath . $zipFile, ZipArchive::CREATE | ZipArchive::OVERWRITE) === true) {
            $this->addFilesToZip($zip, $sourceDir);
            $zip->close();
            return $zipFile;
        }
        
        throw new Exception("Could not create backup archive");
    }

    public function restore($backupFile) {
        try {
            $restoreId = $this->logRestoreStart($backupFile);
            $extractPath = $this->backupPath . 'restore_' . time() . '/';
            
            // Extract backup
            $this->extractBackup($backupFile, $extractPath);

            // Validate manifest
            $manifest = $this->validateManifest($extractPath);

            // Restore database
            if (isset($manifest['files']['database'])) {
                $this->restoreDatabase($extractPath . $manifest['files']['database']);
            }

            // Restore files
            if (isset($manifest['files']['files'])) {
                $this->restoreFiles($extractPath . $manifest['files']['files']);
            }

            // Log successful restore
            $this->logRestoreCompletion($restoreId);

            // Cleanup
            $this->cleanup($extractPath);

            return true;
        } catch (Exception $e) {
            $this->logRestoreError($restoreId ?? null, $e->getMessage());
            error_log("Restore failed: " . $e->getMessage());
            throw new Exception("Restore failed: " . $e->getMessage());
        }
    }

    private function extractBackup($backupFile, $extractPath) {
        $zip = new ZipArchive();
        if ($zip->open($backupFile) === true) {
            $zip->extractTo($extractPath);
            $zip->close();
        } else {
            throw new Exception("Could not extract backup file");
        }
    }

    private function validateManifest($extractPath) {
        $manifestFile = $extractPath . 'manifest.json';
        if (!file_exists($manifestFile)) {
            throw new Exception("Invalid backup: manifest.json not found");
        }

        $manifest = json_decode(file_get_contents($manifestFile), true);
        if (!$manifest) {
            throw new Exception("Invalid manifest file");
        }

        return $manifest;
    }

    private function restoreDatabase($sqlFile) {
        $sql = file_get_contents($sqlFile);
        $this->db->exec($sql);
    }

    private function restoreFiles($filesArchive) {
        $zip = new ZipArchive();
        if ($zip->open($filesArchive) === true) {
            $zip->extractTo('uploads/');
            $zip->close();
        } else {
            throw new Exception("Could not restore files");
        }
    }

    private function cleanup($path) {
        if (!is_dir($path)) return;

        $files = array_diff(scandir($path), ['.', '..']);
        foreach ($files as $file) {
            $filePath = $path . $file;
            is_dir($filePath) ? $this->cleanup($filePath . '/') : unlink($filePath);
        }
        rmdir($path);
    }

    private function logBackupStart() {
        $stmt = $this->db->prepare("
            INSERT INTO backup_logs (
                type, status, started_at, created_by
            ) VALUES ('backup', 'in_progress', ?, ?)
        ");
        $stmt->execute([$this->currentDateTime, $this->currentUser]);
        return $this->db->lastInsertId();
    }

    private function logBackupCompletion($backupId, $filename) {
        $stmt = $this->db->prepare("
            UPDATE backup_logs 
            SET status = 'completed',
                filename = ?,
                completed_at = ?,
                updated_at = ?,
                updated_by = ?
            WHERE id = ?
        ");
        $stmt->execute([
            $filename,
            $this->currentDateTime,
            $this->currentDateTime,
            $this->currentUser,
            $backupId
        ]);
    }

    private function logBackupError($backupId, $error) {
        if (!$backupId) return;

        $stmt = $this->db->prepare("
            UPDATE backup_logs 
            SET status ▋