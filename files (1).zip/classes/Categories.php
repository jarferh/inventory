<?php
class Categories {
    private $db;
    private $currentDateTime = '2025-02-16 15:55:22';
    private $currentUser = 'musty131311';

    public function __construct() {
        $this->db = Database::getInstance();
    }

    public function getAllCategories($includeInactive = false) {
        try {
            $sql = "SELECT c.*, 
                    p.name as parent_name,
                    (SELECT COUNT(*) FROM products WHERE category_id = c.id) as product_count
                    FROM categories c 
                    LEFT JOIN categories p ON c.parent_id = p.id";
            
            if (!$includeInactive) {
                $sql .= " WHERE c.status = 'active'";
            }
            
            $sql .= " ORDER BY c.name ASC";

            $stmt = $this->db->prepare($sql);
            $stmt->execute();
            return $stmt->fetchAll();
        } catch (Exception $e) {
            error_log("Error fetching categories: " . $e->getMessage());
            throw new Exception("Error fetching categories");
        }
    }

    public function getCategory($id) {
        try {
            $stmt = $this->db->prepare("
                SELECT c.*, 
                    p.name as parent_name,
                    (SELECT COUNT(*) FROM products WHERE category_id = c.id) as product_count
                FROM categories c 
                LEFT JOIN categories p ON c.parent_id = p.id
                WHERE c.id = ?
            ");
            $stmt->execute([$id]);
            return $stmt->fetch();
        } catch (Exception $e) {
            error_log("Error fetching category: " . $e->getMessage());
            throw new Exception("Error fetching category details");
        }
    }

    public function addCategory($data) {
        try {
            $stmt = $this->db->prepare("
                INSERT INTO categories (
                    name, description, parent_id, status, 
                    created_by, updated_by
                ) VALUES (?, ?, ?, ?, ?, ?)
            ");

            $stmt->execute([
                $data['name'],
                $data['description'] ?? null,
                $data['parent_id'] ?? null,
                $data['status'] ?? 'active',
                $this->currentUser,
                $this->currentUser
            ]);

            return $this->db->lastInsertId();
        } catch (Exception $e) {
            error_log("Error adding category: " . $e->getMessage());
            throw new Exception("Error adding category");
        }
    }

    public function updateCategory($id, $data) {
        try {
            // Prevent circular parent references
            if (isset($data['parent_id']) && $data['parent_id'] == $id) {
                throw new Exception("Category cannot be its own parent");
            }

            if (isset($data['parent_id'])) {
                $this->validateParentCategory($id, $data['parent_id']);
            }

            $stmt = $this->db->prepare("
                UPDATE categories SET 
                    name = ?,
                    description = ?,
                    parent_id = ?,
                    status = ?,
                    updated_by = ?,
                    updated_at = ?
                WHERE id = ?
            ");

            $stmt->execute([
                $data['name'],
                $data['description'] ?? null,
                $data['parent_id'] ?? null,
                $data['status'] ?? 'active',
                $this->currentUser,
                $this->currentDateTime,
                $id
            ]);

            return true;
        } catch (Exception $e) {
            error_log("Error updating category: " . $e->getMessage());
            throw new Exception("Error updating category");
        }
    }

    private function validateParentCategory($categoryId, $parentId) {
        // Check if parent category exists
        $parent = $this->getCategory($parentId);
        if (!$parent) {
            throw new Exception("Parent category does not exist");
        }

        // Check for circular references
        $currentParentId = $parentId;
        while ($currentParentId !== null) {
            if ($currentParentId == $categoryId) {
                throw new Exception("Circular category reference detected");
            }
            $currentParent = $this->getCategory($currentParentId);
            $currentParentId = $currentParent['parent_id'];
        }
    }

    public function deleteCategory($id) {
        try {
            // Check if category has products
            $stmt = $this->db->prepare("
                SELECT COUNT(*) as count 
                FROM products 
                WHERE category_id = ?
            ");
            $stmt->execute([$id]);
            $result = $stmt->fetch();

            if ($result['count'] > 0) {
                throw new Exception("Cannot delete category with existing products");
            }

            // Check if category has child categories
            $stmt = $this->db->prepare("
                SELECT COUNT(*) as count 
                FROM categories 
                WHERE parent_id = ?
            ");
            $stmt->execute([$id]);
            $result = $stmt->fetch();

            if ($result['count'] > 0) {
                throw new Exception("Cannot delete category with child categories");
            }

            $stmt = $this->db->prepare("DELETE FROM categories WHERE id = ?");
            $stmt->execute([$id]);

            return true;
        } catch (Exception $e) {
            error_log("Error deleting category: " . $e->getMessage());
            throw new Exception($e->getMessage());
        }
    }

    public function getCategoryTree($parentId = null) {
        try {
            $categories = $this->getAllCategories();
            return $this->buildCategoryTree($categories, $parentId);
        } catch (Exception $e) {
            error_log("Error building category tree: " . $e->getMessage());
            throw new Exception("Error building category tree");
        }
    }

    private function buildCategoryTree($categories, $parentId = null) {
        $tree = [];
        
        foreach ($categories as $category) {
            if ($category['parent_id'] == $parentId) {
                $children = $this->buildCategoryTree($categories, $category['id']);
                if ($children) {
                    $category['children'] = $children;
                }
                $tree[] = $category;
            }
        }
        
        return $tree;
    }

    public function moveCategory($categoryId, $newParentId) {
        try {
            $this->validateParentCategory($categoryId, $newParentId);

            $stmt = $this->db->prepare("
                UPDATE categories SET 
                    parent_id = ?,
                    updated_by = ?,
                    updated_at = ?
                WHERE id = ?
            ");

            $stmt->execute([
                $newParentId,
                $this->currentUser,
                $this->currentDateTime,
                $ ▋