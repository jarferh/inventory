<?php
class Sales {
    private $db;
    private $currentDateTime = '2025-02-16 15:56:34';
    private $currentUser = 'musty131311';

    public function __construct() {
        $this->db = Database::getInstance();
    }

    public function createSale($data) {
        try {
            $this->db->beginTransaction();

            // Generate invoice number
            $invoiceNumber = $this->generateInvoiceNumber();

            // Calculate totals
            $subtotal = 0;
            foreach ($data['items'] as $item) {
                $subtotal += $item['quantity'] * $item['unit_price'];
            }

            $taxRate = $this->getTaxRate();
            $taxAmount = $subtotal * ($taxRate / 100);
            $discountAmount = $data['discount_amount'] ?? 0;
            $totalAmount = $subtotal + $taxAmount - $discountAmount;

            // Insert sale record
            $stmt = $this->db->prepare("
                INSERT INTO sales (
                    customer_id, invoice_number, sale_date,
                    subtotal, tax_amount, discount_amount, total_amount,
                    payment_method, payment_status, notes,
                    created_by, updated_by
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");

            $stmt->execute([
                $data['customer_id'] ?? null,
                $invoiceNumber,
                $this->currentDateTime,
                $subtotal,
                $taxAmount,
                $discountAmount,
                $totalAmount,
                $data['payment_method'],
                $data['payment_status'] ?? 'pending',
                $data['notes'] ?? null,
                $this->currentUser,
                $this->currentUser
            ]);

            $saleId = $this->db->lastInsertId();

            // Insert sale items
            foreach ($data['items'] as $item) {
                $this->addSaleItem($saleId, $item);
            }

            $this->db->commit();

            // Generate receipt if payment is completed
            if ($data['payment_status'] === 'paid') {
                $this->generateReceipt($saleId);
            }

            return [
                'sale_id' => $saleId,
                'invoice_number' => $invoiceNumber,
                'total_amount' => $totalAmount
            ];
        } catch (Exception $e) {
            $this->db->rollBack();
            error_log("Error creating sale: " . $e->getMessage());
            throw new Exception("Error creating sale");
        }
    }

    private function addSaleItem($saleId, $item) {
        // Verify product stock
        $product = $this->getProduct($item['product_id']);
        if ($product['stock_quantity'] < $item['quantity']) {
            throw new Exception("Insufficient stock for product: " . $product['name']);
        }

        // Calculate item total
        $totalAmount = $item['quantity'] * $item['unit_price'];
        $totalAmount -= ($item['discount_amount'] ?? 0);

        // Insert sale item
        $stmt = $this->db->prepare("
            INSERT INTO sale_items (
                sale_id, product_id, quantity,
                unit_price, discount_amount, total_amount
            ) VALUES (?, ?, ?, ?, ?, ?)
        ");

        $stmt->execute([
            $saleId,
            $item['product_id'],
            $item['quantity'],
            $item['unit_price'],
            $item['discount_amount'] ?? 0,
            $totalAmount
        ]);

        // Update product stock
        $this->updateProductStock(
            $item['product_id'],
            -$item['quantity'],
            'sale',
            "Sale #{$saleId}"
        );
    }

    private function updateProductStock($productId, $quantity, $type, $notes) {
        $stmt = $this->db->prepare("
            UPDATE products 
            SET stock_quantity = stock_quantity + ?,
                updated_at = ?,
                updated_by = ?
            WHERE id = ?
        ");

        $stmt->execute([
            $quantity,
            $this->currentDateTime,
            $this->currentUser,
            $productId
        ]);

        // Log inventory transaction
        $stmt = $this->db->prepare("
            INSERT INTO inventory_transactions (
                product_id, type, quantity, notes, created_by
            ) VALUES (?, ?, ?, ?, ?)
        ");

        $stmt->execute([
            $productId,
            $type,
            $quantity,
            $notes,
            $this->currentUser
        ]);
    }

    private function generateInvoiceNumber() {
        $prefix = $this->getSetting('invoice_prefix', 'INV-');
        $nextNumber = $this->getSetting('next_invoice_number', '1');

        // Update next invoice number
        $this->updateSetting('next_invoice_number', $nextNumber + 1);

        return $prefix . str_pad($nextNumber, 6, '0', STR_PAD_LEFT);
    }

    private function getSetting($key, $default = null) {
        $stmt = $this->db->prepare("
            SELECT value 
            FROM settings 
            WHERE name = ?
        ");
        $stmt->execute([$key]);
        $result = $stmt->fetch();

        return $result ? $result['value'] : $default;
    }

    private function updateSetting($key, $value) {
        $stmt = $this->db->prepare("
            UPDATE settings 
            SET value = ?,
                updated_at = ?,
                updated_by = ?
            WHERE name = ?
        ");

        $stmt->execute([
            $value,
            $this->currentDateTime,
            $this->currentUser,
            $key
        ]);
    }

    public function getSale($id) {
        try {
            $stmt = $this->db->prepare("
                SELECT s.*, 
                    c.name as customer_name,
                    c.email as customer_email,
                    c.phone as customer_phone
                FROM sales s
                LEFT JOIN customers c ON s.customer_id = c.id
                WHERE s.id = ?
            ");
            $stmt->execute([$id]);
            $sale = $stmt->fetch();

            if (!$sale) {
                return null;
            }

            // Get sale items
            $sale['items'] = $this->getSaleItems($id);

            return $sale;
        } catch (Exception $e) {
            error_log("Error fetching sale: " . $e->getMessage());
            throw new Exception("Error fetching sale details");
        }
    }

    private function getSaleItems($saleId) {
        $stmt = $this->db->prepare("
            SELECT si.*, 
                p.name as product_name,
                p.sku as product_sku
            FROM sale_items si
            JOIN products p ON si.product_id = p.id
            WHERE si.sale_id = ?
        ");
        $stmt->execute([$saleId]);
        return $stmt->fetchAll();
    }

    public function updateSaleStatus($id, $status) {
        try {
            $stmt = $this->db->prepare("
                UPDATE sales 
                SET payment_status = ?,
                    updated_at = ?,
                    updated_by = ?
                WHERE id = ?
            ");

            $stmt->execute([
                $status,
                $this->currentDateTime,
                $this->currentUser,
                $id
            ]);

            if ($status === 'paid') {
                $this->generateReceipt($id);
            }

            return true;
        } catch (Exception $e) {
            error_log("Error updating sale status: " . $e->getMessage());
            throw new Exception("Error updating sale status");
        }
    }

    private function generateReceipt($saleId) {
        $sale = $this->getSale($saleId);
        if (!$sale) {
            throw new Exception("Sale not found");
        }

        // Receipt generation logic here
        // This could involve generating PDF, sending email, etc.
        // Implementation depends on specific requirements
    }

    public function getSalesByDateRange($startDate, $endDate) {
        try {
            $stmt = $this->db->prepare("
                SELECT s.*, 
                    c.name as customer_name,
                    COUNT(si.id) as total_items,
                    SUM(si.quantity) as total_quantity
                FROM sales s
                LEFT JOIN customers c ON s.customer_id = c.id
                LEFT JOIN sale_items si ON s.id = si.sale_id
                WHERE s.sale_date BETWEEN ? AND ?
                GROUP BY s.id
                ORDER BY s.sale_date DESC
            ");

            $stmt->execute([$startDate, $endDate]);
            return $stmt->fetchAll();
        } catch (Exception $e) {
            error_log("Error fetching sales: " . $e->getMessage());
            throw new Exception("Error fetching sales");
        }
    }

    private function getTaxRate() {
        return (float) $this->getSetting('tax_rate', '16.0'); ▋