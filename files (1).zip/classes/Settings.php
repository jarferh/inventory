<?php
class Settings {
    private $db;
    private $currentDateTime = '2025-02-16 16:02:22';
    private $currentUser = 'musty131311';
    private $cache = [];

    public function __construct() {
        $this->db = Database::getInstance();
        $this->loadSettings();
    }

    private function loadSettings() {
        try {
            $stmt = $this->db->prepare("SELECT * FROM settings");
            $stmt->execute();
            $settings = $stmt->fetchAll();

            foreach ($settings as $setting) {
                $this->cache[$setting['category']][$setting['name']] = [
                    'value' => $this->castValue($setting['value'], $setting['type']),
                    'type' => $setting['type'],
                    'is_public' => $setting['is_public']
                ];
            }
        } catch (Exception $e) {
            error_log("Error loading settings: " . $e->getMessage());
            throw new Exception("Error loading system settings");
        }
    }

    private function castValue($value, $type) {
        switch ($type) {
            case 'boolean':
                return (bool) $value;
            case 'integer':
                return (int) $value;
            case 'float':
                return (float) $value;
            case 'json':
                return json_decode($value, true);
            default:
                return $value;
        }
    }

    public function get($category, $name, $default = null) {
        if (isset($this->cache[$category][$name])) {
            return $this->cache[$category][$name]['value'];
        }
        return $default;
    }

    public function set($category, $name, $value, $type = 'string', $isPublic = false) {
        try {
            $this->db->beginTransaction();

            $stmt = $this->db->prepare("
                INSERT INTO settings (
                    category, name, value, type, is_public,
                    created_at, updated_at, updated_by
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE
                    value = VALUES(value),
                    type = VALUES(type),
                    is_public = VALUES(is_public),
                    updated_at = VALUES(updated_at),
                    updated_by = VALUES(updated_by)
            ");

            // Convert value based on type before storage
            $storedValue = $type === 'json' ? json_encode($value) : (string) $value;

            $stmt->execute([
                $category,
                $name,
                $storedValue,
                $type,
                $isPublic,
                $this->currentDateTime,
                $this->currentDateTime,
                $this->currentUser
            ]);

            // Update cache
            $this->cache[$category][$name] = [
                'value' => $value,
                'type' => $type,
                'is_public' => $isPublic
            ];

            $this->db->commit();

            // Log the change
            $this->logSettingChange($category, $name, $value);

            return true;
        } catch (Exception $e) {
            $this->db->rollBack();
            error_log("Error updating setting: " . $e->getMessage());
            throw new Exception("Error updating system setting");
        }
    }

    public function delete($category, $name) {
        try {
            $stmt = $this->db->prepare("
                DELETE FROM settings 
                WHERE category = ? AND name = ?
            ");
            $stmt->execute([$category, $name]);

            // Update cache
            unset($this->cache[$category][$name]);

            return true;
        } catch (Exception $e) {
            error_log("Error deleting setting: " . $e->getMessage());
            throw new Exception("Error deleting system setting");
        }
    }

    public function getCategories() {
        return array_keys($this->cache);
    }

    public function getCategorySettings($category, $publicOnly = false) {
        if (!isset($this->cache[$category])) {
            return [];
        }

        if ($publicOnly) {
            return array_filter($this->cache[$category], function($setting) {
                return $setting['is_public'];
            });
        }

        return $this->cache[$category];
    }

    private function logSettingChange($category, $name, $value) {
        $auditLog = new AuditLog();
        $auditLog->log(
            'settings',
            'update',
            "Updated setting {$category}.{$name}",
            [
                'category' => $category,
                'name' => $name,
                'new_value' => $value
            ]
        );
    }

    public function backup() {
        try {
            $backup = [
                'timestamp' => $this->currentDateTime,
                'settings' => $this->cache
            ];

            $backupPath = 'backups/settings_' . date('Y-m-d_His') . '.json';
            file_put_contents($backupPath, json_encode($backup, JSON_PRETTY_PRINT));

            return $backupPath;
        } catch (Exception $e) {
            error_log("Error backing up settings: " . $e->getMessage());
            throw new Exception("Error creating settings backup");
        }
    }

    public function restore($backupFile) {
        try {
            $this->db->beginTransaction();

            $backup = json_decode(file_get_contents($backupFile), true);
            if (!$backup || !isset($backup['settings'])) {
                throw new Exception("Invalid backup file");
            }

            // Clear existing settings
            $stmt = $this->db->prepare("TRUNCATE TABLE settings");
            $stmt->execute();

            // Restore settings from backup
            foreach ($backup['settings'] as $category => $settings) {
                foreach ($settings as $name => $setting) {
                    $this->set(
                        $category,
                        $name,
                        $setting['value'],
                        $setting['type'],
                        $setting['is_public']
                    );
                }
            }

            $this->db->commit();
            $this->loadSettings(); // Reload cache

            return true;
        } catch (Exception $e) {
            $this->db->rollBack();
            error_log("Error restoring settings: " . $e->getMessage());
            throw new Exception("Error restoring settings from backup");
        }
    }
}