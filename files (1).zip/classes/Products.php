<?php
class Products {
    private $db;
    private $currentDateTime = '2025-02-16 15:54:01';
    private $currentUser = 'musty131311';

    public function __construct() {
        $this->db = Database::getInstance();
    }

    public function getAllProducts($filters = [], $page = 1, $limit = 10) {
        try {
            $conditions = [];
            $params = [];
            $sql = "SELECT p.*, c.name as category_name 
                    FROM products p 
                    LEFT JOIN categories c ON p.category_id = c.id 
                    WHERE 1=1";

            if (isset($filters['category_id'])) {
                $conditions[] = "p.category_id = ?";
                $params[] = $filters['category_id'];
            }

            if (isset($filters['status'])) {
                $conditions[] = "p.status = ?";
                $params[] = $filters['status'];
            }

            if (isset($filters['search'])) {
                $conditions[] = "(p.name LIKE ? OR p.sku LIKE ? OR p.barcode LIKE ?)";
                $searchTerm = "%{$filters['search']}%";
                $params[] = $searchTerm;
                $params[] = $searchTerm;
                $params[] = $searchTerm;
            }

            if (!empty($conditions)) {
                $sql .= " AND " . implode(" AND ", $conditions);
            }

            // Add sorting
            $sql .= " ORDER BY p.name ASC";

            // Add pagination
            $offset = ($page - 1) * $limit;
            $sql .= " LIMIT ? OFFSET ?";
            $params[] = $limit;
            $params[] = $offset;

            $stmt = $this->db->prepare($sql);
            $stmt->execute($params);

            return $stmt->fetchAll();
        } catch (Exception $e) {
            error_log("Error fetching products: " . $e->getMessage());
            throw new Exception("Error fetching products");
        }
    }

    public function getProduct($id) {
        try {
            $stmt = $this->db->prepare("
                SELECT p.*, c.name as category_name 
                FROM products p 
                LEFT JOIN categories c ON p.category_id = c.id 
                WHERE p.id = ?
            ");
            $stmt->execute([$id]);
            return $stmt->fetch();
        } catch (Exception $e) {
            error_log("Error fetching product: " . $e->getMessage());
            throw new Exception("Error fetching product details");
        }
    }

    public function addProduct($data) {
        try {
            $this->db->beginTransaction();

            $stmt = $this->db->prepare("
                INSERT INTO products (
                    name, description, category_id, sku, barcode, 
                    unit_price, cost_price, stock_quantity, reorder_level,
                    status, image, created_by, updated_by
                ) VALUES (
                    ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
                )
            ");

            $stmt->execute([
                $data['name'],
                $data['description'] ?? null,
                $data['category_id'] ?? null,
                $data['sku'],
                $data['barcode'] ?? null,
                $data['unit_price'],
                $data['cost_price'] ?? null,
                $data['stock_quantity'] ?? 0,
                $data['reorder_level'] ?? 0,
                $data['status'] ?? 'active',
                $data['image'] ?? null,
                $this->currentUser,
                $this->currentUser
            ]);

            $productId = $this->db->lastInsertId();

            // Log inventory transaction
            if (isset($data['stock_quantity']) && $data['stock_quantity'] > 0) {
                $this->logInventoryTransaction(
                    $productId,
                    'adjustment',
                    $data['stock_quantity'],
                    'Initial stock'
                );
            }

            $this->db->commit();
            return $productId;
        } catch (Exception $e) {
            $this->db->rollBack();
            error_log("Error adding product: " . $e->getMessage());
            throw new Exception("Error adding product");
        }
    }

    public function updateProduct($id, $data) {
        try {
            $this->db->beginTransaction();

            $currentProduct = $this->getProduct($id);
            if (!$currentProduct) {
                throw new Exception("Product not found");
            }

            $stmt = $this->db->prepare("
                UPDATE products SET 
                    name = ?,
                    description = ?,
                    category_id = ?,
                    sku = ?,
                    barcode = ?,
                    unit_price = ?,
                    cost_price = ?,
                    reorder_level = ?,
                    status = ?,
                    image = ?,
                    updated_by = ?,
                    updated_at = ?
                WHERE id = ?
            ");

            $stmt->execute([
                $data['name'],
                $data['description'] ?? null,
                $data['category_id'] ?? null,
                $data['sku'],
                $data['barcode'] ?? null,
                $data['unit_price'],
                $data['cost_price'] ?? null,
                $data['reorder_level'] ?? 0,
                $data['status'] ?? 'active',
                $data['image'] ?? $currentProduct['image'],
                $this->currentUser,
                $this->currentDateTime,
                $id
            ]);

            // Handle stock quantity changes
            if (isset($data['stock_quantity']) && 
                $data['stock_quantity'] !== $currentProduct['stock_quantity']) {
                $difference = $data['stock_quantity'] - $currentProduct['stock_quantity'];
                
                if ($difference !== 0) {
                    $this->updateStock($id, $difference, 'adjustment', 'Stock adjustment');
                }
            }

            $this->db->commit();
            return true;
        } catch (Exception $e) {
            $this->db->rollBack();
            error_log("Error updating product: " . $e->getMessage());
            throw new Exception("Error updating product");
        }
    }

    public function deleteProduct($id) {
        try {
            // Check if product can be deleted
            if (!$this->canDeleteProduct($id)) {
                throw new Exception("Cannot delete product with existing transactions");
            }

            $stmt = $this->db->prepare("DELETE FROM products WHERE id = ?");
            $stmt->execute([$id]);
            return true;
        } catch (Exception $e) {
            error_log("Error deleting product: " . $e->getMessage());
            throw new Exception("Error deleting product");
        }
    }

    private function canDeleteProduct($id) {
        // Check if product has any transactions
        $stmt = $this->db->prepare("
            SELECT COUNT(*) as count 
            FROM inventory_transactions 
            WHERE product_id = ?
        ");
        $stmt->execute([$id]);
        $result = $stmt->fetch();
        
        return $result['count'] == 0;
    }

    public function updateStock($productId, $quantity, $type, $notes = '') {
        try {
            $this->db->beginTransaction();

            // Update product stock
            $stmt = $this->db->prepare("
                UPDATE products 
                SET stock_quantity = stock_quantity + ?,
                    updated_at = ?,
                    updated_by = ?
                WHERE id = ?
            ");
            $stmt->execute([
                $quantity,
                $this->currentDateTime,
                $this->currentUser,
                $productId
            ]);

            // Log transaction
            $this->logInventoryTransaction($productId, $type, $quantity, $notes);

            $this->db->commit();
            return true;
        } catch (Exception $e) {
            $this->db->rollBack();
            error_log("Error updating stock: " . $e->getMessage());
            throw new Exception("Error updating stock");
        }
    }

    private function logInventoryTransaction($productId, $type, $quantity, $notes) {
        $stmt = $this->db->prepare("
            INSERT INTO inventory_transactions (
                product_id, type, quantity, notes, created_by
            ) VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $productId,
            $type,
            $quantity,
            $notes,
            $this->currentUser
        ]);
    }

    public function getInventoryTransactions($productId, $limit = 10) {
        try {
            $stmt = $this->db->prepare("
                SELECT it.*, p.name as product_name 
                FROM inventory_transactions it
                JOIN products p ON it.product_id = p.id
                WHERE it.product_id = ?
                ORDER BY it.created_at DESC
                LIMIT ?
            ");
            $stmt->execute([$productId, $limit]);
            return $stmt->fetchAll();
        } catch (Exception $e) {
            error_log("Error fetching inventory transactions: " . $e->getMessage());
            throw new Exception("Error fetching inventory transactions");
        }
    }

    public function getLowStockProducts() {
        try {
            $stmt = $this->db->prepare("
                SELECT p.*, c.name as category_name 
                FROM products p 
                LEFT JOIN categories c ON p.category_id = c.id 
                WHERE p.stock_quantity <= p.reorder_level 
                AND p.status = 'active'
                ORDER BY p.stock_quantity ASC
            ");
            $stmt->execute();
            return $stmt->fetchAll();
        } catch (Exception $e) {
            error_log("Error fetching low stock products: " . $e->getMessage());
            throw new Exception("Error fetching low stock products");
        }
    }

    public function searchProducts($term) {
        try {
            $stmt = $this->db->prepare("
                SELECT p.*, c.name as category_name 
                FROM products p 
                LEFT JOIN categories c ON p.category_id = c.id 
                WHERE p.name LIKE ? 
                OR p.sku LIKE ? 
                OR p.barcode LIKE ?
                ORDER BY p.name ASC
            ");
            
            $searchTerm = "%{$term}%";
            $stmt->execute([$searchTerm, $searchTerm, $searchTerm]);
            return $stmt->fetchAll();
        } catch (Exception $e) {
            error_log("Error searching products: " . $e->getMessage());
            throw new Exception("Error searching products");
        }
    }
}