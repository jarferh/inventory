<?php
class Customers {
    private $db;
    private $currentDateTime = '2025-02-16 15:57:50';
    private $currentUser = 'musty131311';

    public function __construct() {
        $this->db = Database::getInstance();
    }

    public function getAllCustomers($filters = [], $page = 1, $limit = 10) {
        try {
            $conditions = [];
            $params = [];
            $sql = "SELECT c.*, 
                    (SELECT COUNT(*) FROM sales WHERE customer_id = c.id) as total_sales,
                    (SELECT SUM(total_amount) FROM sales WHERE customer_id = c.id) as total_spent
                    FROM customers c 
                    WHERE 1=1";

            if (isset($filters['status'])) {
                $conditions[] = "c.status = ?";
                $params[] = $filters['status'];
            }

            if (isset($filters['search'])) {
                $conditions[] = "(c.name LIKE ? OR c.email LIKE ? OR c.phone LIKE ?)";
                $searchTerm = "%{$filters['search']}%";
                $params[] = $searchTerm;
                $params[] = $searchTerm;
                $params[] = $searchTerm;
            }

            if (!empty($conditions)) {
                $sql .= " AND " . implode(" AND ", $conditions);
            }

            // Add sorting
            $sql .= " ORDER BY c.name ASC";

            // Add pagination
            $offset = ($page - 1) * $limit;
            $sql .= " LIMIT ? OFFSET ?";
            $params[] = $limit;
            $params[] = $offset;

            $stmt = $this->db->prepare($sql);
            $stmt->execute($params);

            return $stmt->fetchAll();
        } catch (Exception $e) {
            error_log("Error fetching customers: " . $e->getMessage());
            throw new Exception("Error fetching customers");
        }
    }

    public function getCustomer($id) {
        try {
            $stmt = $this->db->prepare("
                SELECT c.*,
                    (SELECT COUNT(*) FROM sales WHERE customer_id = c.id) as total_sales,
                    (SELECT SUM(total_amount) FROM sales WHERE customer_id = c.id) as total_spent,
                    (SELECT MAX(sale_date) FROM sales WHERE customer_id = c.id) as last_purchase
                FROM customers c
                WHERE c.id = ?
            ");
            $stmt->execute([$id]);
            $customer = $stmt->fetch();

            if ($customer) {
                // Get recent sales
                $customer['recent_sales'] = $this->getCustomerRecentSales($id);
            }

            return $customer;
        } catch (Exception $e) {
            error_log("Error fetching customer: " . $e->getMessage());
            throw new Exception("Error fetching customer details");
        }
    }

    private function getCustomerRecentSales($customerId, $limit = 5) {
        $stmt = $this->db->prepare("
            SELECT s.*,
                COUNT(si.id) as total_items
            FROM sales s
            LEFT JOIN sale_items si ON s.id = si.sale_id
            WHERE s.customer_id = ?
            GROUP BY s.id
            ORDER BY s.sale_date DESC
            LIMIT ?
        ");
        $stmt->execute([$customerId, $limit]);
        return $stmt->fetchAll();
    }

    public function addCustomer($data) {
        try {
            $stmt = $this->db->prepare("
                INSERT INTO customers (
                    name, email, phone, address,
                    status, created_by, updated_by
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
            ");

            $stmt->execute([
                $data['name'],
                $data['email'] ?? null,
                $data['phone'] ?? null,
                $data['address'] ?? null,
                $data['status'] ?? 'active',
                $this->currentUser,
                $this->currentUser
            ]);

            return $this->db->lastInsertId();
        } catch (Exception $e) {
            error_log("Error adding customer: " . $e->getMessage());
            throw new Exception("Error adding customer");
        }
    }

    public function updateCustomer($id, $data) {
        try {
            $stmt = $this->db->prepare("
                UPDATE customers SET 
                    name = ?,
                    email = ?,
                    phone = ?,
                    address = ?,
                    status = ?,
                    updated_by = ?,
                    updated_at = ?
                WHERE id = ?
            ");

            $stmt->execute([
                $data['name'],
                $data['email'] ?? null,
                $data['phone'] ?? null,
                $data['address'] ?? null,
                $data['status'] ?? 'active',
                $this->currentUser,
                $this->currentDateTime,
                $id
            ]);

            return true;
        } catch (Exception $e) {
            error_log("Error updating customer: " . $e->getMessage());
            throw new Exception("Error updating customer");
        }
    }

    public function deleteCustomer($id) {
        try {
            // Check if customer has any sales
            $stmt = $this->db->prepare("
                SELECT COUNT(*) as count 
                FROM sales 
                WHERE customer_id = ?
            ");
            $stmt->execute([$id]);
            $result = $stmt->fetch();

            if ($result['count'] > 0) {
                throw new Exception("Cannot delete customer with existing sales");
            }

            $stmt = $this->db->prepare("DELETE FROM customers WHERE id = ?");
            $stmt->execute([$id]);

            return true;
        } catch (Exception $e) {
            error_log("Error deleting customer: " . $e->getMessage());
            throw new Exception($e->getMessage());
        }
    }

    public function getCustomerStats($customerId) {
        try {
            $stmt = $this->db->prepare("
                SELECT 
                    COUNT(*) as total_sales,
                    SUM(total_amount) as total_spent,
                    AVG(total_amount) as average_sale,
                    MAX(sale_date) as last_purchase,
                    MIN(sale_date) as first_purchase
                FROM sales
                WHERE customer_id = ?
            ");
            $stmt->execute([$customerId]);
            return $stmt->fetch();
        } catch (Exception $e) {
            error_log("Error fetching customer stats: " . $e->getMessage());
            throw new Exception("Error fetching customer statistics");
        }
    }

    public function searchCustomers($term) {
        try {
            $stmt = $this->db->prepare("
                SELECT * FROM customers
                WHERE name LIKE ? 
                OR email LIKE ? 
                OR phone LIKE ?
                ORDER BY name ASC
                LIMIT 10
            ");
            
            $searchTerm = "%{$term}%";
            $stmt->execute([$searchTerm, $searchTerm, $searchTerm]);
            return $stmt->fetchAll();
        } catch (Exception $e) {
            error_log("Error searching customers: " . $e->getMessage());
            throw new Exception("Error searching customers");
        }
    }

    public function getTopCustomers($limit = 10) {
        try {
             ▋