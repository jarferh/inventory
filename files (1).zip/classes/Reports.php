<?php
class Reports {
    private $db;
    private $currentDateTime = '2025-02-16 15:58:47';
    private $currentUser = 'musty131311';

    public function __construct() {
        $this->db = Database::getInstance();
    }

    public function getSalesReport($startDate, $endDate, $groupBy = 'daily') {
        try {
            $groupFormat = $this->getDateGroupFormat($groupBy);
            
            $sql = "
                SELECT 
                    DATE_FORMAT(s.sale_date, ?) as period,
                    COUNT(DISTINCT s.id) as total_sales,
                    COUNT(DISTINCT s.customer_id) as unique_customers,
                    SUM(s.total_amount) as total_revenue,
                    SUM(s.tax_amount) as total_tax,
                    SUM(s.discount_amount) as total_discounts,
                    AVG(s.total_amount) as average_sale_value,
                    SUM(si.quantity) as total_items_sold
                FROM sales s
                LEFT JOIN sale_items si ON s.id = si.sale_id
                WHERE s.sale_date BETWEEN ? AND ?
                GROUP BY period
                ORDER BY period ASC
            ";

            $stmt = $this->db->prepare($sql);
            $stmt->execute([$groupFormat, $startDate, $endDate]);
            
            return $stmt->fetchAll();
        } catch (Exception $e) {
            error_log("Error generating sales report: " . $e->getMessage());
            throw new Exception("Error generating sales report");
        }
    }

    private function getDateGroupFormat($groupBy) {
        return match($groupBy) {
            'hourly' => '%Y-%m-%d %H:00',
            'daily' => '%Y-%m-%d',
            'weekly' => '%Y-%u',
            'monthly' => '%Y-%m',
            'yearly' => '%Y',
            default => '%Y-%m-%d'
        };
    }

    public function getInventoryReport() {
        try {
            $sql = "
                SELECT 
                    p.*,
                    c.name as category_name,
                    (p.stock_quantity * p.cost_price) as stock_value,
                    (
                        SELECT SUM(quantity) 
                        FROM inventory_transactions 
                        WHERE product_id = p.id AND type = 'sale'
                        AND created_at >= DATE_SUB(?, INTERVAL 30 DAY)
                    ) as monthly_sales,
                    (
                        SELECT SUM(quantity) 
                        FROM inventory_transactions 
                        WHERE product_id = p.id AND type = 'purchase'
                        AND created_at >= DATE_SUB(?, INTERVAL 30 DAY)
                    ) as monthly_purchases
                FROM products p
                LEFT JOIN categories c ON p.category_id = c.id
                ORDER BY p.stock_quantity ASC
            ";

            $stmt = $this->db->prepare($sql);
            $stmt->execute([$this->currentDateTime, $this->currentDateTime]);
            
            return $stmt->fetchAll();
        } catch (Exception $e) {
            error_log("Error generating inventory report: " . $e->getMessage());
            throw new Exception("Error generating inventory report");
        }
    }

    public function getProfitReport($startDate, $endDate) {
        try {
            $sql = "
                SELECT 
                    DATE_FORMAT(s.sale_date, '%Y-%m-%d') as date,
                    SUM(s.total_amount) as total_revenue,
                    SUM(s.tax_amount) as total_tax,
                    SUM(s.discount_amount) as total_discounts,
                    SUM(si.quantity * p.cost_price) as total_cost,
                    SUM(s.total_amount) - SUM(si.quantity * p.cost_price) as gross_profit
                FROM sales s
                JOIN sale_items si ON s.id = si.sale_id
                JOIN products p ON si.product_id = p.id
                WHERE s.sale_date BETWEEN ? AND ?
                GROUP BY date
                ORDER BY date ASC
            ";

            $stmt = $this->db->prepare($sql);
            $stmt->execute([$startDate, $endDate]);
            
            return $stmt->fetchAll();
        } catch (Exception $e) {
            error_log("Error generating profit report: " . $e->getMessage());
            throw new Exception("Error generating profit report");
        }
    }

    public function getTopProducts($startDate, $endDate, $limit = 10) {
        try {
            $sql = "
                SELECT 
                    p.id,
                    p.name,
                    p.sku,
                    c.name as category_name,
                    SUM(si.quantity) as total_quantity_sold,
                    SUM(si.total_amount) as total_revenue,
                    COUNT(DISTINCT s.id) as number_of_sales
                FROM products p
                JOIN sale_items si ON p.id = si.product_id
                JOIN sales s ON si.sale_id = s.id
                LEFT JOIN categories c ON p.category_id = c.id
                WHERE s.sale_date BETWEEN ? AND ?
                GROUP BY p.id
                ORDER BY total_quantity_sold DESC
                LIMIT ?
            ";

            $stmt = $this->db->prepare($sql);
            $stmt->execute([$startDate, $endDate, $limit]);
            
            return $stmt->fetchAll();
        } catch (Exception $e) {
            error_log("Error generating top products report: " . $e->getMessage());
            throw new Exception("Error generating top products report");
        }
    }

    public function getCategoryPerformance($startDate, $endDate) {
        try {
            $sql = "
                SELECT 
                    c.id,
                    c.name,
                    COUNT(DISTINCT s.id) as total_sales,
                    SUM(si.quantity) as total_items_sold,
                    SUM(si.total_amount) as total_revenue,
                    AVG(si.unit_price) as average_price
                FROM categories c
                JOIN products p ON c.id = p.category_id
                JOIN sale_items si ON p.id = si.product_id
                JOIN sales s ON si.sale_id = s.id
                WHERE s.sale_date BETWEEN ? AND ?
                GROUP BY c.id
                ORDER BY total_revenue DESC
            ";

            $stmt = $this->db->prepare($sql);
            $stmt->execute([$startDate, $endDate]);
            
            return $stmt->fetchAll();
        } catch (Exception $e) {
            error_log("Error generating category performance report: " . $e->getMessage());
            throw new Exception("Error generating category performance report");
        }
    }

    public function getCustomerAnalytics() {
        try {
            $sql = "
                SELECT 
                    COUNT(DISTINCT c.id) as total_customers,
                    COUNT(DISTINCT CASE WHEN s.sale_date >= DATE_SUB(?, INTERVAL 30 DAY) THEN c.id END) as active_customers,
                    AVG(customer_totals.total_spent) as average_customer_value,
                    MAX(customer_totals.total_spent) as highest_customer_value
                FROM customers c
                LEFT JOIN sales s ON c.id = s.customer_id
                LEFT JOIN (
                    SELECT 
                        customer_id,
                        SUM(total_amount) as total_spent
                    FROM sales
                    GROUP BY customer_id
                ) customer_totals ON c.id = customer_totals.customer_id
            ";

            $stmt = $this->db->prepare($sql);
            $stmt->execute([$this->currentDateTime]);
            
            return $stmt->fetch();
        } catch (Exception $e) {
            error_log("Error generating customer analytics: " . $e->getMessage());
            throw new Exception("Error generating customer analytics");
        }
    }

    public function getInventoryAlerts() {
        try {
            $sql = "
                SELECT 
                    p.*,
                    c.name as category_name,
                    (
                        SELECT SUM(quantity) 
                        FROM inventory_transactions 
                        WHERE product_id = p.id 
                        AND type = 'sale'
                        AND created_at >= DATE_SUB(?, INTERVAL 30 DAY)
                    ) as monthly_usage
                FROM products p
                LEFT JOIN categories c ON p.category_id = c.id
                WHERE p.stock_quantity <= p.reorder_level
                ORDER BY (p.stock_quantity / p.reorder_level) ASC
            ";

            $stmt = $this->db->prepare($sql);
            $stmt->execute([$this->currentDateTime]);
            
            return $stmt->fetchAll();
        } catch (Exception $e) {
            error_log("Error generating inventory alerts: " . $e->getMessage());
            throw new Exception("Error generating inventory alerts");
        }
    }

    public function exportReport($type, $data, $format = 'csv') {
        try {
            switch($format) {
                case 'csv':
                    return $this->exportToCsv($type, $data);
                case 'pdf':
                    return $this->exportToPdf($type, $data);
                case 'excel':
                    return $this->exportToExcel($type, $data);
                default:
                    throw new Exception("Unsupported export format");
            }
        } catch (Exception $e) {
            error_log("Error exporting report: " . $e->getMessage());
            throw new Exception("Error exporting report");
        }
    }

    private function exportToCsv($type, $data) {
        // CSV export implementation
        // To be implemented based on specific requirements
    }

    private function exportToPdf($type, $data) {
        // PDF export implementation
        // To be implemented based on specific requirements
    }

    private function exportToExcel($type, $data) {
        // Excel export implementation
        // To be implemented based on specific requirements
    }
}