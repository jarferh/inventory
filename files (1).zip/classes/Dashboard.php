<?php
class Dashboard {
    private $db;
    private $currentDateTime = '2025-02-16 16:03:34';
    private $currentUser = 'musty131311';

    public function __construct() {
        $this->db = Database::getInstance();
    }

    public function getSummaryStats() {
        try {
            return [
                'sales' => $this->getSalesStats(),
                'inventory' => $this->getInventoryStats(),
                'customers' => $this->getCustomerStats(),
                'orders' => $this->getOrderStats()
            ];
        } catch (Exception $e) {
            error_log("Error fetching dashboard stats: " . $e->getMessage());
            throw new Exception("Error fetching dashboard statistics");
        }
    }

    private function getSalesStats() {
        // Get sales statistics for today, this week, and this month
        $stmt = $this->db->prepare("
            SELECT
                SUM(CASE WHEN DATE(sale_date) = CURRENT_DATE THEN total_amount ELSE 0 END) as today_sales,
                SUM(CASE WHEN sale_date >= DATE_SUB(CURRENT_DATE, INTERVAL 7 DAY) THEN total_amount ELSE 0 END) as weekly_sales,
                SUM(CASE WHEN sale_date >= DATE_SUB(CURRENT_DATE, INTERVAL 30 DAY) THEN total_amount ELSE 0 END) as monthly_sales,
                COUNT(CASE WHEN DATE(sale_date) = CURRENT_DATE THEN 1 END) as today_orders,
                AVG(total_amount) as average_order_value
            FROM sales
            WHERE sale_date >= DATE_SUB(CURRENT_DATE, INTERVAL 30 DAY)
        ");
        $stmt->execute();
        return $stmt->fetch();
    }

    private function getInventoryStats() {
        $stmt = $this->db->prepare("
            SELECT
                COUNT(*) as total_products,
                SUM(CASE WHEN stock_quantity <= reorder_level THEN 1 ELSE 0 END) as low_stock_items,
                SUM(stock_quantity * cost_price) as inventory_value,
                AVG(stock_quantity) as average_stock_level
            FROM products
            WHERE status = 'active'
        ");
        $stmt->execute();
        return $stmt->fetch();
    }

    private function getCustomerStats() {
        $stmt = $this->db->prepare("
            SELECT
                COUNT(*) as total_customers,
                COUNT(CASE WHEN created_at >= DATE_SUB(CURRENT_DATE, INTERVAL 30 DAY) THEN 1 END) as new_customers,
                (
                    SELECT COUNT(DISTINCT customer_id)
                    FROM sales
                    WHERE sale_date >= DATE_SUB(CURRENT_DATE, INTERVAL 30 DAY)
                ) as active_customers
            FROM customers
            WHERE status = 'active'
        ");
        $stmt->execute();
        return $stmt->fetch();
    }

    private function getOrderStats() {
        $stmt = $this->db->prepare("
            SELECT
                COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending_orders,
                COUNT(CASE WHEN status = 'processing' THEN 1 END) as processing_orders,
                COUNT(CASE WHEN payment_status = 'pending' THEN 1 END) as pending_payments,
                SUM(CASE WHEN payment_status = 'pending' THEN total_amount ELSE 0 END) as pending_amount
            FROM sales
            WHERE sale_date >= DATE_SUB(CURRENT_DATE, INTERVAL 30 DAY)
        ");
        $stmt->execute();
        return $stmt->fetch();
    }

    public function getChartData($type, $period = 30) {
        try {
            switch ($type) {
                case 'sales_trend':
                    return $this->getSalesTrend($period);
                case 'top_products':
                    return $this->getTopProducts($period);
                case 'category_distribution':
                    return $this->getCategoryDistribution();
                case 'daily_orders':
                    return $this->getDailyOrders($period);
                default:
                    throw new Exception("Invalid chart type");
            }
        } catch (Exception $e) {
            error_log("Error fetching chart data: " . $e->getMessage());
            throw new Exception("Error fetching chart data");
        }
    }

    private function getSalesTrend($days) {
        $stmt = $this->db->prepare("
            SELECT 
                DATE(sale_date) as date,
                COUNT(*) as total_orders,
                SUM(total_amount) as total_sales,
                AVG(total_amount) as average_sale
            FROM sales
            WHERE sale_date >= DATE_SUB(CURRENT_DATE, INTERVAL ? DAY)
            GROUP BY DATE(sale_date)
            ORDER BY date ASC
        ");
        $stmt->execute([$days]);
        return $stmt->fetchAll();
    }

    private function getTopProducts($days) {
        $stmt = $this->db->prepare("
            SELECT 
                p.name,
                SUM(si.quantity) as total_quantity,
                SUM(si.total_amount) as total_revenue
            FROM sale_items si
            JOIN products p ON si.product_id = p.id
            JOIN sales s ON si.sale_id = s.id
            WHERE s.sale_date >= DATE_SUB(CURRENT_DATE, INTERVAL ? DAY)
            GROUP BY p.id
            ORDER BY total_revenue DESC
            LIMIT 10
        ");
        $stmt->execute([$days]);
        return $stmt->fetchAll();
    }

    private function getCategoryDistribution() {
        $stmt = $this->db->prepare("
            SELECT 
                c.name,
                COUNT(p.id) as product_count,
                SUM(p.stock_quantity) as total_stock,
                SUM(p.stock_quantity * p.cost_price) as inventory_value
            FROM categories c
            LEFT JOIN products p ON c.id = p.category_id
            WHERE c.status = 'active'
            GROUP BY c.id
            ORDER BY inventory_value DESC
        ");
        $stmt->execute();
        return $stmt->fetchAll();
    }

    private function getDailyOrders($days) {
        $stmt = $this->db->prepare("
            SELECT 
                DATE(sale_date) as date,
                HOUR(sale_date) as hour,
                COUNT(*) as order_count
            FROM sales
            WHERE sale_date >= DATE_SUB(CURRENT_DATE, INTERVAL ? DAY)
            GROUP BY DATE(sale_date), HOUR(sale_date)
            ORDER BY date ASC, hour ASC
        ");
        $stmt->execute([$days]);
        return $stmt->fetchAll();
    }

    public function getRecentActivity() {
        $stmt = $this->db->prepare("
            SELECT 
                'sale' as type,
                id,
                sale_date as date,
                total_amount,
                status ▋