<?php
class Invoice {
    private $db;
    private $currentDateTime;
    private $currentUser;

    public function __construct() {
        $this->db = Database::getInstance();
        $this->currentDateTime = '2025-02-16 15:17:10';
        $this->currentUser = 'musty131311';
    }

    public function getSaleDetails($id) {
        // Get main sale information
        $sql = "SELECT 
                    s.*,
                    CONCAT('INV-', LPAD(s.id, 6, '0')) as invoice_number,
                    c.name as customer_name,
                    c.email as customer_email,
                    c.phone as customer_phone,
                    u.username as created_by
                FROM sales s
                LEFT JOIN customers c ON s.customer_id = c.id
                LEFT JOIN users u ON s.user_id = u.id
                WHERE s.id = ?";

        $stmt = $this->db->query($sql, [$id]);
        $sale = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$sale) {
            return null;
        }

        // Get sale items
        $sql = "SELECT 
                    si.*,
                    p.name,
                    p.description,
                    p.unit_price,
                    (si.quantity * si.unit_price) as total
                FROM sale_items si
                LEFT JOIN products p ON si.product_id = p.id
                WHERE si.sale_id = ?";

        $stmt = $this->db->query($sql, [$id]);
        $sale['items'] = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Calculate totals
        $sale['subtotal'] = array_sum(array_column($sale['items'], 'total'));
        $sale['vat'] = $sale['subtotal'] * 0.16;
        $sale['total'] = $sale['subtotal'] + $sale['vat'];

        return $sale;
    }

    public function generateInvoicePDF($id) {
        $sale = $this->getSaleDetails($id);
        if (!$sale) {
            throw new Exception('Sale not found');
        }

        // PDF generation logic here
        // You would typically use a library like TCPDF or FPDF
        
        return $pdfContent;
    }

    public function sendInvoiceEmail($data) {
        try {
            // Validate email
            if (!filter_var($data['recipient'], FILTER_VALIDATE_EMAIL)) {
                throw new Exception('Invalid email address');
            }

            // Generate PDF
            $pdfContent = $this->generateInvoicePDF($data['invoiceId']);

            // Log email attempt
            $sql = "INSERT INTO email_logs (
                        invoice_id, 
                        recipient, 
                        subject, 
                        message, 
                        sent_by, 
                        sent_at,
                        status
                    ) VALUES (?, ?, ?, ?, ?, ?, ?)";

            $this->db->query($sql, [
                $data['invoiceId'],
                $data['recipient'],
                $data['subject'],
                $data['message'],
                $this->currentUser,
                $this->currentDateTime,
                'pending'
            ]);

            $logId = $this->db->lastInsertId();

            // Send email
            $emailSent = $this->sendEmail([
                'to' => $data['recipient'],
                'subject' => $data['subject'],
                'message' => $data['message'],
                'attachment' => $pdfContent
            ]);

            // Update log status
            $sql = "UPDATE email_logs SET status = ? WHERE id = ?";
            $this->db->query($sql, [
                $emailSent ? 'sent' : 'failed',
                $logId
            ]);

            return $emailSent;

        } catch (Exception $e) {
            // Log error
            error_log("Invoice email error: " . $e->getMessage());
            throw $e;
        }
    }

    private function sendEmail($data) {
        // Implement email sending logic here
        // You would typically use PHPMailer or similar library
        
        return true; // Return success/failure
    }

    public function verifyInvoice($invoiceNumber) {
        $sql = "SELECT 
                    s.*,
                    CONCAT('INV-', LPAD(s.id, 6, '0')) as invoice_number
                FROM sales s
                WHERE CONCAT('INV-', LPAD(s.id, 6, '0')) = ?";

        $stmt = $this->db->query($sql, [$invoiceNumber]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function getEmailLogs($invoiceId) {
        $sql = "SELECT * FROM email_logs WHERE invoice_id = ? ORDER BY sent_at DESC";
        $stmt = $this->db->query($sql, [$invoiceId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}