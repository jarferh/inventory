<?php
class SystemInfo {
    const SYSTEM_VERSION = '1.0.0';
    const LAST_UPDATED = '2025-02-16 16:07:35';
    const LAST_UPDATED_BY = 'musty131311';
    
    const IMPLEMENTED_MODULES = [
        'core' => [
            'Products',
            'Categories',
            'Sales',
            'Customers',
            'Suppliers',
            'PurchaseOrders'
        ],
        'support' => [
            'Settings',
            'AuditLog',
            'Notifications',
            'Dashboard',
            'Backup'
        ]
    ];

    const DATABASE_TABLES = [
        'products',
        'categories',
        'sales',
        'sale_items',
        'customers',
        'suppliers',
        'purchases',
        'purchase_items',
        'inventory_transactions',
        'settings',
        'audit_logs',
        'notifications',
        'email_templates',
        'backup_logs'
    ];

    public static function getSystemStatus() {
        return [
            'version' => self::SYSTEM_VERSION,
            'last_updated' => self::LAST_UPDATED,
            'last_updated_by' => self::LAST_UPDATED_BY,
            'modules' => self::IMPLEMENTED_MODULES,
            'database_tables' => self::DATABASE_TABLES,
            'php_version' => PHP_VERSION,
            'server_info' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown'
        ];
    }
}