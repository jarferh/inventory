<?php
class Notifications {
    private $db;
    private $currentDateTime = '2025-02-16 16:03:34';
    private $currentUser = 'musty131311';
    private $mailer;
    private $settings;

    public function __construct() {
        $this->db = Database::getInstance();
        $this->settings = new Settings();
        $this->initializeMailer();
    }

    private function initializeMailer() {
        // Initialize PHP Mailer or other email service
        // This is a placeholder for email configuration
        $this->mailer = [
            'host' => $this->settings->get('email', 'smtp_host'),
            'port' => $this->settings->get('email', 'smtp_port'),
            'username' => $this->settings->get('email', 'smtp_username'),
            'password' => $this->settings->get('email', 'smtp_password'),
            'encryption' => $this->settings->get('email', 'smtp_encryption'),
            'from_email' => $this->settings->get('email', 'from_email'),
            'from_name' => $this->settings->get('email', 'from_name')
        ];
    }

    public function send($to, $subject, $template, $data = [], $attachments = []) {
        try {
            // Get template content
            $templateContent = $this->getEmailTemplate($template);
            
            // Replace placeholders with data
            $content = $this->parseTemplate($templateContent, $data);

            // Log notification attempt
            $notificationId = $this->logNotification($to, $subject, $template, $data);

            // Send email (placeholder for actual email sending logic)
            $success = $this->sendEmail($to, $subject, $content, $attachments);

            // Update notification status
            $this->updateNotificationStatus($notificationId, $success);

            return $success;
        } catch (Exception $e) {
            error_log("Error sending notification: " . $e->getMessage());
            throw new Exception("Error sending notification");
        }
    }

    private function getEmailTemplate($templateName) {
        $stmt = $this->db->prepare("
            SELECT content 
            FROM email_templates 
            WHERE name = ? AND status = 'active'
        ");
        $stmt->execute([$templateName]);
        $template = $stmt->fetch();

        if (!$template) {
            throw new Exception("Email template not found: " . $templateName);
        }

        return $template['content'];
    }

    private function parseTemplate($content, $data) {
        foreach ($data as $key => $value) {
            $content = str_replace('{{' . $key . '}}', $value, $content);
        }
        return $content;
    }

    private function logNotification($to, $subject, $template, $data) {
        $stmt = $this->db->prepare("
            INSERT INTO notifications (
                recipient, subject, template,
                data, status, created_by,
                created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
        ");

        $stmt->execute([
            $to,
            $subject,
            $template,
            json_encode($data),
            'pending',
            $this->currentUser,
            $this->currentDateTime
        ]);

        return $this->db->lastInsertId();
    }

    private function updateNotificationStatus($id, $success) {
        $stmt = $this->db->prepare("
            UPDATE notifications 
            SET status = ?,
                sent_at = ?,
                updated_at = ?,
                updated_by = ?
            WHERE id = ?
        ");

        $stmt->execute([
            $success ? 'sent' : 'failed',
            $success ? $this->currentDateTime : null,
            $this->currentDateTime,
            $this->currentUser,
            $id
        ]);
    }

    private function sendEmail($to, $subject, $content, $attachments) {
        // Placeholder for actual email sending implementation
        // This should be replaced with actual email sending logic
        // using PHP Mailer or other email service
        return true;
    }
}