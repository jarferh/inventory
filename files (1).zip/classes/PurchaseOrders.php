<?php
class PurchaseOrders {
    private $db;
    private $currentDateTime = '2025-02-16 16:01:15';
    private $currentUser = 'musty131311';

    public function __construct() {
        $this->db = Database::getInstance();
    }

    public function createPurchaseOrder($data) {
        try {
            $this->db->beginTransaction();

            // Generate order number
            $orderNumber = $this->generateOrderNumber();

            // Calculate totals
            $subtotal = 0;
            foreach ($data['items'] as $item) {
                $subtotal += $item['quantity'] * $item['unit_price'];
            }

            $taxAmount = $subtotal * ($this->getTaxRate() / 100);
            $totalAmount = $subtotal + $taxAmount;

            // Insert purchase order
            $stmt = $this->db->prepare("
                INSERT INTO purchases (
                    supplier_id, order_number, order_date,
                    expected_delivery, subtotal, tax_amount,
                    total_amount, status, payment_status,
                    notes, created_by, updated_by
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");

            $stmt->execute([
                $data['supplier_id'],
                $orderNumber,
                $this->currentDateTime,
                $data['expected_delivery'] ?? null,
                $subtotal,
                $taxAmount,
                $totalAmount,
                $data['status'] ?? 'pending',
                $data['payment_status'] ?? 'pending',
                $data['notes'] ?? null,
                $this->currentUser,
                $this->currentUser
            ]);

            $purchaseId = $this->db->lastInsertId();

            // Insert purchase items
            foreach ($data['items'] as $item) {
                $this->addPurchaseItem($purchaseId, $item);
            }

            $this->db->commit();

            // Send notifications
            $this->sendPurchaseOrderNotifications($purchaseId);

            return [
                'purchase_id' => $purchaseId,
                'order_number' => $orderNumber,
                'total_amount' => $totalAmount
            ];
        } catch (Exception $e) {
            $this->db->rollBack();
            error_log("Error creating purchase order: " . $e->getMessage());
            throw new Exception("Error creating purchase order");
        }
    }

    private function addPurchaseItem($purchaseId, $item) {
        $totalAmount = $item['quantity'] * $item['unit_price'];

        $stmt = $this->db->prepare("
            INSERT INTO purchase_items (
                purchase_id, product_id, quantity,
                unit_price, total_amount
            ) VALUES (?, ?, ?, ?, ?)
        ");

        $stmt->execute([
            $purchaseId,
            $item['product_id'],
            $item['quantity'],
            $item['unit_price'],
            $totalAmount
        ]);
    }

    private function generateOrderNumber() {
        $prefix = $this->getSetting('purchase_order_prefix', 'PO-');
        $nextNumber = $this->getSetting('next_po_number', '1');

        // Update next PO number
        $this->updateSetting('next_po_number', $nextNumber + 1);

        return $prefix . str_pad($nextNumber, 6, '0', STR_PAD_LEFT);
    }

    public function getPurchaseOrder($id) {
        try {
            $stmt = $this->db->prepare("
                SELECT p.*,
                    s.name as supplier_name,
                    s.email as supplier_email,
                    s.phone as supplier_phone,
                    s.contact_person as supplier_contact
                FROM purchases p
                LEFT JOIN suppliers s ON p.supplier_id = s.id
                WHERE p.id = ?
            ");
            $stmt->execute([$id]);
            $purchase = $stmt->fetch();

            if (!$purchase) {
                return null;
            }

            // Get purchase items
            $purchase['items'] = $this->getPurchaseItems($id);

            return $purchase;
        } catch (Exception $e) {
            error_log("Error fetching purchase order: " . $e->getMessage());
            throw new Exception("Error fetching purchase order details");
        }
    }

    private function getPurchaseItems($purchaseId) {
        $stmt = $this->db->prepare("
            SELECT pi.*,
                p.name as product_name,
                p.sku as product_sku
            FROM purchase_items pi
            JOIN products p ON pi.product_id = p.id
            WHERE pi.purchase_id = ?
        ");
        $stmt->execute([$purchaseId]);
        return $stmt->fetchAll();
    }

    public function updatePurchaseOrder($id, $data) {
        try {
            $this->db->beginTransaction();

            $purchase = $this->getPurchaseOrder($id);
            if (!$purchase) {
                throw new Exception("Purchase order not found");
            }

            // Update main purchase order
            $stmt = $this->db->prepare("
                UPDATE purchases SET 
                    expected_delivery = ?,
                    status = ?,
                    payment_status = ?,
                    notes = ?,
                    updated_by = ?,
                    updated_at = ?
                WHERE id = ?
            ");

            $stmt->execute([
                $data['expected_delivery'] ?? $purchase['expected_delivery'],
                $data['status'] ?? $purchase['status'],
                $data['payment_status'] ?? $purchase['payment_status'],
                $data['notes'] ?? $purchase['notes'],
                $this->currentUser,
                $this->currentDateTime,
                $id
            ]);

            // Handle status changes
            if (isset($data['status']) && $data['status'] === 'received') {
                $this->processPurchaseOrderReceipt($id);
            }

            $this->db->commit();

            // Send notifications for status changes
            $this->sendStatusChangeNotifications($id, $purchase['status'], $data['status'] ?? $purchase['status']);

            return true;
        } catch (Exception $e) {
            $this->db->rollBack();
            error_log("Error updating purchase order: " . $e->getMessage());
            throw new Exception("Error updating purchase order");
        }
    }

    private function processPurchaseOrderReceipt($purchaseId) {
        $items = $this->getPurchaseItems($purchaseId);
        
        foreach ($items as $item) {
            // Update product stock
            $stmt = $this->db->prepare("
                UPDATE products 
                SET stock_quantity = stock_quantity + ?,
                    updated_at = ?,
                    updated_by = ?
                WHERE id = ?
            ");

            $stmt->execute([
                $item['quantity'],
                $this->currentDateTime,
                $this->currentUser,
                $item['product_id']
            ]);

            // Log inventory transaction
            $stmt = $this->db->prepare("
                INSERT INTO inventory_transactions (
                    product_id, type, quantity, reference_id,
                    notes, created_by
                ) VALUES (?, ?, ?, ?, ?, ?)
            ");

            $stmt->execute([
                $item['product_id'],
                'purchase',
                $item['quantity'],
                $purchaseId,
                "Purchase Order #{$purchaseId} received",
                $this->currentUser
            ]);
        }
    }

    public function deletePurchaseOrder($id) {
        try {
            $purchase = $this->getPurchaseOrder($id);
            if (!$purchase || $purchase['status'] !== 'pending') {
                throw new Exception("Only pending purchase orders can be deleted");
            }

            $stmt = $this->db->prepare("DELETE FROM purchases WHERE id = ?");
            $stmt->execute([$id]);

            return true;
        } catch (Exception $e) {
            error_log("Error deleting purchase order: " . $e->getMessage());
            throw new Exception($e->getMessage());
        }
    }

    private function sendPurchaseOrderNotifications($purchaseId) {
        // Implementation depends on notification system
        // This is a placeholder for the notification logic
    }

    private function sendStatusChangeNotifications($purchaseId, $oldStatus, $newStatus) {
        // Implementation depends on notification system
        // This is a placeholder for the notification logic
    }

    private function getTaxRate() {
        return (float) $this->getSetting('purchase_tax_rate', '16.0');
    }

    private function getSetting($key, $default = null) {
        $stmt = $this->db->prepare("
            SELECT value 
            FROM settings 
            WHERE name = ?
        ");
        $stmt->execute([$key]);
        $result = $stmt->fetch();

        return $result ? $result['value'] : $default;
    }

    private function updateSetting($key, $value) {
        $stmt = $this->db->prepare("
            UPDATE settings 
            SET value = ?,
                updated_at =  ▋