<?php
class Auth {
    private $db;
    private $currentDateTime = '2025-02-16 15:52:12';
    private $currentUser = 'musty131311';

    public function __construct() {
        $this->db = Database::getInstance();
    }

    public function login($username, $password) {
        try {
            $stmt = $this->db->prepare("SELECT * FROM users WHERE username = ?");
            $stmt->execute([$username]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user && password_verify($password, $user['password'])) {
                if ($user['status'] === 'locked') {
                    throw new Exception('Account is locked. Please contact administrator.');
                }

                // Reset failed attempts on successful login
                $this->resetFailedAttempts($user['id']);

                // Create session
                Session::set('user_id', $user['id']);
                Session::set('username', $user['username']);
                Session::set('role_id', $user['role_id']);

                // Update last login
                $this->updateLastLogin($user['id']);

                // Log activity
                $this->logActivity($user['id'], 'login', 'User logged in successfully');

                return true;
            }

            // Increment failed attempts
            $this->incrementFailedAttempts($username);
            
            return false;
        } catch (Exception $e) {
            error_log("Login error: " . $e->getMessage());
            throw $e;
        }
    }

    private function resetFailedAttempts($userId) {
        $stmt = $this->db->prepare("UPDATE users SET failed_attempts = 0 WHERE id = ?");
        $stmt->execute([$userId]);
    }

    private function incrementFailedAttempts($username) {
        $stmt = $this->db->prepare("
            UPDATE users 
            SET failed_attempts = failed_attempts + 1,
                status = CASE 
                    WHEN failed_attempts >= 5 THEN 'locked'
                    ELSE status 
                END
            WHERE username = ?
        ");
        $stmt->execute([$username]);
    }

    private function updateLastLogin($userId) {
        $stmt = $this->db->prepare("
            UPDATE users 
            SET last_login = ?, 
                last_active = ?,
                ip_address = ?
            WHERE id = ?
        ");
        $stmt->execute([
            $this->currentDateTime,
            $this->currentDateTime,
            $_SERVER['REMOTE_ADDR'],
            $userId
        ]);
    }

    private function logActivity($userId, $type, $description) {
        $stmt = $this->db->prepare("
            INSERT INTO activity_logs 
            (user_id, type, action, description, ip_address, user_agent) 
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $userId,
            $type,
            'login',
            $description,
            $_SERVER['REMOTE_ADDR'],
            $_SERVER['HTTP_USER_AGENT']
        ]);
    }

    public function logout() {
        if (Session::isLoggedIn()) {
            $userId = Session::get('user_id');
            
            // Log activity before destroying session
            $this->logActivity($userId, 'logout', 'User logged out');
            
            Session::destroy();
        }
    }

    public function checkPermission($permission) {
        if (!Session::isLoggedIn()) {
            return false;
        }

        $roleId = Session::get('role_id');
        
        $stmt = $this->db->prepare("SELECT permissions FROM roles WHERE id = ?");
        $stmt->execute([$roleId]);
        $role = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$role) {
            return false;
        }

        $permissions = json_decode($role['permissions'], true);

        // Check if user has all permissions
        if (isset($permissions['all']) && $permissions['all'] === true) {
            return true;
        }

        // Check specific permission
        $parts = explode('.', $permission);
        $current = $permissions;

        foreach ($parts as $part) {
            if (!isset($current[$part])) {
                return false;
            }
            $current = $current[$part];
        }

        return $current === true;
    }

    public function updatePassword($userId, $currentPassword, $newPassword) {
        try {
            $stmt = $this->db->prepare("SELECT password FROM users WHERE id = ?");
            $stmt->execute([$userId]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$user || !password_verify($currentPassword, $user['password'])) {
                throw new Exception('Current password is incorrect');
            }

            $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
            
            $stmt = $this->db->prepare("
                UPDATE users 
                SET password = ?,
                    updated_at = ?,
                    updated_by = ?
                WHERE id = ?
            ");
            $stmt->execute([
                $hashedPassword,
                $this->currentDateTime,
                $this->currentUser,
                $userId
            ]);

            $this->logActivity($userId, 'password', 'Password updated successfully');
            
            return true;
        } catch (Exception $e) {
            error_log("Password update error: " . $e->getMessage());
            throw $e;
        }
    }

    public function resetPassword($email) {
        try {
            $stmt = $this->db->prepare("SELECT id, name FROM users WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$user) {
                throw new Exception('Email address not found');
            }

            // Generate reset token
            $token = bin2hex(random_bytes(32));
            $expiry = date('Y-m-d H:i:s', strtotime('+1 hour'));

            $stmt = $this->db->prepare("
                UPDATE users 
                SET reset_token = ?,
                    reset_token_expiry = ?,
                    updated_at = ?,
                    updated_by = ?
                WHERE id = ?
            ");
            $stmt->execute([
                $token,
                $expiry,
                $this->currentDateTime,
                'system',
                $user['id']
            ]);

            // Send reset email
            $this->sendPasswordResetEmail($user['name'], $email, $token);

            $this->logActivity($user['id'], 'password', 'Password reset requested');
            
            return true;
        } catch (Exception $e) {
            error_log("Password reset error: " . $e->getMessage());
            throw $e;
        }
    }

    private function sendPasswordResetEmail($name, $email, $token) {
        // Implementation depends on your email service provider
        // This is a placeholder for the email sending logic
        $resetLink = "http://yourdomain.com/reset-password?token=" . $token;
        $to = $email;
        $subject = "Password Reset Request";
        $message = "Hello " . $name . ",\n\n";
        $message .= "You have requested to reset your password. Click the link below to proceed:\n\n";
        $message .= $resetLink . ▋