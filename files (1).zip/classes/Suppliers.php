<?php
class Suppliers {
    private $db;
    private $currentDateTime = '2025-02-16 16:00:20';
    private $currentUser = 'musty131311';

    public function __construct() {
        $this->db = Database::getInstance();
    }

    public function getAllSuppliers($filters = [], $page = 1, $limit = 10) {
        try {
            $conditions = [];
            $params = [];
            $sql = "SELECT s.*, 
                    (SELECT COUNT(*) FROM purchases WHERE supplier_id = s.id) as total_purchases,
                    (SELECT SUM(total_amount) FROM purchases WHERE supplier_id = s.id) as total_spent
                    FROM suppliers s 
                    WHERE 1=1";

            if (isset($filters['status'])) {
                $conditions[] = "s.status = ?";
                $params[] = $filters['status'];
            }

            if (isset($filters['search'])) {
                $conditions[] = "(s.name LIKE ? OR s.email LIKE ? OR s.phone LIKE ?)";
                $searchTerm = "%{$filters['search']}%";
                $params[] = $searchTerm;
                $params[] = $searchTerm;
                $params[] = $searchTerm;
            }

            if (!empty($conditions)) {
                $sql .= " AND " . implode(" AND ", $conditions);
            }

            $sql .= " ORDER BY s.name ASC";

            // Add pagination
            $offset = ($page - 1) * $limit;
            $sql .= " LIMIT ? OFFSET ?";
            $params[] = $limit;
            $params[] = $offset;

            $stmt = $this->db->prepare($sql);
            $stmt->execute($params);

            return $stmt->fetchAll();
        } catch (Exception $e) {
            error_log("Error fetching suppliers: " . $e->getMessage());
            throw new Exception("Error fetching suppliers");
        }
    }

    public function getSupplier($id) {
        try {
            $stmt = $this->db->prepare("
                SELECT s.*,
                    (SELECT COUNT(*) FROM purchases WHERE supplier_id = s.id) as total_purchases,
                    (SELECT SUM(total_amount) FROM purchases WHERE supplier_id = s.id) as total_spent,
                    (SELECT MAX(order_date) FROM purchases WHERE supplier_id = s.id) as last_order
                FROM suppliers s
                WHERE s.id = ?
            ");
            $stmt->execute([$id]);
            $supplier = $stmt->fetch();

            if ($supplier) {
                // Get recent purchases
                $supplier['recent_purchases'] = $this->getSupplierRecentPurchases($id);
            }

            return $supplier;
        } catch (Exception $e) {
            error_log("Error fetching supplier: " . $e->getMessage());
            throw new Exception("Error fetching supplier details");
        }
    }

    private function getSupplierRecentPurchases($supplierId, $limit = 5) {
        $stmt = $this->db->prepare("
            SELECT p.*,
                COUNT(pi.id) as total_items
            FROM purchases p
            LEFT JOIN purchase_items pi ON p.id = pi.purchase_id
            WHERE p.supplier_id = ?
            GROUP BY p.id
            ORDER BY p.order_date DESC
            LIMIT ?
        ");
        $stmt->execute([$supplierId, $limit]);
        return $stmt->fetchAll();
    }

    public function addSupplier($data) {
        try {
            $stmt = $this->db->prepare("
                INSERT INTO suppliers (
                    name, email, phone, address,
                    contact_person, status, created_by, updated_by
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ");

            $stmt->execute([
                $data['name'],
                $data['email'] ?? null,
                $data['phone'] ?? null,
                $data['address'] ?? null,
                $data['contact_person'] ?? null,
                $data['status'] ?? 'active',
                $this->currentUser,
                $this->currentUser
            ]);

            return $this->db->lastInsertId();
        } catch (Exception $e) {
            error_log("Error adding supplier: " . $e->getMessage());
            throw new Exception("Error adding supplier");
        }
    }

    public function updateSupplier($id, $data) {
        try {
            $stmt = $this->db->prepare("
                UPDATE suppliers SET 
                    name = ?,
                    email = ?,
                    phone = ?,
                    address = ?,
                    contact_person = ?,
                    status = ?,
                    updated_by = ?,
                    updated_at = ?
                WHERE id = ?
            ");

            $stmt->execute([
                $data['name'],
                $data['email'] ?? null,
                $data['phone'] ?? null,
                $data['address'] ?? null,
                $data['contact_person'] ?? null,
                $data['status'] ?? 'active',
                $this->currentUser,
                $this->currentDateTime,
                $id
            ]);

            return true;
        } catch (Exception $e) {
            error_log("Error updating supplier: " . $e->getMessage());
            throw new Exception("Error updating supplier");
        }
    }

    public function deleteSupplier($id) {
        try {
            // Check if supplier has any purchases
            $stmt = $this->db->prepare("
                SELECT COUNT(*) as count 
                FROM purchases 
                WHERE supplier_id = ?
            ");
            $stmt->execute([$id]);
            $result = $stmt->fetch();

            if ($result['count'] > 0) {
                throw new Exception("Cannot delete supplier with existing purchases");
            }

            $stmt = $this->db->prepare("DELETE FROM suppliers WHERE id = ?");
            $stmt->execute([$id]);

            return true;
        } catch (Exception $e) {
            error_log("Error deleting supplier: " . $e->getMessage());
            throw new Exception($e->getMessage());
        }
    }

    public function getSupplierStats($supplierId) {
        try {
            $stmt = $this->db->prepare("
                SELECT 
                    COUNT(*) as total_purchases,
                    SUM(total_amount) as total_spent,
                    AVG(total_amount) as average_purchase,
                    MAX(order_date) as last_order,
                    MIN(order_date) as first_order,
                    COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending_orders,
                    SUM(CASE WHEN payment_status = 'pending' THEN total_amount ELSE 0 END) as pending_payments
                FROM purchases
                WHERE supplier_id = ?
            ");
            $stmt->execute([$supplierId]);
            return $stmt->fetch();
        } catch (Exception $e) {
            error_log("Error fetching supplier stats: " . $e->getMessage());
            throw new Exception("Error fetching supplier statistics");
        }
    }

    public function searchSuppliers($term) {
        try {
            $stmt = $this->db->prepare("
                SELECT * FROM suppliers
                WHERE name LIKE ? 
                OR email LIKE ? 
                OR phone LIKE ?
                ORDER BY name ASC
                LIMIT 10
            ");
            
            $searchTerm = "%{$term}%";
            $stmt->execute([$searchTerm, $searchTerm, $searchTerm]);
            return $stmt->fetchAll();
        } catch (Exception $e) {
            error_log("Error searching suppliers: " . $e->getMessage());
            throw new Exception("Error searching suppliers");
        }
    }

    public function getTopSuppliers($limit = 10) {
        try {
            $stmt = $this->db->prepare("
                SELECT 
                    s.*,
                     ▋