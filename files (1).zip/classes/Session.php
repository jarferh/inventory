<?php
class Session {
    private static $currentDateTime = '2025-02-16 15:53:09';
    private static $currentUser = 'musty131311';

    public static function init() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
    }

    public static function set($key, $value) {
        $_SESSION[$key] = $value;
    }

    public static function get($key) {
        return $_SESSION[$key] ?? null;
    }

    public static function destroy() {
        session_destroy();
    }

    public static function unset($key) {
        unset($_SESSION[$key]);
    }

    public static function isLoggedIn() {
        return isset($_SESSION['user_id']);
    }

    public static function hasPermission($permission) {
        if (!self::isLoggedIn()) {
            return false;
        }

        // Get user's role permissions
        $db = Database::getInstance();
        $stmt = $db->prepare("
            SELECT r.permissions 
            FROM roles r 
            JOIN users u ON u.role_id = r.id 
            WHERE u.id = ?
        ");
        $stmt->execute([self::get('user_id')]);
        $role = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$role) {
            return false;
        }

        $permissions = json_decode($role['permissions'], true);

        // Check for full access
        if (isset($permissions['all']) && $permissions['all'] === true) {
            return true;
        }

        // Check specific permission
        $parts = explode('.', $permission);
        $current = $permissions;

        foreach ($parts as $part) {
            if (!isset($current[$part])) {
                return false;
            }
            $current = $current[$part];
        }

        return $current === true;
    }

    public static function regenerateId() {
        session_regenerate_id(true);
    }

    public static function setFlash($key, $message) {
        $_SESSION['flash'][$key] = $message;
    }

    public static function getFlash($key) {
        if (isset($_SESSION['flash'][$key])) {
            $message = $_SESSION['flash'][$key];
            unset($_SESSION['flash'][$key]);
            return $message;
        }
        return null;
    }

    public static function hasFlash($key) {
        return isset($_SESSION['flash'][$key]);
    }

    public static function updateActivity() {
        if (self::isLoggedIn()) {
            $db = Database::getInstance();
            $stmt = $db->prepare("
                UPDATE users 
                SET last_active = ?, 
                    ip_address = ? 
                WHERE id = ?
            ");
            $stmt->execute([
                self::$currentDateTime,
                $_SERVER['REMOTE_ADDR'],
                self::get('user_id')
            ]);
        }
    }

    public static function getLastActivity() {
        return $_SESSION['last_activity'] ?? null;
    }

    public static function setTimeout($timeout = 1800) {
        $_SESSION['timeout'] = $timeout;
    }

    public static function checkTimeout() {
        if (self::isLoggedIn()) {
            $lastActivity = self::getLastActivity();
            $timeout = $_SESSION[' ▋