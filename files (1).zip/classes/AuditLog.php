<?php
class AuditLog {
    private $db;
    private $currentDateTime = '2025-02-16 16:02:22';
    private $currentUser = 'musty131311';

    public function __construct() {
        $this->db = Database::getInstance();
    }

    public function log($module, $action, $description, $data = []) {
        try {
            $stmt = $this->db->prepare("
                INSERT INTO audit_logs (
                    user_id, module, action, description,
                    data, ip_address, user_agent,
                    created_at
                ) VALUES (
                    (SELECT id FROM users WHERE username = ?),
                    ?, ?, ?, ?, ?, ?, ?
                )
            ");

            $stmt->execute([
                $this->currentUser,
                $module,
                $action,
                $description,
                json_encode($data),
                $_SERVER['REMOTE_ADDR'] ?? null,
                $_SERVER['HTTP_USER_AGENT'] ?? null,
                $this->currentDateTime
            ]);

            return $this->db->lastInsertId();
        } catch (Exception $e) {
            error_log("Error creating audit log: " . $e->getMessage());
            // Don't throw exception - logging should not interrupt main operation
            return false;
        }
    }

    public function getAuditLogs($filters = [], $page = 1, $limit = 50) {
        try {
            $conditions = [];
            $params = [];
            $sql = "
                SELECT al.*,
                    u.username,
                    u.name as user_name
                FROM audit_logs al
                LEFT JOIN users u ON al.user_id = u.id
                WHERE 1=1
            ";

            if (isset($filters['module'])) {
                $conditions[] = "al.module = ?";
                $params[] = $filters['module'];
            }

            if (isset($filters['action'])) {
                $conditions[] = "al.action = ?";
                $params[] = $filters['action'];
            }

            if (isset($filters['user_id'])) {
                $conditions[] = "al.user_id = ?";
                $params[] = $filters['user_id'];
            }

            if (isset($filters['start_date'])) {
                $conditions[] = "al.created_at >= ?";
                $params[] = $filters['start_date'];
            }

            if (isset($filters['end_date'])) {
                $conditions[] = "al.created_at <= ?";
                $params[] = $filters['end_date'];
            }

            if (!empty($conditions)) {
                $sql .= " AND " . implode(" AND ", $conditions);
            }

            $sql .= " ORDER BY al.created_at DESC";

            // Add pagination
            $offset = ($page - 1) * $limit;
            $sql .= " LIMIT ? OFFSET ?";
            $params[] = $limit;
            $params[] = $offset;

            $stmt = $this->db->prepare($sql);
            $stmt->execute($params);

            return $stmt->fetchAll();
        } catch (Exception $e) {
            error_log("Error fetching audit logs: " . $e->getMessage());
            throw new Exception("Error fetching audit logs");
        }
    }

    public function getAuditLog($id) {
        try {
            $stmt = $this->db->prepare("
                SELECT al.*,
                    u.username,
                    u.name as user_name
                FROM audit_logs al
                LEFT JOIN users u ON al.user_id = u.id
                WHERE al.id = ?
            ");
            $stmt->execute([$id]);
            return $stmt->fetch();
        } catch (Exception $e) {
            error_log("Error fetching audit log: " . $e->getMessage());
            throw new Exception("Error fetching audit log details");
        }
    }

    public function exportAuditLogs($filters = []) {
        try {
            $logs = $this->getAuditLogs($filters, 1, PHP_INT_MAX);
            
            $filename = 'audit_logs_' . date('Y-m-d_His') . '.csv';
            $filepath = 'exports/' . $filename;

            $fp = fopen($filepath, 'w');
            
            // Write CSV header
            fputcsv($fp, [
                'ID',
                'Timestamp',
                'Username',
                'Module',
                'Action',
                'Description',
                'IP Address',
                'User Agent'
            ]);

            // Write data
            foreach ($logs as $log) {
                fputcsv($fp, [
                    $log['id'],
                    $log['created_at'],
                    $log['username'],
                    $log['module'],
                    $log['action'],
                     ▋