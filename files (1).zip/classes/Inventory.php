<?php
class Inventory {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    public function addProduct($data) {
        $sql = "INSERT INTO products (name, sku, category, description, unit_price, 
                stock_quantity, reorder_level) VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        return $this->db->query($sql, [
            $data['name'],
            $data['sku'],
            $data['category'],
            $data['description'],
            $data['unit_price'],
            $data['stock_quantity'],
            $data['reorder_level']
        ]);
    }
    
    public function updateProduct($id, $data) {
        $sql = "UPDATE products SET 
                name = ?, 
                category = ?, 
                description = ?, 
                unit_price = ?, 
                stock_quantity = ?, 
                reorder_level = ? 
                WHERE id = ?";
        
        return $this->db->query($sql, [
            $data['name'],
            $data['category'],
            $data['description'],
            $data['unit_price'],
            $data['stock_quantity'],
            $data['reorder_level'],
            $id
        ]);
    }
    
    public function deleteProduct($id) {
        $sql = "DELETE FROM products WHERE id = ?";
        return $this->db->query($sql, [$id]);
    }
    
    public function getProduct($id) {
        $sql = "SELECT * FROM products WHERE id = ?";
        $stmt = $this->db->query($sql, [$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    public function getAllProducts() {
        $sql = "SELECT * FROM products ORDER BY name";
        $stmt = $this->db->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function updateStock($id, $quantity, $type = 'add') {
        $product = $this->getProduct($id);
        if (!$product) return false;
        
        $newQuantity = $type === 'add' 
            ? $product['stock_quantity'] + $quantity
            : $product['stock_quantity'] - $quantity;
        
        $sql = "UPDATE products SET stock_quantity = ? WHERE id = ?";
        return $this->db->query($sql, [$newQuantity, $id]);
    }
    
    public function getLowStockProducts() {
        $sql = "SELECT * FROM products WHERE stock_quantity <= reorder_level";
        $stmt = $this->db->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}