-- Database Initialization Script
-- Generated: 2025-02-16 16:08:27
-- Author: musty131311

-- Create database
CREATE DATABASE IF NOT EXISTS inventory_system;
USE inventory_system;

-- Products table
CREATE TABLE products (
    id INT PRIMARY KEY AUTO_INCREMENT,
    sku VARCHAR(50) UNIQUE NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    category_id INT,
    stock_quantity INT NOT NULL DEFAULT 0,
    reorder_level INT NOT NULL DEFAULT 0,
    unit_price DECIMAL(10,2) NOT NULL,
    cost_price DECIMAL(10,2) NOT NULL,
    status ENUM('active', 'inactive', 'discontinued') NOT NULL DEFAULT 'active',
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL,
    created_by VARCHAR(50) NOT NULL,
    updated_by VARCHAR(50) NOT NULL,
    INDEX idx_sku (sku),
    INDEX idx_category (category_id)
);

-- Categories table
CREATE TABLE categories (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    parent_id INT,
    status ENUM('active', 'inactive') NOT NULL DEFAULT 'active',
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL,
    created_by VARCHAR(50) NOT NULL,
    updated_by VARCHAR(50) NOT NULL,
    INDEX idx_parent (parent_id)
);

-- Sales table
CREATE TABLE sales (
    id INT PRIMARY KEY AUTO_INCREMENT,
    invoice_number VARCHAR(50) UNIQUE NOT NULL,
    customer_id INT,
    sale_date DATETIME NOT NULL,
    subtotal DECIMAL(10,2) NOT NULL,
    tax_amount DECIMAL(10,2) NOT NULL,
    discount_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
    total_amount DECIMAL(10,2) NOT NULL,
    payment_method VARCHAR(50) NOT NULL,
    payment_status ENUM('pending', 'paid', 'cancelled') NOT NULL,
    status ENUM('pending', 'completed', 'cancelled') NOT NULL,
    notes TEXT,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL,
    created_by VARCHAR(50) NOT NULL,
    updated_by VARCHAR(50) NOT NULL,
    INDEX idx_customer (customer_id),
    INDEX idx_invoice (invoice_number)
);

-- Sale Items table
CREATE TABLE sale_items (
    id INT PRIMARY KEY AUTO_INCREMENT,
    sale_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    unit_price DECIMAL(10,2) NOT NULL,
    discount_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
    total_amount DECIMAL(10,2) NOT NULL,
    INDEX idx_sale (sale_id),
    INDEX idx_product (product_id)
);

-- Add more table creation statements for other entities...

-- Create foreign key constraints
ALTER TABLE products
ADD CONSTRAINT fk_product_category
FOREIGN KEY (category_id) REFERENCES categories(id);

ALTER TABLE categories
ADD CONSTRAINT fk_category_parent
FOREIGN KEY (parent_id) REFERENCES categories(id);

ALTER TABLE sales
ADD CONSTRAINT fk_sale_customer
FOREIGN KEY (customer_id) REFERENCES customers(id);

ALTER TABLE sale_items
ADD CONSTRAINT fk_sale_item_sale
FOREIGN KEY (sale_id) REFERENCES sales(id),
ADD CONSTRAINT fk_sale_item_product
FOREIGN KEY (product_id) REFERENCES products(id);

-- Insert initial settings
INSERT INTO settings (category, name, value, type, is_public, created_at, updated_at, created_by, updated_by)
VALUES 
('system', 'company_name', 'Inventory System', 'string', 1, NOW(), NOW(), 'musty131311', 'musty131311'),
('system', 'version', '1.0.0', 'string', 1, NOW(), NOW(), 'musty131311', 'musty131311'),
('email', 'smtp_host', 'smtp.example.com', 'string', 0, NOW(), NOW(), 'mus ▋