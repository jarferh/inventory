<?php
class AuthMiddleware {
    private $currentDateTime = '2025-02-16 16:10:31';
    private $currentUser = 'musty131311';
    private $excludedRoutes = [
        '/api/auth/login' => ['POST'],
        '/api/auth/forgot-password' => ['POST'],
        '/api/auth/reset-password' => ['POST']
    ];

    public function handle($request, $next) {
        try {
            // Check if route is excluded from authentication
            if ($this->isExcludedRoute($request)) {
                return $next($request);
            }

            // Validate JWT token
            $token = $this->getTokenFromRequest($request);
            if (!$token) {
                throw new AuthException('No authentication token provided', 401);
            }

            $payload = $this->validateToken($token);
            
            // Check token expiration
            if ($payload['exp'] < strtotime($this->currentDateTime)) {
                throw new AuthException('Token has expired', 401);
            }

            // Set authenticated user in request
            $request->user = $payload;

            // Log access
            $this->logAccess($request);

            return $next($request);
        } catch (AuthException $e) {
            return [
                'status' => 'error',
                'message' => $e->getMessage(),
                'code' => $e->getCode()
            ];
        }
    }

    private function isExcludedRoute($request) {
        $path = $request->getPath();
        $method = $request->getMethod();

        return isset($this->excludedRoutes[$path]) && 
               in_array($method, $this->excludedRoutes[$path]);
    }

    private function getTokenFromRequest($request) {
        $header = $request->getHeader('Authorization');
        if (!$header) {
            return null;
        }

        $parts = explode(' ', $header);
        return count($parts) === 2 && $parts[0] === 'Bearer' ? $parts[1] : null;
    }

    private function validateToken($token) {
        try {
            return JWT::decode($token, config('app.jwt_secret'), ['HS256']);
        } catch (Exception $e) {
            throw new AuthException('Invalid token', 401);
        }
    }

    private function logAccess($request) {
        $auditLog = new AuditLog();
        $auditLog->log(
            'auth',
            'access',
            "API access: {$request->getMethod()} {$request->getPath()}",
            [
                'ip' => $request->getClientIp(),
                'user_agent' => $request->getUserAgent()
            ]
        );
    }
}