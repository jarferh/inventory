<?php
class AuthController extends BaseController {
    private $users;

    public function __construct() {
        parent::__construct();
        $this->users = new Users();
    }

    public function login() {
        $data = json_decode(file_get_contents('php://input'), true);
        
        $this->validateRequest($data, [
            'username' => 'required',
            'password' => 'required'
        ]);

        try {
            $user = $this->users->authenticate($data['username'], $data['password']);
            if (!$user) {
                return $this->error('Invalid credentials', 401);
            }

            // Generate JWT token
            $token = $this->generateToken($user);

            // Log successful login
            $this->logLogin($user['id'], true);

            return $this->respond([
                'token' => $token,
                'user' => [
                    'id' => $user['id'],
                    'username' => $user['username'],
                    'name' => $user['name'],
                    'role' => $user['role'],
                    'permissions' => $this->users->getUserPermissions($user['id'])
                ]
            ]);
        } catch (Exception $e) {
            $this->logLogin($data['username'], false, $e->getMessage());
            return $this->error($e->getMessage(), 401);
        }
    }

    private function generateToken($user) {
        $payload = [
            'sub' => $user['id'],
            'username' => $user['username'],
            'role' => $user['role'],
            'iat' => strtotime($this->currentDateTime),
            'exp' => strtotime('+8 hours', strtotime($this->currentDateTime))
        ];

        return JWT::encode($payload, config('app.jwt_secret'));
    }

    private function logLogin($userId, $success, $errorMessage = null) {
        $auditLog = new AuditLog();
        $auditLog->log(
            'auth',
            'login',
            $success ? "Successful login" : "Failed login attempt",
            [
                'user_id' => $userId,
                'success' => $success,
                'error' => $errorMessage,
                'ip' => $_SERVER['REMOTE_ADDR'],
                'user_agent' => $_SERVER['HTTP_USER_AGENT']
            ]
        );
    }

    public function logout() {
        // Log logout
        $auditLog = new AuditLog();
        $auditLog->log(
            'auth',
            'logout',
            "User logged out",
            ['user_id' => $this->currentUser] ▋