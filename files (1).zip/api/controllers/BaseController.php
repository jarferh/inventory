<?php
abstract class BaseController {
    protected $currentDateTime = '2025-02-16 16:09:33';
    protected $currentUser = 'musty131311';
    protected $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    protected function validateRequest($data, $rules) {
        $errors = [];
        foreach ($rules as $field => $rule) {
            if (!isset($data[$field]) && strpos($rule, 'required') !== false) {
                $errors[$field] = "Field is required";
            }
        }
        if (!empty($errors)) {
            throw new ValidationException("Validation failed", $errors);
        }
    }

    protected function respond($data, $statusCode = 200) {
        http_response_code($statusCode);
        return [
            'status' => 'success',
            'timestamp' => $this->currentDateTime,
            'data' => $data
        ];
    }

    protected function error($message, $statusCode = 400) {
        http_response_code($statusCode);
        return [
            'status' => 'error',
            'timestamp' => $this->currentDateTime,
            'message' => $message
        ];
    }
}