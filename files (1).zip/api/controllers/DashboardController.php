<?php
class DashboardController extends BaseController {
    private $dashboard;

    public function __construct() {
        parent::__construct();
        $this->dashboard = new Dashboard();
    }

    public function getSummary() {
        $stats = $this->dashboard->getSummaryStats();
         ▋