<?php
class SalesController extends BaseController {
    private $sales;

    public function __construct() {
        parent::__construct();
        $this->sales = new Sales();
    }

    public function list($params) {
        $page = $_GET['page'] ?? 1;
        $limit = $_GET['limit'] ?? 10;
        $filters = [
            'customer_id' => $_GET['customer'] ?? null,
            'status' => $_GET['status'] ?? null,
            'start_date' => $_GET['start_date'] ?? null,
            'end_date' => $_GET['end_date'] ?? null
        ];

        $sales = $this->sales->getAllSales($filters, $page, $limit);
        return $this->respond([
            'sales' => $sales,
            'pagination' => [
                'page' => $page,
                'limit' => $limit,
                'total' => $this->sales->getTotalCount($filters)
            ]
        ]);
    }

    public function get($params) {
        $sale = $this->sales->getSale($params['id']);
        if (!$sale) {
            return $this->error("Sale not found", 404);
        }
        return $this->respond($sale);
    }

    public function create() {
        $data = json_decode(file_get_contents('php://input'), true);
        
        $this->validateRequest($data, [
            'customer_id' => 'required|exists:customers',
            'items' => 'required|array',
            'payment_method' => 'required'
        ]);

        try {
            $saleId = $this->sales->createSale($data);
            return $this->respond([
                'id' => $saleId,
                'invoice_number' => $this->sales->getInvoiceNumber($saleId)
            ], 201);
        } catch (Exception $e) {
            return $this->error($e->getMessage(), 400);
        }
    }

    public function updateStatus($params) {
        $data = json_decode(file_get_contents('php://input'), true);
        
        $this->validateRequest($data, [
            'status' => 'required|in:pending,completed,cancelled'
        ]);

        try {
            $success = $this->sales->updateSaleStatus($params['id'], $data['status']);
            return $this->respond(['success' => $success]);
        } catch (Exception $e) {
            return $this->error($e->getMessage(), 400);
        }
    }
}