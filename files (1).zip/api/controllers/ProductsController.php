<?php
class ProductsController extends BaseController {
    private $products;

    public function __construct() {
        parent::__construct();
        $this->products = new Products();
    }

    public function list($params) {
        $page = $_GET['page'] ?? 1;
        $limit = $_GET['limit'] ?? 10;
        $filters = [
            'category' => $_GET['category'] ?? null,
            'status' => $_GET['status'] ?? null,
            'search' => $_GET['search'] ?? null
        ];

        $products = $this->products->getAllProducts($filters, $page, $limit);
        return $this->respond([
            'products' => $products,
            'pagination' => [
                'page' => $page,
                'limit' => $limit,
                'total' => $this->products->getTotalCount($filters)
            ]
        ]);
    }

    public function get($params) {
        $product = $this->products->getProduct($params['id']);
        if (!$product) {
            return $this->error("Product not found", 404);
        }
        return $this->respond($product);
    }

    public function create() {
        $data = json_decode(file_get_contents('php://input'), true);
        
        $this->validateRequest($data, [
            'name' => 'required',
            'sku' => 'required|unique',
            'unit_price' => 'required|numeric',
            'cost_price' => 'required|numeric'
        ]);

        $productId = $this->products->addProduct($data);
        return $this->respond(['id' => $productId], 201);
    }

    public function update($params) {
        $data = json_decode(file_get_contents('php://input'), true);
        
        $this->validateRequest($data, [
            'name' => 'required',
            'unit_price' => 'required|numeric',
            'cost_price' => 'required|numeric'
        ]);

        $success = $this->products->updateProduct($params['id'], $data);
        return $this->respond(['success' => $success]);
    }

    public function delete($params) {
        $success = $this->products->deleteProduct($params['id']);
        return $this->respond(['success' => $success]);
    }
}