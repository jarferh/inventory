<?php
class CustomersController extends BaseController {
    private $customers;

    public function __construct() {
        parent::__construct();
        $this->customers = new Customers();
    }

    public function list($params) {
        $page = $_GET['page'] ?? 1;
        $limit = $_GET['limit'] ?? 10;
        $filters = [
            'status' => $_GET['status'] ?? null,
            'search' => $_GET['search'] ?? null
        ];

        $customers = $this->customers->getAllCustomers($filters, $page, $limit);
        return $this->respond([
            'customers' => $customers,
            'pagination' => [
                'page' => $page,
                'limit' => $limit,
                'total' => $this->customers->getTotalCount($filters)
            ]
        ]);
    }

    public function get($params) {
        $customer = $this->customers->getCustomer($params['id']);
        if (!$customer) {
            return $this->error("Customer not found", 404);
        }
        
        // Enhance customer data with statistics
        $customer['statistics'] = [
            'total_orders' => $this->customers->getOrderCount($params['id']),
            'total_spent' => $this->customers->getTotalSpent($params['id']),
            'last_order' => $this->customers->getLastOrder($params['id'])
        ];

        return $this->respond($customer);
    }

    public function create() {
        $data = json_decode(file_get_contents('php://input'), true);
        
        $this->validateRequest($data, [
            'name' => 'required',
            'email' => 'required|email|unique:customers',
            'phone' => 'required'
        ]);

        try {
            $customerId = $this->customers->addCustomer($data);
            return $this->respond(['id' => $customerId], 201);
        } catch (Exception $e) {
            return $this->error($e->getMessage(), 400);
        }
    }

    public function update($params) {
        $data = json_decode(file_get_contents('php://input'), true);
        
        $this->validateRequest($data, [
            'name' => 'required',
            'email' => 'required|email'
        ]);

        try {
            $success = $this->customers->updateCustomer($params['id'], $data);
            return $this->respond(['success' => $success]);
        } catch (Exception $e) {
            return $this->error($e->getMessage(), 400);
        }
    }

    public function getOrders($params) {
        $page = $_GET['page'] ?? 1;
        $limit = $_GET['limit'] ?? 10;
        
        $orders = $this->customers->getCustomerOrders($params['id'], $page, $limit);
        return $this->respond([
            'orders' => $orders,
            'pagination' => [
                'page' => $page,
                'limit' => $limit,
                'total' => $this->customers->getOrderCount($params['id'])
            ]
        ]);
    }

    public function getStatistics($params) {
        try {
            $stats = $this->customers->getCustomerStatistics($params['id']);
            return $this->respond($stats);
        } catch (Exception $e) {
            return $this->error($e->getMessage(), 400);
        }
    }
}