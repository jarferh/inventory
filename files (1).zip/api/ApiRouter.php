<?php
class ApiRouter {
    private $currentDateTime = '2025-02-16 16:08:27';
    private $currentUser = 'musty131311';
    private $routes = [];

    public function __construct() {
        $this->initializeRoutes();
    }

    private function initializeRoutes() {
        // Products endpoints
        $this->routes['GET']['/api/products'] = ['ProductsController', 'list'];
        $this->routes['GET']['/api/products/{id}'] = ['ProductsController', 'get'];
        $this->routes['POST']['/api/products'] = ['ProductsController', 'create'];
        $this->routes['PUT']['/api/products/{id}'] = ['ProductsController', 'update'];
        $this->routes['DELETE']['/api/products/{id}'] = ['ProductsController', 'delete'];

        // Sales endpoints
        $this->routes['GET']['/api/sales'] = ['SalesController', 'list'];
        $this->routes['GET']['/api/sales/{id}'] = ['SalesController', 'get'];
        $this->routes['POST']['/api/sales'] = ['SalesController', 'create'];
        $this->routes['PUT']['/api/sales/{id}/status'] = ['SalesController', 'updateStatus'];

        // Customer endpoints
        $this->routes['GET']['/api/customers'] = ['CustomersController', 'list'];
        $this->routes['GET']['/api/customers/{id}'] = ['CustomersController', 'get'];
        $this->routes['POST']['/api/customers'] = ['CustomersController', 'create'];
        $this->routes['PUT']['/api/customers/{id}'] = ['CustomersController', 'update'];

        // Dashboard endpoints
        $this->routes['GET']['/api/dashboard/summary'] = ['DashboardController', 'getSummary'];
        $this->routes['GET']['/api/dashboard/charts/{type}'] = ['DashboardController', 'getChartData'];
        $this->routes['GET']['/api/dashboard/activity'] = ['DashboardController', 'getRecentActivity'];
    }

    public function handleRequest($method, $path) {
        try {
            // Start output buffering
            ob_start();

            // Validate request
            $this->validateRequest($method);

            // Find matching route
            $route = $this->findRoute($method, $path);
            if (!$route) {
                throw new Exception("Route not found", 404);
            }

            // Extract parameters
            $params = $this->extractParams($route['pattern'], $path);

            // Execute controller method
            $result = $this->executeController($route['handler'], $params);

            // Send response
            $this->sendResponse($result);
        } catch (Exception $e) {
            $this->handleError($e);
        } finally {
            ob_end_flush();
        }
    }

    private function validateRequest($method) {
        if (!in_array($method, ['GET', 'POST', 'PUT', 'DELETE'])) {
            throw new Exception("Method not allowed", 405);
        }
    }

    private function findRoute($method, $path) {
        foreach ($this->routes[$method] as $pattern => $handler) {
            if ($this->matchRoute($pattern, $path)) {
                return ['pattern' => $pattern, 'handler' => $handler];
            }
        }
        return null;
    }

    private function matchRoute($pattern, $path) {
        $pattern = preg_replace('/{[^}]+}/', '([^/]+)', $pattern);
        return preg_match("#^$pattern$#", $path);
    }

    private function extractParams($pattern, $path) {
        $params = [];
        $patternParts = explode('/', $pattern);
        $pathParts = explode('/', $path);

        foreach ($patternParts as $index => $part) {
            if (preg_match('/^{(.+)}$/', $part, $matches)) {
                $params[$matches[1]] = $pathParts[$index];
            }
        }

        return $params;
    }

    private function executeController($handler, $params) {
        list($controllerName, $methodName) = $handler;
        $controller = new $controllerName();
        return $controller->$methodName($params);
    }

    private function sendResponse($data) {
        header('Content-Type: application/json');
        echo json_encode([
            'status' => 'success',
            'timestamp' => $this->currentDateTime,
            'data' => $data
        ]);
    }

    private function handleError(Exception $e) {
        $statusCode = $e->getCode() ?: 500;
        http_response_code($statusCode);
        
        header('Content-Type: application/json');
        echo json_encode([
            'status' => 'error',
            'timestamp' => $this->currentDateTime,
            'message' => $e->getMessage(),
            'code' => $statusCode
        ]);
    }
}