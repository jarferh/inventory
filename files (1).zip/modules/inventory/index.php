<?php
require_once '../../config/config.php';
require_once '../../classes/Database.php';
require_once '../../classes/Session.php';
require_once '../../classes/Inventory.php';

Session::init();

if (!Session::isLoggedIn()) {
    header('Location: ../../login.php');
    exit();
}

$currentDateTime = '2025-02-16 15:20:51';
$currentUser = 'musty131311';

$inventory = new Inventory();
$categories = $inventory->getAllCategories();

// Handle filters
$category = $_GET['category'] ?? '';
$status = $_GET['status'] ?? '';
$search = $_GET['search'] ?? '';
$sort = $_GET['sort'] ?? 'name_asc';

$products = $inventory->getFilteredProducts($category, $status, $search, $sort);

$pageTitle = 'Inventory Management - ' . SITE_NAME;
$currentPage = 'inventory';
$extraCSS = ['/assets/css/inventory.css'];
?>

<?php include '../../includes/header.php'; ?>

<div class="container-fluid py-4">
    <!-- Page Header -->
    <div class="row mb-4">
        <div class="col">
            <h2 class="mb-0">Inventory Management</h2>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="/dashboard">Dashboard</a></li>
                    <li class="breadcrumb-item active">Inventory</li>
                </ol>
            </nav>
        </div>
        <div class="col-auto">
            <div class="btn-group">
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addProductModal">
                    <i class="fas fa-plus me-2"></i>Add Product
                </button>
                <button type="button" class="btn btn-outline-primary" onclick="importProducts()">
                    <i class="fas fa-file-import me-2"></i>Import
                </button>
                <button type="button" class="btn btn-outline-primary" onclick="exportInventory()">
                    <i class="fas fa-file-export me-2"></i>Export
                </button>
            </div>
        </div>
    </div>

    <!-- Filters and Search -->
    <div class="card mb-4">
        <div class="card-body">
            <form id="filterForm" class="row g-3">
                <div class="col-md-3">
                    <div class="form-group">
                        <label class="form-label">Category</label>
                        <select name="category" class="form-select">
                            <option value="">All Categories</option>
                            <?php foreach ($categories as $cat): ?>
                            <option value="<?= $cat['id'] ?>" <?= $category == $cat['id'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($cat['name']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label class="form-label">Stock Status</label>
                        <select name="status" class="form-select">
                            <option value="">All Status</option>
                            <option value="in_stock" <?= $status == 'in_stock' ? 'selected' : '' ?>>In Stock</option>
                            <option value="low_stock" <?= $status == 'low_stock' ? 'selected' : '' ?>>Low Stock</option>
                            <option value="out_of_stock" <?= $status == 'out_of_stock' ? 'selected' : '' ?>>Out of Stock</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label class="form-label">Search</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-search"></i></span>
                            <input type="text" name="search" class="form-control" placeholder="Search products..."
                                   value="<?= htmlspecialchars($search) ?>">
                        </div>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label class="form-label">Sort By</label>
                        <select name="sort" class="form-select">
                            <option value="name_asc" <?= $sort == 'name_asc' ? 'selected' : '' ?>>Name (A-Z)</option>
                            <option value="name_desc" <?= $sort == 'name_desc' ? 'selected' : '' ?>>Name (Z-A)</option>
                            <option value="stock_low" <?= $sort == 'stock_low' ? 'selected' : '' ?>>Lowest Stock</option>
                            <option value="stock_high" <?= $sort == 'stock_high' ? 'selected' : '' ?>>Highest Stock</option>
                            <option value="price_low" <?= $sort == 'price_low' ? 'selected' : '' ?>>Price (Low-High)</option>
                            <option value="price_high" <?= $sort == 'price_high' ? 'selected' : '' ?>>Price (High-Low)</option>
                        </select>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Inventory Grid -->
    <div class="row g-4 mb-4">
        <?php foreach ($products as $product): ?>
        <div class="col-12 col-sm-6 col-md-4 col-xl-3">
            <div class="card inventory-card h-100">
                <div class="card-body">
                    <div class="product-image mb-3">
                        <?php if ($product['image']): ?>
                            <img src="<?= htmlspecialchars($product['image']) ?>" 
                                 alt="<?= htmlspecialchars($product['name']) ?>"
                                 class="img-fluid rounded">
                        <?php else: ?>
                            <div class="placeholder-image">
                                <i class="fas fa-box"></i>
                            </div>
                        <?php endif; ?>
                        
                        <div class="stock-badge <?= getStockStatusClass($product) ?>">
                            <?= getStockStatus($product) ?>
                        </div>
                    </div>
                    
                    <h5 class="card-title mb-2"><?= htmlspecialchars($product['name']) ?></h5>
                    <p class="category-label mb-2">
                        <i class="fas fa-tag me-1"></i>
                        <?= htmlspecialchars($product['category_name']) ?>
                    </p>
                    
                    <div class="stock-info mb-3">
                        <div class="progress" style="height: 6px;">
                            <div class="progress-bar bg-<?= getProgressBarColor($product) ?>" 
                                 style="width: <?= getStockPercentage($product) ?>%">
                            </div>
                        </div>
                        <div class="d-flex justify-content-between mt-2">
                            <small class="text-muted">In Stock: <?= $product['stock_quantity'] ?></small>
                            <small class="text-muted">Reorder Level: <?= $product['reorder_level'] ?></small>
                        </div>
                    </div>
                    
                    <div class="price-info d-flex justify-content-between align-items-center mb-3">
                        <div>
                            <label class="text-muted small">Unit Price</label>
                            <h6 class="mb-0">KES <?= number_format($product['unit_price'], 2) ?></h6>
                        </div>
                        <div class="text-end">
                            <label class="text-muted small">Stock Value</label>
                            <h6 class="mb-0">KES <?= number_format($product['stock_quantity'] * $product['unit_price'], 2) ?></h6>
                        </div>
                    </div>
                    
                    <div class="card-actions">
                        <button class="btn btn-sm btn-primary" onclick="editProduct(<?= $product['id'] ?>)">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="btn btn-sm btn-success" onclick="restockProduct(<?= $product['id'] ?>)">
                            <i class="fas fa-plus"></i>
                        </button>
                        <button class="btn btn-sm btn-info" onclick="viewHistory(<?= $product['id'] ?>)">
                            <i class="fas fa-history"></i>
                        </button>
                        <button class="btn btn-sm btn-danger" onclick="deleteProduct(<?= $product['id'] ?>)">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <!-- Pagination -->
    <?php if ($inventory->getTotalPages() > 1): ?>
    <nav aria-label="Page navigation" class="d-flex justify-content-center">
        <ul class="pagination">
            <?php for ($i = 1; $i <= $inventory->getTotalPages(); $i++): ?>
            <li class="page-item <?= $inventory->getCurrentPage() == $i ? 'active' : '' ?>">
                <a class="page-link" href="?page=<?= $i ?>&<?= http_build_query(array_filter([
                    'category' => $category,
                    'status' => $status,
                    'search' => $search,
                    'sort' => $sort
                ])) ?>">
                    <?= $i ?>
                </a>
            </li>
            <?php endfor; ?>
        </ul>
    </nav>
    <?php endif; ?>
</div>

<!-- Add/Edit Product Modal -->
<div class="modal fade" id="productModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalTitle">Add Product</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="productForm" class="row g-3">
                    <input type="hidden" name="product_id" id="productId">
                    
                    <div class="col-md-6">
                        <label class="form-label">Product Name</label>
                        <input type="text" class="form-control" name="name" required>
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label">Category</label>
                        <select class="form-select" name="category_id" required>
                            <?php foreach ($categories as $cat): ?>
                            <option value="<?= $cat['id'] ?>"><?= htmlspecialchars($cat['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label">Unit Price</label>
                        <div class="input-group">
                            <span class="input-group-text">KES</span>
                            <input type="number" class="form-control" name="unit_price" step="0.01" required>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label">Reorder Level</label>
                        <input type="number" class="form-control" name="reorder_level" required>
                    </div>
                    
                    <div class="col-12">
                        <label class="form-label">Description</label>
                        <textarea class="form-control" name="description" rows="3"></textarea>
                    </div>
                    
                    <div class="col-12">
                        <label class="form-label">Product Image</label>
                        <input type="file" class="form-control" name="image" accept="image/*">
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary" onclick="saveProduct()">Save Product</button>
            </div>
        </div>
    </div>
</div>

<?php
function getStockStatus($product) {
    if ($product['stock_quantity'] == 0) {
        return 'Out of Stock';
    } elseif ($product['stock_quantity'] <= $product['reorder_level']) {
        return 'Low Stock';
    }
    return 'In Stock';
}

function getStockStatusClass($product) {
    if ($product['stock_quantity'] == 0) {
        return 'out-of-stock';
    } elseif ($product['stock_quantity'] <= $product['reorder_level']) {
        return 'low-stock';
    }
    return 'in-stock';
}

function getProgressBarColor($product) {
    if ($product['stock_quantity'] == 0) {
        return 'danger';
    } elseif ($product['stock_quantity'] <= $product['reorder_level']) {
        return 'warning';
    }
    return 'success';
}

function getStockPercentage($product) {
    $maxStock = max($product['stock_quantity'], $ ▋