<?php
require_once '../../config/config.php';
require_once '../../classes/Database.php';
require_once '../../classes/Session.php';
require_once '../../classes/Inventory.php';
require_once '../../classes/Audit.php';

Session::init();

if (!Session::isLoggedIn()) {
    header('Location: ../../login.php');
    exit();
}

$success = $error = '';
$inventory = new Inventory();
$audit = new Audit();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $data = [
            'name' => $_POST['name'],
            'sku' => $_POST['sku'],
            'category' => $_POST['category'],
            'description' => $_POST['description'],
            'unit_price' => $_POST['unit_price'],
            'stock_quantity' => $_POST['stock_quantity'],
            'reorder_level' => $_POST['reorder_level']
        ];
        
        $inventory->addProduct($data);
        
        // Log the action
        $audit->log(
            Session::get('user_id'),
            'product_added',
            "New product added: {$data['name']}"
        );
        
        $success = 'Product added successfully!';
    } catch (Exception $e) {
        $error = 'Error adding product: ' . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Product - <?= SITE_NAME ?></title>
    <link rel="stylesheet" href="../../assets/css/style.css">
</head>
<body>
    <div class="container">
        <?php include '../../includes/header.php'; ?>
        
        <div class="content">
            <h2>Add New Product</h2>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><?= $success ?></div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="alert alert-danger"><?= $error ?></div>
            <?php endif; ?>
            
            <form method="POST" class="form">
                <div class="form-group">
                    <label for="name">Product Name</label>
                    <input type="text" id="name" name="name" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="sku">SKU</label>
                    <input type="text" id="sku" name="sku" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="category">Category</label>
                    <select id="category" name="category" class="form-control" required>
                        <option value="">Select Category</option>
                        <option value="medicines">Medicines</option>
                        <option value="feeds">Animal Feeds</option>
                        <option value="equipment">Equipment</option>
                        <option value="supplements">Supplements</option>
                        <option value="pesticides">Pesticides</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea id="description" name="description" class="form-control"></textarea>
                </div>
                
                <div class="form-group">
                    <label for="unit_price">Unit Price</label>
                    <input type="number" id="unit_price" name="unit_price" step="0.01" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="stock_quantity">Initial Stock Quantity</label>
                    <input type="number" id="stock_quantity" name="stock_quantity" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="reorder_level">Reorder Level</label>
                    <input type="number" id="reorder_level" name="reorder_level" class="form-control" required>
                </div>
                
                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">Add Product</button>
                    <a href="list.php" class="btn">Cancel</a>
                </div>
            </form>
        </div>
    </div>
    
    <script src="../../assets/js/inventory.js"></script>
</body>
</html>