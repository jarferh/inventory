    } elseif ($diff < 3600) {
        $minutes = floor($diff / 60);
        return $minutes . ' minute' . ($minutes > 1 ? 's' : '') . ' ago';
    } elseif ($diff < 86400) {
        $hours = floor($diff / 3600);
        return $hours . ' hour' . ($hours > 1 ? 's' : '') . ' ago';
    } else {
        return date('M d, Y H:i', strtotime($timestamp));
    }
}

function getActivityIcon($type) {
    return match($type) {
        'login' => 'fa-sign-in-alt',
        'logout' => 'fa-sign-out-alt',
        'create' => 'fa-plus-circle',
        'update' => 'fa-edit',
        'delete' => 'fa-trash',
        'password' => 'fa-key',
        'settings' => 'fa-cog',
        default => 'fa-circle'
    };
}

function getActivityIconColor($type) {
    return match($type) {
        'login' => 'success',
        'logout' => 'secondary',
        'create' => 'primary',
        'update' => 'info',
        'delete' => 'danger',
        'password' => 'warning',
        'settings' => 'purple',
        default => 'secondary'
    };
}

function formatActivityTime($timestamp) {
    return date('h:i A', strtotime($timestamp));
}
?>

<?php include '../../includes/footer.php'; ?>