<?php
require_once '../../config/config.php';
require_once '../../classes/Database.php';
require_once '../../classes/Session.php';
require_once '../../classes/Order.php';

Session::init();

if (!Session::isLoggedIn()) {
    header('Location: ../../login.php');
    exit();
}

if (!isset($_GET['id'])) {
    header('Location: list.php');
    exit();
}

$order = new Order();
$orderData = $order->getOrder($_GET['id']);

if (!$orderData) {
    header('Location: list.php');
    exit();
}

$currentDateTime = '2025-02-16 14:46:22'; // Using provided UTC time
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Order #<?= $orderData['order_number'] ?> - <?= SITE_NAME ?></title>
    <link rel="stylesheet" href="../../assets/css/style.css">
</head>
<body>
    <div class="container">
        <?php include '../../includes/header.php'; ?>
        
        <div class="content">
            <div class="content-header">
                <h2>Purchase Order #<?= htmlspecialchars($orderData['order_number']) ?></h2>
                <div class="order-actions">
                    <?php if ($orderData['status'] === 'pending'): ?>
                        <button onclick="updateStatus('approved')" class="btn btn-primary">Approve</button>
                        <button onclick="updateStatus('cancelled')" class="btn btn-danger">Cancel</button>
                    <?php elseif ($orderData['status'] === 'approved'): ?>
                        <button onclick="showReceiveModal()" class="btn btn-success">Receive Order</button>
                    <?php endif; ?>
                    <button onclick="printOrder()" class="btn">Print</button>
                </div>
            </div>
            
            <div class="order-details">
                <div class="order-info">
                    <div class="info-group">
                        <label>Supplier:</label>
                        <span><?= htmlspecialchars($orderData['supplier_name']) ?></span>
                    </div>
                    <div class="info-group">
                        <label>Status:</label>
                        <span class="status-badge status-<?= $orderData['status'] ?>">
                            <?= ucfirst($orderData['status']) ?>
                        </span>
                    </div>
                    <div class="info-group">
                        <label>Created By:</label>
                        <span><?= htmlspecialchars($orderData['created_by']) ?></span>
                    </div>
                    <div class="info-group">
                        <label>Created At:</label>
                        <span><?= date('Y-m-d H:i:s', strtotime($orderData['created_at'])) ?></span>
                    </div>
                </div>
                
                <table class="table">
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>Quantity</th>
                            <th>Unit Price</th>
                            <th>Subtotal</th>
                            <?php if ($orderData['status'] === 'received'): ?>
                            <th>Received Qty</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($orderData['items'] as $item): ?>
                        <tr>
                            <td><?= htmlspecialchars($item['product_name']) ?></td>
                            <td><?= $item['quantity'] ?></td>
                            <td>KES <?= number_format($item['unit_price'], 2) ?></td>
                            <td>KES <?= number_format($item['subtotal'], 2) ?></td>
                            <?php if ($orderData['status'] === 'received'): ?>
                            <td><?= $item['received_quantity'] ?></td>
                            <?php endif; ?>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="3" class="text-right"><strong>Total:</strong></td>
                            <td colspan="<?= $orderData['status'] === 'received' ? '2' : '1' ?>">
                                <strong>KES <?= number_format($orderData['total_amount'], 2) ?></strong>
                            </td>
                        </tr>
                    </tfoot>
                </table>
                
                <?php if ($orderData['notes']): ?>
                <div class="order-notes">
                    <h4>Notes:</h4>
                    <p><?= nl2br(htmlspecialchars($orderData['notes'])) ?></p>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Receive Order Modal -->
    <div id="receive-modal" class="modal" style="display: none;">
        <div class="modal-content">
            <h3>Receive Order</h3>
            <form id="receive-form">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>Ordered Qty</th>
                            <th>Received Qty</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($orderData['items'] as $item): ?>
                        <tr>
                            <td><?= htmlspecialchars($item['product_name']) ?></td>
                            <td><?= $item['quantity'] ?></td>
                            <td>
                                <input type="number" name="received[<?= $item['id'] ?>]" 
                                       value="<?= $item['quantity'] ?>" 
                                       min="0" max="<?= $item['quantity'] ?>" required>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                
                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">Confirm Receipt</button>
                    <button type="button" onclick="hideReceiveModal()" class="btn">Cancel</button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
    function updateStatus(status) {
        if (!confirm(`Are you sure you want to ${status} this order?`)) {
            return;
        }
        
        fetch('update_status.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                order_id: <?= $orderData['id'] ?>,
                status: status
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                alert('Error: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while updating the order status');
        });
    }
    
    function showReceiveModal() {
        document.getElementById('receive-modal').style.display = 'block';
    }
    
    function hideReceiveModal() {
        document.getElementById('receive-modal').style.display = 'none';
    }
    
    document.getElementById('receive-form').addEventListener('submit', function(e) {
        e.preventDefault();
        
        const formData = new FormData(this);
        formData.append('order_id', <?= $orderData['id'] ?>);
        
        fetch('receive_order.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                alert('Error: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while processing the order receipt');
        });
    });
    
    function printOrder() {
        window.print();
    }
    </script>
</body>
</html>