<?php
require_once '../../config/config.php';
require_once '../../classes/Database.php';
require_once '../../classes/Session.php';
require_once '../../classes/Reports.php';

Session::init();

if (!Session::isLoggedIn()) {
    header('Location: ../../login.php');
    exit();
}

$currentDateTime = '2025-02-16 15:28:02';
$currentUser = 'musty131311';

$reports = new Reports();

// Get report data
$dateRange = $_GET['range'] ?? 'last_30_days';
$startDate = '';
$endDate = '';

switch ($dateRange) {
    case 'today':
        $startDate = date('Y-m-d');
        $endDate = date('Y-m-d');
        break;
    case 'this_week':
        $startDate = date('Y-m-d', strtotime('monday this week'));
        $endDate = date('Y-m-d');
        break;
    case 'this_month':
        $startDate = date('Y-m-01');
        $endDate = date('Y-m-d');
        break;
    case 'last_30_days':
    default:
        $startDate = date('Y-m-d', strtotime('-30 days'));
        $endDate = date('Y-m-d');
        break;
}

$salesData = $reports->getSalesReport($startDate, $endDate);
$inventoryData = $reports->getInventoryReport($startDate, $endDate);
$supplierData = $reports->getSupplierReport($startDate, $endDate);
$profitData = $reports->getProfitReport($startDate, $endDate);

$pageTitle = 'Reports & Analytics - ' . SITE_NAME;
$currentPage = 'reports';
$extraCSS = ['/assets/css/reports.css'];
?>

<?php include '../../includes/header.php'; ?>

<div class="container-fluid py-4">
    <!-- Page Header -->
    <div class="row mb-4">
        <div class="col">
            <h2 class="mb-0">Reports & Analytics</h2>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="/dashboard">Dashboard</a></li>
                    <li class="breadcrumb-item active">Reports</li>
                </ol>
            </nav>
        </div>
        <div class="col-auto">
            <div class="d-flex gap-2">
                <select class="form-select" id="dateRange">
                    <option value="today" <?= $dateRange == 'today' ? 'selected' : '' ?>>Today</option>
                    <option value="this_week" <?= $dateRange == 'this_week' ? 'selected' : '' ?>>This Week</option>
                    <option value="this_month" <?= $dateRange == 'this_month' ? 'selected' : '' ?>>This Month</option>
                    <option value="last_30_days" <?= $dateRange == 'last_30_days' ? 'selected' : '' ?>>Last 30 Days</option>
                    <option value="custom">Custom Range</option>
                </select>
                <button class="btn btn-primary" onclick="exportReport()">
                    <i class="fas fa-file-export me-2"></i>Export Report
                </button>
            </div>
        </div>
    </div>

    <!-- Date Range Picker (Initially Hidden) -->
    <div id="customDateRange" class="card mb-4" style="display: none;">
        <div class="card-body">
            <div class="row g-3">
                <div class="col-md-5">
                    <label class="form-label">Start Date</label>
                    <input type="date" class="form-control" id="startDate" value="<?= $startDate ?>">
                </div>
                <div class="col-md-5">
                    <label class="form-label">End Date</label>
                    <input type="date" class="form-control" id="endDate" value="<?= $endDate ?>">
                </div>
                <div class="col-md-2">
                    <label class="form-label">&nbsp;</label>
                    <button class="btn btn-primary w-100" onclick="applyDateRange()">Apply</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Summary Cards -->
    <div class="row g-4 mb-4">
        <!-- Sales Summary -->
        <div class="col-md-6 col-xl-3">
            <div class="card summary-card">
                <div class="card-body">
                    <div class="d-flex justify-content-between mb-3">
                        <div>
                            <h6 class="card-subtitle text-muted">Total Sales</h6>
                            <h3 class="card-title mb-0">KES <?= number_format($salesData['total_sales'], 2) ?></h3>
                        </div>
                        <div class="summary-icon bg-primary">
                            <i class="fas fa-chart-line"></i>
                        </div>
                    </div>
                    <div class="progress" style="height: 4px;">
                        <div class="progress-bar" style="width: <?= $salesData['growth_percentage'] ?>%"></div>
                    </div>
                    <div class="d-flex justify-content-between mt-2">
                        <small class="text-muted">Previous: KES <?= number_format($salesData['previous_sales'], 2) ?></small>
                        <small class="<?= $salesData['growth_percentage'] >= 0 ? 'text-success' : 'text-danger' ?>">
                            <i class="fas fa-arrow-<?= $salesData['growth_percentage'] >= 0 ? 'up' : 'down' ?>"></i>
                            <?= abs($salesData['growth_percentage']) ?>%
                        </small>
                    </div>
                </div>
            </div>
        </div>

        <!-- Profit Summary -->
        <div class="col-md-6 col-xl-3">
            <div class="card summary-card">
                <div class="card-body">
                    <div class="d-flex justify-content-between mb-3">
                        <div>
                            <h6 class="card-subtitle text-muted">Net Profit</h6>
                            <h3 class="card-title mb-0">KES <?= number_format($profitData['net_profit'], 2) ?></h3>
                        </div>
                        <div class="summary-icon bg-success">
                            <i class="fas fa-dollar-sign"></i>
                        </div>
                    </div>
                    <div class="progress" style="height: 4px;">
                        <div class="progress-bar bg-success" style="width: <?= $profitData['margin_percentage'] ?>%"></div>
                    </div>
                    <div class="d-flex justify-content-between mt-2">
                        <small class="text-muted">Margin: <?= number_format($profitData['margin_percentage'], 1) ?>%</small>
                        <small class="<?= $profitData['growth_percentage'] >= 0 ? 'text-success' : 'text-danger' ?>">
                            <i class="fas fa-arrow-<?= $profitData['growth_percentage'] >= 0 ? 'up' : 'down' ?>"></i>
                            <?= abs($profitData['growth_percentage']) ?>%
                        </small>
                    </div>
                </div>
            </div>
        </div>

        <!-- Inventory Summary -->
        <div class="col-md-6 col-xl-3">
            <div class="card summary-card">
                <div class="card-body">
                    <div class="d-flex justify-content-between mb-3">
                        <div>
                            <h6 class="card-subtitle text-muted">Inventory Value</h6>
                            <h3 class="card-title mb-0">KES <?= number_format($inventoryData['total_value'], 2) ?></h3>
                        </div>
                        <div class="summary-icon bg-info">
                            <i class="fas fa-box"></i>
                        </div>
                    </div>
                    <div class="progress" style="height: 4px;">
                        <div class="progress-bar bg-info" style="width: <?= $inventoryData['stock_percentage'] ?>%"></div>
                    </div>
                    <div class="d-flex justify-content-between mt-2">
                        <small class="text-muted"><?= $inventoryData['total_items'] ?> Items</small>
                        <small class="text-muted"><?= $inventoryData['low_stock_items'] ?> Low Stock</small>
                    </div>
                </div>
            </div>
        </div>

        <!-- Orders Summary -->
        <div class="col-md-6 col-xl-3">
            <div class="card summary-card">
                <div class="card-body">
                    <div class="d-flex justify-content-between mb-3">
                        <div>
                            <h6 class="card-subtitle text-muted">Total Orders</h6>
                            <h3 class="card-title mb-0"><?= number_format($salesData['total_orders']) ?></h3>
                        </div>
                        <div class="summary-icon bg-warning">
                            <i class="fas fa-shopping-cart"></i>
                        </div>
                    </div>
                    <div class="progress" style="height: 4px;">
                        <div class="progress-bar bg-warning" style="width: <?= $salesData['order_completion_rate'] ?>%"></div>
                    </div>
                    <div class="d-flex justify-content-between mt-2">
                        <small class="text-muted">Avg. Order: KES <?= number_format($salesData['average_order'], 2) ?></small>
                        <small class="text-success"><?= number_format($salesData['order_completion_rate'], 1) ?>% Complete</small>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Charts Row -->
    <div class="row g-4 mb-4">
        <!-- Sales Trend -->
        <div class="col-xl-8">
            <div class="card">
                <div class="card-header bg-white p-4">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">Sales Trend</h5>
                        <div class="btn-group">
                            <button type="button" class="btn btn-outline-primary active" data-chart-view="daily">Daily</button>
                            <button type="button" class="btn btn-outline-primary" data-chart-view="weekly">Weekly</button>
                            <button type="button" class="btn btn-outline-primary" data-chart-view="monthly">Monthly</button>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <canvas id="salesTrendChart" height="300"></canvas>
                </div>
            </div>
        </div>

        <!-- Top Products -->
        <div class="col-xl-4">
            <div class="card">
                <div class="card-header bg-white p-4">
                    <h5 class="mb-0">Top Products</h5>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="bg-light">
                                <tr>
                                    <th>Product</th>
                                    <th class="text-end">Sales</th>
                                    <th class="text-end">Revenue</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($salesData['top_products'] as $product): ?>
                                <tr>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <?php if ($product['image']): ?>
                                                <img src="<?= htmlspecialchars($product['image']) ?>" 
                                                     class="product-thumbnail me-2" 
                                                     alt="<?= htmlspecialchars($product['name']) ?>">
                                            <?php else: ?>
                                                <div class="product-thumbnail-placeholder me-2">
                                                    <i class="fas fa-box"></i>
                                                </div>
                                            <?php endif; ?>
                                            <div>
                                                <h6 class="mb-0"><?= htmlspecialchars($product['name']) ?></h6>
                                                <small class="text-muted"><?= htmlspecialchars($product['category']) ?></small>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="text-end"><?= number_format($product['quantity']) ?></td>
                                    <td class="text-end">KES <?= number_format($product['revenue'], 2) ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Detailed Reports -->
    <div class="row g-4">
        <!-- Sales by Category -->
        <div class="col-md-6">
            <div class="card">
                <div class="card-header bg-white p-4">
                    <h5 class="mb-0">Sales by Category</h5>
                </div>
                <div class="card-body">
                    <canvas id="categoryChart" height="300"></canvas>
                </div>
            </div>
        </div>

        <!-- Payment Methods -->
        <div class="col-md-6">
            <div class="card">
                <div class="card-header bg-white p-4">
                    <h5 class="mb-0">Payment Methods</h5>
                </div>
                <div class="card-body">
                    <canvas id="paymentMethods ▋