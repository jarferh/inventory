<?php
require_once '../../config/config.php';
require_once '../../classes/Database.php';
require_once '../../classes/Session.php';
require_once '../../classes/Reports.php';
require_once '../../classes/Inventory.php';

Session::init();

if (!Session::isLoggedIn()) {
    header('Location: ../../login.php');
    exit();
}

$currentDateTime = '2025-02-16 14:53:22';
$currentUser = 'musty131311';

$reports = new Reports();
$inventory = new Inventory();

// Get category filter if set
$category = $_GET['category'] ?? '';
$stockStatus = $_GET['stock_status'] ?? '';

$inventoryData = $reports->getInventoryReport($category, $stockStatus);
$categories = $inventory->getAllCategories();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory Report - <?= SITE_NAME ?></title>
    <link rel="stylesheet" href="../../assets/css/style.css">
    <link rel="stylesheet" href="../../assets/css/reports.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="container">
        <?php include '../../includes/header.php'; ?>
        
        <div class="content">
            <div class="content-header">
                <h2>Inventory Report</h2>
                <div class="export-buttons">
                    <button onclick="exportToPDF()" class="btn">Export PDF</button>
                    <button onclick="exportToExcel()" class="btn">Export Excel</button>
                </div>
            </div>
            
            <div class="report-filters">
                <form method="GET" class="filters-grid">
                    <div class="form-group">
                        <label for="category">Category</label>
                        <select id="category" name="category" class="form-control">
                            <option value="">All Categories</option>
                            <?php foreach ($categories as $cat): ?>
                            <option value="<?= $cat['id'] ?>" 
                                <?= $category == $cat['id'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($cat['name']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="stock_status">Stock Status</label>
                        <select id="stock_status" name="stock_status" class="form-control">
                            <option value="">All Status</option>
                            <option value="low" <?= $stockStatus == 'low' ? 'selected' : '' ?>>
                                Low Stock
                            </option>
                            <option value="out" <?= $stockStatus == 'out' ? 'selected' : '' ?>>
                                Out of Stock
                            </option>
                            <option value="optimal" <?= $stockStatus == 'optimal' ? 'selected' : '' ?>>
                                Optimal
                            </option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary">Apply Filter</button>
                    </div>
                </form>
            </div>
            
            <div class="report-summary">
                <div class="summary-grid">
                    <div class="summary-box">
                        <h4>Total Products</h4>
                        <p class="amount"><?= count($inventoryData) ?></p>
                    </div>
                    
                    <div class="summary-box">
                        <h4>Low Stock Items</h4>
                        <p class="amount"><?= count(array_filter($inventoryData, fn($item) => 
                            $item['stock_quantity'] <= $item['reorder_level'])) ?></p>
                    </div>
                    
                    <div class="summary-box">
                        <h4>Out of Stock</h4>
                        <p class="amount"><?= count(array_filter($inventoryData, fn($item) => 
                            $item['stock_quantity'] == 0)) ?></p>
                    </div>
                    
                    <div class="summary-box">
                        <h4>Total Stock Value</h4>
                        <p class="amount">KES <?= number_format(array_reduce($inventoryData, 
                            fn($carry, $item) => $carry + ($item['stock_quantity'] * $item['unit_price']), 0), 2) ?></p>
                    </div>
                </div>
            </div>
            
            <div class="chart-container">
                <canvas id="stockLevelChart"></canvas>
            </div>
            
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>Category</th>
                            <th>Current Stock</th>
                            <th>Reorder Level</th>
                            <th>Unit Price</th>
                            <th>Stock Value</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($inventoryData as $item): ?>
                        <tr class="<?= getStockStatusClass($item) ?>">
                            <td><?= htmlspecialchars($item['name']) ?></td>
                            <td><?= htmlspecialchars($item['category']) ?></td>
                            <td><?= $item['stock_quantity'] ?></td>
                            <td><?= $item['reorder_level'] ?></td>
                            <td>KES <?= number_format($item['unit_price'], 2) ?></td>
                            <td>KES <?= number_format($item['stock_quantity'] * $item['unit_price'], 2) ?></td>
                            <td>
                                <span class="status-badge">
                                    <?= getStockStatus($item) ?>
                                </span>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <script>
    // Prepare data for chart
    const stockData = {
        labels: <?= json_encode(array_column($inventoryData, 'name')) ?>,
        datasets: [{
            label: 'Current Stock',
            data: <?= json_encode(array_column($inventoryData, 'stock_quantity')) ?>,
            backgroundColor: 'rgba(52, 152, 219, 0.5)',
            borderColor: '#3498db'
        }, {
            label: 'Reorder Level',
            data: <?= json_encode(array_column($inventoryData, 'reorder_level')) ?>,
            backgroundColor: 'rgba(231, 76, 60, 0.5)',
            borderColor: '#e74c3c'
        }]
    };

    // Create stock level chart
    const ctx = document.getElementById('stockLevelChart').getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: stockData,
        options: {
            responsive: true,
            plugins: {
                title: {
                    display: true,
                    text: 'Stock Levels vs Reorder Points'
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Quantity'
                    }
                }
            }
        }
    });

    // Export functions
    function exportToPDF() {
        window.location.href = 'export_pdf.php?' + new URLSearchParams({
            type: 'inventory',
            category: '<?= $category ?>',
            stock_status: '<?= $stockStatus ?>'
        });
    }

    function exportToExcel() {
        window.location.href = 'export_excel.php?' + new URLSearchParams({
            type: 'inventory',
            category: '<?= $category ?>',
            stock_status: '<?= $stockStatus ?>'
        });
    }
    </script>
</body>
</html>

<?php
function getStockStatus($item) {
    if ($item['stock_quantity'] == 0) {
        return 'Out of Stock';
    } elseif ($item['stock_quantity'] <= $item['reorder_level']) {
        return 'Low Stock';
    } else {
        return 'Optimal';
    }
}

function getStockStatusClass($item) {
    if ($item['stock_quantity'] == 0) {
        return 'stock-out';
    } elseif ($item['stock_quantity'] <= $item['reorder_level']) {
        return 'stock-low';
    }
    return '';
}
?>