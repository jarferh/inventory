<?php
require_once '../../config/config.php';
require_once '../../classes/Database.php';
require_once '../../classes/Session.php';
require_once '../../classes/Reports.php';
require_once '../../lib/fpdf/fpdf.php';

Session::init();

if (!Session::isLoggedIn()) {
    exit('Unauthorized access');
}

$currentDateTime = '2025-02-16 14:51:37';
$currentUser = 'musty131311';

class ReportPDF extends FPDF {
    function Header() {
        global $currentDateTime;
        
        $this->SetFont('Arial', 'B', 15);
        $this->Cell(0, 10, SITE_NAME, 0, 1, 'C');
        
        $this->SetFont('Arial', '', 10);
        $this->Cell(0, 5, 'Generated on: ' . $currentDateTime, 0, 1, 'C');
        
        $this->Ln(10);
    }
    
    function Footer() {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 8);
        $this->Cell(0, 10, 'Page ' . $this->PageNo() . '/{nb}', 0, 0, 'C');
    }
}

$reports = new Reports();
$type = $_GET['type'] ?? '';
$startDate = $_GET['start_date'] ?? date('Y-m-d', strtotime('-30 days'));
$endDate = $_GET['end_date'] ?? date('Y-m-d');

$pdf = new ReportPDF();
$pdf->AliasNbPages();
$pdf->AddPage();

switch ($type) {
    case 'sales':
        $salesData = $reports->getSalesReport($startDate, $endDate);
        
        $pdf->SetFont('Arial', 'B', 14);
        $pdf->Cell(0, 10, 'Sales Report', 0, 1, 'C');
        $pdf->Cell(0, 5, "Period: $startDate to $endDate", 0, 1, 'C');
        $pdf->Ln(10);
        
        // Table header
        $pdf->SetFont('Arial', 'B', 10);
        $pdf->Cell(40, 7, 'Date', 1);
        $pdf->Cell(30, 7, 'Transactions', 1);
        $pdf->Cell(60, 7, 'Total Sales', 1);
        $pdf->Cell(60, 7, 'Average Sale', 1);
        $pdf->Ln();
        
        // Table data
        $pdf->SetFont('Arial', '', 10);
        $totalSales = 0;
        foreach ($salesData as $sale) {
            $pdf->Cell(40, 6, $sale['sale_date'], 1);
            $pdf->Cell(30, 6, $sale['total_transactions'], 1);
            $pdf->Cell(60, 6, 'KES ' . number_format($sale['total_amount'], 2), 1);
            $pdf->Cell(60, 6, 'KES ' . number_format($sale['average_sale'], 2), 1);
            $pdf->Ln();
            $totalSales += $sale['total_amount'];
        }
        
        // Summary
        $pdf->Ln(10);
        $pdf->SetFont('Arial', 'B', 12);
        $pdf->Cell(0, 8, 'Summary', 0, 1);
        $pdf->SetFont('Arial', '', 10);
        $pdf->Cell(0, 6, 'Total Sales: KES ' . number_format($totalSales, 2), 0, 1);
        break;
        
    // Add more report types here
}

$pdf->Output('D', $type . '_report.pdf');