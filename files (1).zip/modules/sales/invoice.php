<?php
require_once '../../config/config.php';
require_once '../../classes/Database.php';
require_once '../../classes/Session.php';
require_once '../../classes/Sales.php';
require_once '../../classes/Invoice.php';

Session::init();

if (!Session::isLoggedIn()) {
    header('Location: ../../login.php');
    exit();
}

$currentDateTime = '2025-02-16 15:14:11';
$currentUser = 'musty131311';

if (!isset($_GET['id'])) {
    header('Location: /sales');
    exit();
}

$invoice = new Invoice();
$saleData = $invoice->getSaleDetails($_GET['id']);

if (!$saleData) {
    header('Location: /sales');
    exit();
}

$pageTitle = 'Invoice #' . $saleData['invoice_number'] . ' - ' . SITE_NAME;
$extraCSS = ['/assets/css/invoice.css'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <?php foreach ($extraCSS as $css): ?>
        <link rel="stylesheet" href="<?= $css ?>">
    <?php endforeach; ?>
</head>
<body>
    <div class="invoice-wrapper">
        <!-- Invoice Actions -->
        <div class="invoice-actions py-3 px-4 bg-white border-bottom">
            <div class="container-fluid">
                <div class="row align-items-center">
                    <div class="col">
                        <h4 class="mb-0">Invoice #<?= $saleData['invoice_number'] ?></h4>
                    </div>
                    <div class="col-auto">
                        <div class="btn-group">
                            <button class="btn btn-outline-primary" onclick="printInvoice()">
                                <i class="fas fa-print me-2"></i>Print
                            </button>
                            <button class="btn btn-outline-success" onclick="downloadPDF()">
                                <i class="fas fa-download me-2"></i>Download PDF
                            </button>
                            <button class="btn btn-outline-info" onclick="sendEmail()">
                                <i class="fas fa-envelope me-2"></i>Email
                            </button>
                        </div>
                        <a href="/sales" class="btn btn-outline-secondary ms-2">
                            <i class="fas fa-arrow-left me-2"></i>Back
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Invoice Content -->
        <div class="invoice-content p-4">
            <div class="container">
                <div class="invoice-card bg-white p-4 shadow-sm">
                    <!-- Invoice Header -->
                    <div class="row mb-4">
                        <div class="col-6">
                            <img src="/assets/img/logo.png" alt="<?= SITE_NAME ?>" class="invoice-logo mb-3">
                            <h4 class="company-name"><?= SITE_NAME ?></h4>
                            <p class="company-details mb-0">
                                123 Business Street<br>
                                Nairobi, Kenya<br>
                                Phone: +254 700 000000<br>
                                Email: info@agrovet.com
                            </p>
                        </div>
                        <div class="col-6 text-end">
                            <h1 class="invoice-title text-primary mb-3">INVOICE</h1>
                            <table class="invoice-info">
                                <tr>
                                    <td class="text-muted pe-2">Invoice Number:</td>
                                    <td class="fw-bold">#<?= $saleData['invoice_number'] ?></td>
                                </tr>
                                <tr>
                                    <td class="text-muted pe-2">Date:</td>
                                    <td><?= date('d M Y', strtotime($saleData['created_at'])) ?></td>
                                </tr>
                                <tr>
                                    <td class="text-muted pe-2">Time:</td>
                                    <td><?= date('H:i:s', strtotime($saleData['created_at'])) ?></td>
                                </tr>
                                <tr>
                                    <td class="text-muted pe-2">Payment Method:</td>
                                    <td class="text-capitalize"><?= $saleData['payment_method'] ?></td>
                                </tr>
                            </table>
                        </div>
                    </div>

                    <!-- Customer Information -->
                    <div class="row mb-4">
                        <div class="col-6">
                            <div class="customer-info p-3 bg-light rounded">
                                <h5 class="mb-3">Bill To:</h5>
                                <h6 class="mb-1"><?= htmlspecialchars($saleData['customer_name']) ?></h6>
                                <?php if ($saleData['customer_phone']): ?>
                                    <p class="mb-1">Phone: <?= htmlspecialchars($saleData['customer_phone']) ?></p>
                                <?php endif; ?>
                                <?php if ($saleData['customer_email']): ?>
                                    <p class="mb-0">Email: <?= htmlspecialchars($saleData['customer_email']) ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="payment-status text-end">
                                <span class="badge bg-<?= $saleData['payment_status'] === 'paid' ? 'success' : 'warning' ?> p-2">
                                    <?= ucfirst($saleData['payment_status']) ?>
                                </span>
                            </div>
                        </div>
                    </div>

                    <!-- Items Table -->
                    <div class="table-responsive mb-4">
                        <table class="table table-hover items-table">
                            <thead class="table-light">
                                <tr>
                                    <th>Item Description</th>
                                    <th class="text-center">Quantity</th>
                                    <th class="text-end">Unit Price</th>
                                    <th class="text-end">Amount</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($saleData['items'] as $item): ?>
                                <tr>
                                    <td>
                                        <h6 class="mb-0"><?= htmlspecialchars($item['name']) ?></h6>
                                        <?php if ($item['description']): ?>
                                            <small class="text-muted"><?= htmlspecialchars($item['description']) ?></small>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center"><?= $item['quantity'] ?></td>
                                    <td class="text-end">KES <?= number_format($item['unit_price'], 2) ?></td>
                                    <td class="text-end">KES <?= number_format($item['total'], 2) ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                            <tfoot class="table-light">
                                <tr>
                                    <td colspan="3" class="text-end fw-bold">Subtotal:</td>
                                    <td class="text-end">KES <?= number_format($saleData['subtotal'], 2) ?></td>
                                </tr>
                                <tr>
                                    <td colspan="3" class="text-end fw-bold">VAT (16%):</td>
                                    <td class="text-end">KES <?= number_format($saleData['vat'], 2) ?></td>
                                </tr>
                                <tr class="table-primary">
                                    <td colspan="3" class="text-end fw-bold">Total:</td>
                                    <td class="text-end fw-bold">KES <?= number_format($saleData['total'], 2) ?></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>

                    <!-- Payment Information -->
                    <?php if ($saleData['payment_method'] === 'cash'): ?>
                    <div class="row mb-4">
                        <div class="col-6 offset-6">
                            <table class="table table-sm payment-details">
                                <tr>
                                    <td class="text-end text-muted">Amount Tendered:</td>
                                    <td class="text-end">KES <?= number_format($saleData['amount_tendered'], 2) ?></td>
                                </tr>
                                <tr>
                                    <td class="text-end text-muted">Change:</td>
                                    <td class="text-end">KES <?= number_format($saleData['change_amount'], 2) ?></td>
                                </tr>
                            </table>
                        </div>
                    </div>
                    <?php endif; ?>

                    <!-- Terms and Notes -->
                    <div class="row">
                        <div class="col-12">
                            <div class="invoice-footer p-3 bg-light rounded">
                                <div class="row">
                                    <div class="col-md-8">
                                        <h6 class="mb-2">Terms & Conditions:</h6>
                                        <p class="mb-0 small">
                                            1. All items sold are non-returnable<br>
                                            2. Warranty claims must be accompanied by this invoice<br>
                                            3. Payment is due upon receipt of invoice
                                        </p>
                                    </div>
                                    <div class="col-md-4 text-end">
                                        <div class="qr-code">
                                            <img src="https://api.qrserver.com/v1/create-qr-code/?size=100x100&data=<?= urlencode(SITE_URL . '/verify/' . $saleData['invoice_number']) ?>" 
                                                 alt="Verify Invoice">
                                            <small class="d-block text-muted mt-1">Scan to verify</small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Email Modal -->
    <div class="modal fade" id="emailModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Send Invoice</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="emailForm">
                        <div class="mb-3">
                            <label class="form-label">Recipient Email</label>
                            <input type="email" class="form-control" id="recipientEmail" 
                                   value="<?= htmlspecialchars($saleData['customer_email'] ?? '') ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Subject</label>
                            <input type="text" class="form-control" id="emailSubject" 
                                   value="Invoice #<?= $saleData['invoice_number'] ?> from <?= SITE_NAME ?>">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Message</label>
                            <textarea class="form-control" id="emailMessage" rows="3">Please find attached your invoice. Thank you for your business!</textarea>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" onclick="sendInvoiceEmail()">Send</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
    <script src="/assets/js/invoice.js"></script>
</body>
</html>