<?php
require_once '../../config/config.php';
require_once '../../classes/Database.php';
require_once '../../classes/Session.php';
require_once '../../classes/Suppliers.php';

Session::init();

if (!Session::isLoggedIn()) {
    header('Location: ../../login.php');
    exit();
}

$currentDateTime = '2025-02-16 15:24:28';
$currentUser = 'musty131311';

$suppliers = new Suppliers();
$suppliersList = $suppliers->getAllSuppliers();
$recentOrders = $suppliers->getRecentOrders();

$pageTitle = 'Supplier Management - ' . SITE_NAME;
$currentPage = 'suppliers';
$extraCSS = ['/assets/css/suppliers.css'];
?>

<?php include '../../includes/header.php'; ?>

<div class="container-fluid py-4">
    <!-- Page Header -->
    <div class="row mb-4">
        <div class="col">
            <h2 class="mb-0">Supplier Management</h2>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="/dashboard">Dashboard</a></li>
                    <li class="breadcrumb-item active">Suppliers</li>
                </ol>
            </nav>
        </div>
        <div class="col-auto">
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#supplierModal">
                <i class="fas fa-plus me-2"></i>Add Supplier
            </button>
        </div>
    </div>

    <!-- Stats Cards -->
    <div class="row g-4 mb-4">
        <div class="col-sm-6 col-xl-3">
            <div class="card stats-card">
                <div class="card-body">
                    <div class="d-flex align-items-center justify-content-between mb-3">
                        <h6 class="card-subtitle text-muted">Total Suppliers</h6>
                        <div class="stats-icon bg-primary">
                            <i class="fas fa-users"></i>
                        </div>
                    </div>
                    <h3 class="card-title mb-0"><?= $suppliers->getTotalSuppliers() ?></h3>
                    <p class="text-muted mt-2 mb-0">
                        <i class="fas fa-arrow-up text-success me-1"></i>
                        <?= $suppliers->getGrowthRate() ?>% this month
                    </p>
                </div>
            </div>
        </div>

        <div class="col-sm-6 col-xl-3">
            <div class="card stats-card">
                <div class="card-body">
                    <div class="d-flex align-items-center justify-content-between mb-3">
                        <h6 class="card-subtitle text-muted">Active Orders</h6>
                        <div class="stats-icon bg-success">
                            <i class="fas fa-shopping-cart"></i>
                        </div>
                    </div>
                    <h3 class="card-title mb-0"><?= $suppliers->getActiveOrdersCount() ?></h3>
                    <p class="text-muted mt-2 mb-0">
                        <?= $suppliers->getPendingOrdersCount() ?> orders pending
                    </p>
                </div>
            </div>
        </div>

        <div class="col-sm-6 col-xl-3">
            <div class="card stats-card">
                <div class="card-body">
                    <div class="d-flex align-items-center justify-content-between mb-3">
                        <h6 class="card-subtitle text-muted">Total Spent</h6>
                        <div class="stats-icon bg-warning">
                            <i class="fas fa-money-bill-wave"></i>
                        </div>
                    </div>
                    <h3 class="card-title mb-0">KES <?= number_format($suppliers->getTotalSpent(), 2) ?></h3>
                    <p class="text-muted mt-2 mb-0">
                        Last 30 days
                    </p>
                </div>
            </div>
        </div>

        <div class="col-sm-6 col-xl-3">
            <div class="card stats-card">
                <div class="card-body">
                    <div class="d-flex align-items-center justify-content-between mb-3">
                        <h6 class="card-subtitle text-muted">Average Lead Time</h6>
                        <div class="stats-icon bg-info">
                            <i class="fas fa-clock"></i>
                        </div>
                    </div>
                    <h3 class="card-title mb-0"><?= $suppliers->getAverageLeadTime() ?> days</h3>
                    <p class="text-muted mt-2 mb-0">
                        Based on last 100 orders
                    </p>
                </div>
            </div>
        </div>
    </div>

    <!-- Suppliers List -->
    <div class="card mb-4">
        <div class="card-header bg-white p-4 d-flex justify-content-between align-items-center">
            <h5 class="mb-0">Suppliers Directory</h5>
            <div class="d-flex gap-2">
                <div class="input-group">
                    <span class="input-group-text bg-white border-end-0">
                        <i class="fas fa-search text-muted"></i>
                    </span>
                    <input type="text" id="supplierSearch" class="form-control border-start-0" 
                           placeholder="Search suppliers...">
                </div>
                <button class="btn btn-outline-primary" onclick="exportSuppliers()">
                    <i class="fas fa-file-export me-2"></i>Export
                </button>
            </div>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light">
                        <tr>
                            <th>Supplier</th>
                            <th>Contact Person</th>
                            <th>Contact Info</th>
                            <th>Products</th>
                            <th>Status</th>
                            <th>Performance</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($suppliersList as $supplier): ?>
                        <tr>
                            <td>
                                <div class="d-flex align-items-center">
                                    <div class="supplier-avatar me-3">
                                        <?php if ($supplier['logo']): ?>
                                            <img src="<?= htmlspecialchars($supplier['logo']) ?>" 
                                                 alt="<?= htmlspecialchars($supplier['name']) ?>">
                                        <?php else: ?>
                                            <div class="avatar-placeholder">
                                                <?= getInitials($supplier['name']) ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <div>
                                        <h6 class="mb-0"><?= htmlspecialchars($supplier['name']) ?></h6>
                                        <small class="text-muted">
                                            ID: <?= $supplier['supplier_code'] ?>
                                        </small>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <div>
                                    <?= htmlspecialchars($supplier['contact_person']) ?>
                                    <small class="text-muted d-block">
                                        <?= htmlspecialchars($supplier['position']) ?>
                                    </small>
                                </div>
                            </td>
                            <td>
                                <div>
                                    <i class="fas fa-phone text-muted me-1"></i>
                                    <?= htmlspecialchars($supplier['phone']) ?>
                                </div>
                                <div>
                                    <i class="fas fa-envelope text-muted me-1"></i>
                                    <?= htmlspecialchars($supplier['email']) ?>
                                </div>
                            </td>
                            <td>
                                <div class="d-flex align-items-center">
                                    <span class="me-2"><?= count($supplier['products']) ?></span>
                                    <button class="btn btn-link btn-sm p-0" 
                                            onclick="viewProducts(<?= $supplier['id'] ?>)">
                                        View List
                                    </button>
                                </div>
                            </td>
                            <td>
                                <span class="badge bg-<?= getStatusColor($supplier['status']) ?>">
                                    <?= ucfirst($supplier['status']) ?>
                                </span>
                            </td>
                            <td>
                                <div class="d-flex align-items-center">
                                    <?php
                                    $rating = $supplier['performance_rating'];
                                    for ($i = 1; $i <= 5; $i++):
                                    ?>
                                    <i class="fas fa-star <?= $i <= $rating ? 'text-warning' : 'text-muted' ?>"></i>
                                    <?php endfor; ?>
                                    <span class="ms-2"><?= number_format($rating, 1) ?></span>
                                </div>
                            </td>
                            <td>
                                <div class="dropdown">
                                    <button class="btn btn-light btn-sm" data-bs-toggle="dropdown">
                                        <i class="fas fa-ellipsis-v"></i>
                                    </button>
                                    <ul class="dropdown-menu">
                                        <li>
                                            <a class="dropdown-item" href="#" 
                                               onclick="editSupplier(<?= $supplier['id'] ?>)">
                                                <i class="fas fa-edit me-2"></i>Edit
                                            </a>
                                        </li>
                                        <li>
                                            <a class="dropdown-item" href="#" 
                                               onclick="viewOrders(<?= $supplier['id'] ?>)">
                                                <i class="fas fa-shopping-cart me-2"></i>View Orders
                                            </a>
                                        </li>
                                        <li>
                                            <a class="dropdown-item" href="#" 
                                               onclick="viewPerformance(<?= $supplier['id'] ?>)">
                                                <i class="fas fa-chart-line me-2"></i>Performance
                                            </a>
                                        </li>
                                        <li><hr class="dropdown-divider"></li>
                                        <li>
                                            <a class="dropdown-item text-danger" href="#" 
                                               onclick="deleteSupplier(<?= $supplier['id'] ?>)">
                                                <i class="fas fa-trash me-2"></i>Delete
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Recent Orders -->
    <div class="card">
        <div class="card-header bg-white p-4">
            <h5 class="mb-0">Recent Orders</h5>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light">
                        <tr>
                            <th>Order ID</th>
                            <th>Supplier</th>
                            <th>Products</th>
                            <th>Order Date</th>
                            <th>Expected Delivery</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recentOrders as $order): ?>
                        <tr>
                            <td>
                                <a href="#" class="text-primary fw-medium" 
                                   onclick="viewOrder('<?= $order['order_number'] ?>')">
                                    #<?= $order['order_number'] ?>
                                </a>
                            </td>
                            <td><?= htmlspecialchars($order['supplier_name']) ?></td>
                            <td><?= $order['item_count'] ?> items</td>
                            <td><?= formatDate($order['order_date']) ?></td>
                            <td><?= formatDate($order['expected_delivery']) ?></td>
                            <td>KES <?= number_format($order['total_amount'], 2) ?></td>
                            <td>
                                <span class="badge bg-<?= getOrderStatusColor($order['status']) ?>">
                                    <?= ucfirst($order['status']) ?>
                                </span>
                            </td>
                            <td>
                                <button class="btn btn-light btn-sm" 
                                        onclick="trackOrder('<?= $order['order_number'] ?>')">
                                    <i class="fas fa-truck me-1"></i>Track
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php
function getInitials($name) {
    $words = explode(' ', $name);
    $initials = '';
    foreach ($words as $word) {
        $initials .= strtoupper($word[0]);
    }
    return substr($initials, 0, 2);
}

function getStatusColor($status) {
    return match($status) {
        'active' => 'success',
        'pending' => 'warning',
        'inactive' => 'danger',
        default => 'secondary'
    };
}

function getOrderStatusColor($status) {
    return match($status) {
        'delivered' => 'success',
        'in_transit' => 'info',
        'pending' => 'warning',
        'cancelled' => 'danger',
        default => 'secondary'
    };
}

function formatDate($date) {
    return date('M d, Y', strtotime($date));
}
?>

<?php include '../../includes/footer.php'; ?>