<?php
require_once '../../config/config.php';
require_once '../../classes/Database.php';
require_once '../../classes/Session.php';
require_once '../../classes/Inventory.php';
require_once '../../classes/Sales.php';

Session::init();

if (!Session::isLoggedIn()) {
    header('Location: ../../login.php');
    exit();
}

$currentDateTime = '2025-02-16 15:09:52';
$currentUser = 'musty131311';

$inventory = new Inventory();
$products = $inventory->getAllProducts();
$categories = $inventory->getAllCategories();

$pageTitle = 'Point of Sale - ' . SITE_NAME;
$currentPage = 'pos';
$extraCSS = ['/assets/css/pos.css'];
?>

<?php include '../../includes/header.php'; ?>

<div class="pos-wrapper">
    <!-- Left Side - Products -->
    <div class="products-section">
        <!-- Search and Category Filters -->
        <div class="filters-bar sticky-top bg-white border-bottom">
            <div class="row g-3 p-3">
                <div class="col-md-6">
                    <div class="input-group">
                        <span class="input-group-text bg-white border-end-0">
                            <i class="fas fa-search text-muted"></i>
                        </span>
                        <input type="text" id="productSearch" class="form-control border-start-0" 
                               placeholder="Search products...">
                    </div>
                </div>
                <div class="col-md-6">
                    <select id="categoryFilter" class="form-select">
                        <option value="">All Categories</option>
                        <?php foreach ($categories as $category): ?>
                        <option value="<?= $category['id'] ?>">
                            <?= htmlspecialchars($category['name']) ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
        </div>

        <!-- Products Grid -->
        <div class="products-grid p-3">
            <div class="row g-3">
                <?php foreach ($products as $product): ?>
                <div class="col-6 col-sm-4 col-md-3 col-xl-2" 
                     data-category="<?= $product['category_id'] ?>"
                     data-search="<?= strtolower($product['name']) ?>">
                    <div class="product-card" data-id="<?= $product['id'] ?>">
                        <div class="product-image">
                            <?php if ($product['image']): ?>
                                <img src="<?= htmlspecialchars($product['image']) ?>" alt="<?= htmlspecialchars($product['name']) ?>">
                            <?php else: ?>
                                <div class="placeholder-image">
                                    <i class="fas fa-box"></i>
                                </div>
                            <?php endif; ?>
                            
                            <?php if ($product['stock_quantity'] <= $product['reorder_level']): ?>
                                <span class="stock-badge low-stock">Low Stock</span>
                            <?php endif; ?>
                        </div>
                        <div class="product-info">
                            <h6 class="product-name mb-1"><?= htmlspecialchars($product['name']) ?></h6>
                            <p class="product-price mb-1">KES <?= number_format($product['unit_price'], 2) ?></p>
                            <small class="text-muted">Stock: <?= $product['stock_quantity'] ?></small>
                        </div>
                        <button class="btn btn-add-to-cart <?= $product['stock_quantity'] == 0 ? 'disabled' : '' ?>"
                                <?= $product['stock_quantity'] == 0 ? 'disabled' : '' ?>>
                            <i class="fas fa-plus"></i>
                        </button>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <!-- Right Side - Cart -->
    <div class="cart-section">
        <div class="cart-header sticky-top bg-white border-bottom p-3">
            <h5 class="mb-3">Current Sale</h5>
            <div class="input-group mb-3">
                <span class="input-group-text bg-white border-end-0">
                    <i class="fas fa-user text-muted"></i>
                </span>
                <input type="text" id="customerName" class="form-control border-start-0" 
                       placeholder="Customer Name">
            </div>
            <div class="cart-actions">
                <button class="btn btn-outline-danger" id="clearCart">
                    <i class="fas fa-trash-alt me-1"></i> Clear
                </button>
                <button class="btn btn-outline-secondary" id="holdSale">
                    <i class="fas fa-pause me-1"></i> Hold
                </button>
                <button class="btn btn-outline-primary" id="loadSale">
                    <i class="fas fa-folder-open me-1"></i> Load
                </button>
            </div>
        </div>

        <div class="cart-items p-3">
            <!-- Cart items will be dynamically added here -->
            <div class="empty-cart text-center text-muted">
                <i class="fas fa-shopping-cart fa-3x mb-3"></i>
                <p>No items in cart</p>
            </div>
        </div>

        <div class="cart-footer">
            <div class="cart-summary p-3 border-top">
                <div class="summary-item d-flex justify-content-between mb-2">
                    <span>Subtotal</span>
                    <span id="subtotal">KES 0.00</span>
                </div>
                <div class="summary-item d-flex justify-content-between mb-2">
                    <span>VAT (16%)</span>
                    <span id="vat">KES 0.00</span>
                </div>
                <div class="summary-item d-flex justify-content-between mb-3">
                    <span class="fw-bold">Total</span>
                    <span id="total" class="fw-bold">KES 0.00</span>
                </div>

                <button class="btn btn-primary w-100" id="checkoutBtn" disabled>
                    <i class="fas fa-cash-register me-1"></i> Checkout
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Checkout Modal -->
<div class="modal fade" id="checkoutModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Complete Sale</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label class="form-label">Amount Due</label>
                    <h3 class="amount-due mb-3">KES 0.00</h3>
                </div>

                <div class="mb-3">
                    <label class="form-label">Payment Method</label>
                    <div class="payment-methods">
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="paymentMethod" 
                                   id="methodCash" value="cash" checked>
                            <label class="form-check-label" for="methodCash">Cash</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="paymentMethod" 
                                   id="methodMpesa" value="mpesa">
                            <label class="form-check-label" for="methodMpesa">M-Pesa</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="paymentMethod" 
                                   id="methodCard" value="card">
                            <label class="form-check-label" for="methodCard">Card</label>
                        </div>
                    </div>
                </div>

                <div id="cashPaymentFields">
                    <div class="mb-3">
                        <label class="form-label">Amount Tendered</label>
                        <div class="input-group">
                            <span class="input-group-text">KES</span>
                            <input type="number" class="form-control" id="amountTendered">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Change Due</label>
                        <h4 id="changeDue" class="text-success">KES 0.00</h4>
                    </div>
                </div>

                <div id="mpesaPaymentFields" style="display: none;">
                    <div class="mb-3">
                        <label class="form-label">Phone Number</label>
                        <input type="tel" class="form-control" id="mpesaPhone" 
                               placeholder="254700000000">
                    </div>
                </div>

                <div id="cardPaymentFields" style="display: none;">
                    <div class="mb-3">
                        <label class="form-label">Card Number</label>
                        <input type="text" class="form-control" id="cardNumber" 
                               placeholder="**** **** **** ****">
                    </div>
                    <div class="row">
                        <div class="col-6">
                            <div class="mb-3">
                                <label class="form-label">Expiry Date</label>
                                <input type="text" class="form-control" id="cardExpiry" 
                                       placeholder="MM/YY">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="mb-3">
                                <label class="form-label">CVV</label>
                                <input type="text" class="form-control" id="cardCvv" 
                                       placeholder="***">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary" id="completePayment">
                    Complete Payment
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Held Sales Modal -->
<div class="modal fade" id="heldSalesModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Held Sales</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="list-group" id="heldSalesList">
                    <!-- Held sales will be loaded here -->
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>