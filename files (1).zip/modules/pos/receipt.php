<?php
require_once '../../config/config.php';
require_once '../../classes/Database.php';
require_once '../../classes/Session.php';
require_once '../../classes/Sales.php';

Session::init();

if (!Session::isLoggedIn()) {
    header('Location: ../../login.php');
    exit();
}

if (!isset($_GET['id'])) {
    header('Location: index.php');
    exit();
}

$sales = new Sales();
$saleData = $sales->getSale($_GET['id']);

if (!$saleData) {
    header('Location: index.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Receipt - <?= SITE_NAME ?></title>
    <link rel="stylesheet" href="../../assets/css/receipt.css">
</head>
<body>
    <div class="receipt">
        <div class="receipt-header">
            <h1><?= SITE_NAME ?></h1>
            <p>123 Business Street</p>
            <p>Phone: +254 123 456 789</p>
            <p>Email: info@agrovet.com</p>
        </div>
        
        <div class="receipt-info">
            <p>Invoice #: <?= htmlspecialchars($saleData[0]['invoice_number']) ?></p>
            <p>Date: <?= date('Y-m-d H:i:s') ?></p>
            <p>Customer: <?= htmlspecialchars($saleData[0]['customer_name']) ?></p>
            <p>Served By: <?= htmlspecialchars(Session::get('username')) ?></p>
        </div>
        
        <table class="receipt-items">
            <thead>
                <tr>
                    <th>Item</th>
                    <th>Qty</th>
                    <th>Price</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($saleData as $item): ?>
                <tr>
                    <td><?= htmlspecialchars($item['product_name']) ?></td>
                    <td><?= $item['quantity'] ?></td>
                    <td><?= number_format($item['unit_price'], 2) ?></td>
                    <td><?= number_format($item['subtotal'], 2) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        
        <div class="receipt-summary">
            <div class="summary-item">
                <span>Subtotal:</span>
                <span>KES <?= number_format($saleData[0]['total_amount'] / 1.16, 2) ?></span>
            </div>
            <div class="summary-item">
                <span>VAT (16%):</span>
                <span>KES <?= number_format($saleData[0]['total_amount'] - ($saleData[0]['total_amount'] / 1.16), 2) ?></span>
            </div>
            <div class="summary-item total">
                <span>Total:</span>
                <span>KES <?= number_format($saleData[0]['total_amount'], 2) ?></span>
            </div>
        </div>
        
        <div class="receipt-footer">
            <p>Thank you for your business!</p>
            <p>Returns accepted within 7 days with receipt</p>
            <p>Terms and conditions apply</p>
        </div>
        
        <div class="receipt-actions">
            <button onclick="window.print()" class="btn btn-primary">Print Receipt</button>
            <a href="index.php" class="btn">New Sale</a>
        </div>
    </div>
</body>
</html>