<?php
class SystemTest {
    private $currentDateTime = '2025-02-16 16:13:01';
    private $currentUser = 'musty131311';

    public function runSystemCheck() {
        try {
            $results = [
                'timestamp' => $this->currentDateTime,
                'user' => $this->currentUser,
                'checks' => []
            ];

            // 1. Database Connection
            $results['checks']['database'] = $this->checkDatabase();

            // 2. Core Classes
            $results['checks']['core_classes'] = $this->checkCoreClasses();

            // 3. API Endpoints
            $results['checks']['api'] = $this->checkApiEndpoints();

            // 4. File Permissions
            $results['checks']['permissions'] = $this->checkFilePermissions();

            return $results;
        } catch (Exception $e) {
            return [
                'status' => 'error',
                'message' => $e->getMessage(),
                'timestamp' => $this->currentDateTime
            ];
        }
    }

    private function checkDatabase() {
        try {
            $db = Database::getInstance();
            $stmt = $db->query("SELECT 1");
            return [
                'status' => 'success',
                'message' => 'Database connection successful'
            ];
        } catch (Exception $e) {
            return [
                'status' => 'error',
                'message' => 'Database connection failed: ' . $e->getMessage()
            ];
        }
    }

    private function checkCoreClasses() {
        $requiredClasses = [
            'Products',
            'Sales',
            'Customers',
            'Suppliers',
            'Dashboard',
            'Settings',
            'AuditLog'
        ];

        $results = [];
        foreach ($requiredClasses as $class) {
            $results[$class] = class_exists($class);
        }

        return $results;
    }

    private function checkApiEndpoints() {
        $endpoints = [
            '/api/products' => ['GET', 'POST'],
            '/api/sales' => ['GET', 'POST'],
            '/api/customers' => ['GET', 'POST'],
            '/api/dashboard/summary' => ['GET']
        ];

        $results = [];
        foreach ($endpoints as $endpoint => $methods) {
            foreach ($methods as $method) {
                $results[$endpoint][$method] = $this->testEndpoint($endpoint, $method);
            }
        }

        return $results;
    }

    private function testEndpoint($endpoint, $method) {
        try {
            // Simulate API request
            $router = new ApiRouter();
            $response = $router->handleRequest($method, $endpoint);
            
            return [
                'status' => 'success',
                'response_code' => 200
            ];
        } catch (Exception $e) {
            return [
                'status' => 'error',
                'message' => $e->getMessage()
            ];
        }
    }

    private function checkFilePermissions() {
        $directories = [
            'uploads/',
            'backups/',
            'logs/',
            'cache/'
        ];

        $results = [];
        foreach ($directories as $dir) {
            $results[$dir] = [
                'exists' => is_dir($dir),
                'writable' => is_writable($dir)
            ];
        }

        return $results;
    }
}

// Run the test
$test = new SystemTest();
$results = $test->runSystemCheck();

// Output results
header('Content-Type: application/json');
echo json_encode($results, JSON_PRETTY_PRINT);