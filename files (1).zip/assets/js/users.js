        editUser: async function(userId) {
            try {
                const response = await fetch(`/api/users/${userId}`);
                const user = await response.json();
                
                if (user) {
                    this.fillUserForm(user);
                    const modal = new bootstrap.Modal(document.getElementById('userModal'));
                    modal.show();
                }
            } catch (error) {
                this.showToast('Error loading user details', 'danger');
            }
        },

        fillUserForm: function(user) {
            const form = document.getElementById('userForm');
            form.querySelector('#userId').value = user.id;
            form.querySelector('input[name="name"]').value = user.name;
            form.querySelector('input[name="email"]').value = user.email;
            form.querySelector('select[name="role"]').value = user.role_id;
            form.querySelector('input[name="phone"]').value = user.phone || '';
            
            // Update modal title
            document.getElementById('modalTitle').textContent = 'Edit User';
        },

        resetForm: function() {
            const form = document.getElementById('userForm');
            form.reset();
            form.querySelector('#userId').value = '';
            document.getElementById('modalTitle').textContent = 'Add User';
        },

        saveUser: async function() {
            const form = document.getElementById('userForm');
            const formData = new FormData(form);
            const userId = form.querySelector('#userId').value;

            try {
                const response = await fetch(`/api/users/${userId || 'new'}`, {
                    method: userId ? 'PUT' : 'POST',
                    body: formData,
                    headers: {
                        'X-Timestamp': this.currentDateTime,
                        'X-User': this.currentUser
                    }
                });

                const result = await response.json();

                if (result.success) {
                    this.showToast('User saved successfully', 'success');
                    bootstrap.Modal.getInstance(document.getElementById('userModal')).hide();
                    window.location.reload();
                } else {
                    throw new Error(result.message);
                }
            } catch (error) {
                this.showToast(error.message || 'Error saving user', 'danger');
            }
        },

        resetPassword: async function(userId) {
            if (!confirm('Are you sure you want to reset this user\'s password?')) {
                return;
            }

            try {
                const response = await fetch(`/api/users/${userId}/reset-password`, {
                    method: 'POST',
                    headers: {
                        'X-Timestamp': this.currentDateTime,
                        'X-User': this.currentUser
                    }
                });

                const result = await response.json();

                if (result.success) {
                    this.showToast('Password reset email sent', 'success');
                } else {
                    throw new Error(result.message);
                }
            } catch (error) {
                this.showToast('Error resetting password', 'danger');
            }
        },

        viewActivity: async function(userId) {
            try {
                const response = await fetch(`/api/users/${userId}/activity`);
                const activity = await response.json();
                
                this.showActivityModal(activity);
            } catch (error) {
                this.showToast('Error loading user activity', 'danger');
            }
        },

        showActivityModal: function(activity) {
            const modal = document.createElement('div');
            modal.className = 'modal fade';
            modal.innerHTML = `
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">User Activity Log</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="activity-timeline">
                                ${activity.map(item => `
                                    <div class="activity-item">
                                        <div class="activity-icon bg-${this.getActivityColor(item.type)}">
                                            <i class="fas ${this.getActivityIcon(item.type)}"></i>
                                        </div>
                                        <div class="activity-content">
                                            <div class="d-flex justify-content-between align-items-center mb-1">
                                                <h6 class="mb-0">${this.escapeHtml(item.action)}</h6>
                                                <small class="text-muted">${this.formatDate(item.timestamp)}</small>
                                            </div>
                                            <p class="mb-0">${this.escapeHtml(item.description)}</p>
                                            <small class="text-muted">
                                                <i class="fas fa-map-marker-alt me-1"></i>${this.escapeHtml(item.ip_address)}
                                            </small>
                                        </div>
                                    </div>
                                `).join('')}
                            </div>
                        </div>
                    </div>
                </div>
            `;

            document.body.appendChild(modal);
            const modalInstance = new bootstrap.Modal(modal);
            modalInstance.show();

            modal.addEventListener('hidden.bs.modal', () => {
                modal.remove();
            });
        },

        unlockAccount: async function(userId) {
            if (!confirm('Are you sure you want to unlock this account?')) {
                return;
            }

            try {
                const response = await fetch(`/api/users/${userId}/unlock`, {
                    method: 'POST',
                    headers: {
                        'X-Timestamp': this.currentDateTime,
                        'X-User': this.currentUser
                    }
                });

                const result = await response.json();

                if (result.success) {
                    this.showToast('Account unlocked successfully', 'success');
                    window.location.reload();
                } else {
                    throw new Error(result.message);
                }
            } catch (error) {
                this.showToast('Error unlocking account', 'danger');
            }
        },

        toggleUserStatus: async function(userId, action) {
            if (!confirm(`Are you sure you want to ${action} this user?`)) {
                return;
            }

            try {
                const response = await fetch(`/api/users/${userId}/${action}`, {
                    method: 'POST',
                    headers: {
                        'X-Timestamp': this.currentDateTime,
                        'X-User': this.currentUser
                    }
                });

                const result = await response.json();

                if (result.success) {
                    this.showToast(`User ${action}d successfully`, 'success');
                    window.location.reload();
                } else {
                    throw new Error(result.message);
                }
            } catch (error) {
                this.showToast(`Error ${action}ing user`, 'danger');
            }
        },

        deleteUser: async function(userId) {
            if (!confirm('Are you sure you want to delete this user? This action cannot be undone.')) {
                return;
            }

            try {
                const response = await fetch(`/api/users/${userId}`, {
                    method: 'DELETE',
                    headers: {
                        'X-Timestamp': this.currentDateTime,
                        'X-User': this.currentUser
                    }
                });

                const result = await response.json();

                if (result.success) {
                    this.showToast('User deleted successfully', 'success');
                    window.location.reload();
                } else {
                    throw new Error(result.message);
                }
            } catch (error) {
                this.showToast('Error deleting user', 'danger');
            }
        },

        getActivityColor: function(type) {
            const colors = {
                login: 'success',
                logout: 'secondary',
                create: 'primary',
                update: 'info',
                delete: 'danger',
                password: 'warning',
                settings: 'purple'
            };
            return colors[type] || 'secondary';
        },

        getActivityIcon: function(type) {
            const icons = {
                login: 'fa-sign-in-alt',
                logout: 'fa-sign-out-alt',
                create: 'fa-plus-circle',
                update: 'fa-edit',
                delete: 'fa-trash',
                password: 'fa-key',
                settings: 'fa-cog'
            };
            return icons[type] || 'fa-circle';
        },

        formatDate: function(timestamp) {
            return new Date(timestamp).toLocaleString();
        },

        escapeHtml: function(unsafe) {
            return unsafe
                .replace(/&/g, "&amp;")
                .replace(/</g, "&lt;")
                .replace(/>/g, "&gt;")
                .replace(/"/g, "&quot;")
                .replace(/'/g, "&#039;");
        },

        showToast: function(message, type = 'info') {
            const toastEl = document.createElement('div');
            toastEl.className = `toast align-items-center text-white bg-${type} border-0`;
            toastEl.setAttribute('role', 'alert');
            toastEl.setAttribute('aria-live', 'assertive');
            toastEl.setAttribute('aria-atomic', 'true');

            toastEl.innerHTML = `
                <div class="d-flex">
                    <div class="toast-body">${message}</div>
                    <button type="button" class="btn-close btn-close-white me-2 m-auto" 
                            data-bs-dismiss="toast"></button>
                </div>
            `;

            const container = document.createElement('div');
            container.className = 'toast-container position-fixed bottom-0 end-0 p-3';
            container.appendChild(toastEl);
            document.body.appendChild(container);

            const toast = new bootstrap.Toast(toastEl);
            toast.show();

            toastEl.addEventListener ▋