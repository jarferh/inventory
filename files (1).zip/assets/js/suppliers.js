document.addEventListener('DOMContentLoaded', function() {
    const Suppliers = {
        currentDateTime: '2025-02-16 15:25:52',
        currentUser: 'musty131311',
        charts: {},
        
        init: function() {
            this.initializeSearch();
            this.initializeCharts();
            this.setupEventListeners();
        },

        initializeSearch: function() {
            const searchInput = document.getElementById('supplierSearch');
            if (searchInput) {
                let timeout = null;
                searchInput.addEventListener('input', (e) => {
                    clearTimeout(timeout);
                    timeout = setTimeout(() => {
                        this.filterSuppliers(e.target.value.toLowerCase());
                    }, 300);
                });
            }
        },

        filterSuppliers: function(query) {
            const rows = document.querySelectorAll('tbody tr');
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(query) ? '' : 'none';
            });
        },

        initializeCharts: function() {
            // Performance trend chart
            const ctx = document.getElementById('performanceChart');
            if (ctx) {
                this.charts.performance = new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                        datasets: [{
                            label: 'On-Time Delivery',
                            data: [85, 88, 92, 87, 94, 90],
                            borderColor: '#0d6efd',
                            tension: 0.4
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: {
                                display: false
                            }
                        },
                        scales: {
                            y: {
                                beginAtZero: true,
                                max: 100
                            }
                        }
                    }
                });
            }
        },

        setupEventListeners: function() {
            document.querySelectorAll('[data-bs-toggle="modal"]').forEach(element => {
                element.addEventListener('click', (e) => {
                    const target = e.target.getAttribute('data-bs-target');
                    if (target === '#supplierModal') {
                        this.resetForm();
                    }
                });
            });
        },

        editSupplier: async function(supplierId) {
            try {
                const response = await fetch(`/api/suppliers/${supplierId}`);
                const supplier = await response.json();
                
                if (supplier) {
                    this.fillSupplierForm(supplier);
                    const modal = new bootstrap.Modal(document.getElementById('supplierModal'));
                    modal.show();
                }
            } catch (error) {
                this.showToast('Error loading supplier details', 'danger');
            }
        },

        fillSupplierForm: function(supplier) {
            const form = document.getElementById('supplierForm');
            for (const [key, value] of Object.entries(supplier)) {
                const input = form.querySelector(`[name="${key}"]`);
                if (input) {
                    input.value = value;
                }
            }
        },

        saveSupplier: async function() {
            const form = document.getElementById('supplierForm');
            const formData = new FormData(form);
            const supplierId = formData.get('supplier_id');

            try {
                const response = await fetch(`/api/suppliers/${supplierId || 'new'}`, {
                    method: supplierId ? 'PUT' : 'POST',
                    body: formData
                });

                const result = await response.json();

                if (result.success) {
                    this.showToast('Supplier saved successfully', 'success');
                    bootstrap.Modal.getInstance(document.getElementById('supplierModal')).hide();
                    window.location.reload();
                } else {
                    throw new Error(result.message);
                }
            } catch (error) {
                this.showToast(error.message || 'Error saving supplier', 'danger');
            }
        },

        viewProducts: async function(supplierId) {
            try {
                const response = await fetch(`/api/suppliers/${supplierId}/products`);
                const products = await response.json();
                
                // Implement products view modal
                this.showProductsModal(products);
            } catch (error) {
                this.showToast('Error loading supplier products', 'danger');
            }
        },

        viewOrders: async function(supplierId) {
            try {
                const response = await fetch(`/api/suppliers/${supplierId}/orders`);
                const orders = await response.json();
                
                // Implement orders view modal
                this.showOrdersModal(orders);
            } catch (error) {
                this.showToast('Error loading supplier orders', 'danger');
            }
        },

        viewPerformance: async function(supplierId) {
            try {
                const response = await fetch(`/api/suppliers/${supplierId}/performance`);
                const performance = await response.json();
                
                // Implement performance view modal
                this.showPerformanceModal(performance);
            } catch (error) {
                this.showToast('Error loading supplier performance', 'danger');
            }
        },

        deleteSupplier: async function(supplierId) {
            if (!confirm('Are you sure you want to delete this supplier?')) {
                return;
            }

            try {
                const response = await fetch(`/api/suppliers/${supplierId}`, {
                    method: 'DELETE'
                });

                const result = await response.json();

                if (result.success) {
                    this.showToast('Supplier deleted successfully', 'success');
                    window.location.reload();
                } else {
                    throw new Error(result.message);
                }
            } catch (error) {
                this.showToast('Error deleting supplier', 'danger');
            }
        },

        trackOrder: async function(orderNumber) {
            try {
                const response = await fetch(`/api/orders/${orderNumber}/tracking`);
                const tracking = await response.json();
                
                // Implement order tracking modal
                this.showTrackingModal(tracking);
            } catch (error) {
                this.showToast('Error loading order tracking', 'danger');
            }
        },

        exportSuppliers: async function() {
            try {
                const response = await fetch('/api/suppliers/export');
                const blob = await response.blob();
                
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `suppliers_export_${this.currentDateTime.replace(/[^0-9]/g, '')}.xlsx`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                window.URL.revokeObjectURL(url);
            } catch (error) {
                this.showToast('Error exporting suppliers', 'danger');
            }
        },

        showToast: function(message, type = 'info') {
            const toastEl = document.createElement('div');
            toastEl.className = `toast align-items-center text-white bg-${type} border-0`;
            toastEl.setAttribute('role', 'alert');
            toastEl.setAttribute('aria-live', 'assertive');
            toastEl.setAttribute('aria-atomic', 'true');

            toastEl.innerHTML = `
                <div class="d-flex">
                    <div class="toast-body">${message}</div>
                    <button type="button" class="btn-close btn-close-white me-2 m-auto" 
                            data-bs-dismiss="toast"></button>
                </div>
            `;

            const container = document.createElement('div');
            container.className = 'toast-container position-fixed bottom-0 end-0 p-3';
            container.appendChild(toastEl);
            document.body.appendChild(container);

            const toast = new bootstrap.Toast(toastEl);
            toast.show();

            toastEl.addEventListener('hidden.bs.toast', () => container.remove());
        }
    };

    // Initialize Supplier Management
    Suppliers.init();
    window.Suppliers = Suppliers;
});