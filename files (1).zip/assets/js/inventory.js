document.addEventListener('DOMContentLoaded', function() {
    const Inventory = {
        currentDateTime: '2025-02-16 15:22:42',
        currentUser: 'musty131311',
        
        init: function() {
            this.initializeFormHandlers();
            this.initializeModals();
            this.initializeFilters();
        },

        initializeFormHandlers: function() {
            const filterForm = document.getElementById('filterForm');
            if (filterForm) {
                filterForm.querySelectorAll('select, input').forEach(element => {
                    element.addEventListener('change', () => filterForm.submit());
                });
            }
        },

        initializeModals: function() {
            this.productModal = new bootstrap.Modal(document.getElementById('productModal'));
        },

        initializeFilters: function() {
            const searchInput = document.querySelector('input[name="search"]');
            if (searchInput) {
                let timeout = null;
                searchInput.addEventListener('input', (e) => {
                    clearTimeout(timeout);
                    timeout = setTimeout(() => {
                        document.getElementById('filterForm').submit();
                    }, 500);
                });
            }
        },

        editProduct: async function(productId) {
            try {
                const response = await fetch(`/api/inventory/product/${productId}`);
                const product = await response.json();
                
                if (product) {
                    this.fillProductForm(product);
                    document.getElementById('modalTitle').textContent = 'Edit Product';
                    this.productModal.show();
                }
            } catch (error) {
                this.showToast('Error loading product details', 'danger');
                console.error('Error:', error);
            }
        },

        fillProductForm: function(product) {
            const form = document.getElementById('productForm');
            form.querySelector('#productId').value = product.id;
            form.querySelector('input[name="name"]').value = product.name;
            form.querySelector('select[name="category_id"]').value = product.category_id;
            form.querySelector('input[name="unit_price"]').value = product.unit_price;
            form.querySelector('input[name="reorder_level"]').value = product.reorder_level;
            form.querySelector('textarea[name="description"]').value = product.description || '';
        },

        saveProduct: async function() {
            const form = document.getElementById('productForm');
            const formData = new FormData(form);
            const productId = form.querySelector('#productId').value;

            try {
                const response = await fetch(`/api/inventory/product/${productId || 'new'}`, {
                    method: productId ? 'PUT' : 'POST',
                    body: formData
                });

                const result = await response.json();

                if (result.success) {
                    this.showToast('Product saved successfully', 'success');
                    this.productModal.hide();
                    window.location.reload();
                } else {
                    throw new Error(result.message);
                }
            } catch (error) {
                this.showToast(error.message || 'Error saving product', 'danger');
            }
        },

        restockProduct: function(productId) {
            // Implement restock functionality
            this.showToast('Restock feature coming soon', 'info');
        },

        viewHistory: async function(productId) {
            try {
                const response = await fetch(`/api/inventory/product/${productId}/history`);
                const history = await response.json();
                
                // Implement history view
                console.log(history);
            } catch (error) {
                this.showToast('Error loading product history', 'danger');
            }
        },

        deleteProduct: async function(productId) {
            if (!confirm('Are you sure you want to delete this product?')) {
                return;
            }

            try {
                const response = await fetch(`/api/inventory/product/${productId}`, {
                    method: 'DELETE'
                });

                const result = await response.json();

                if (result.success) {
                    this.showToast('Product deleted successfully', 'success');
                    window.location.reload();
                } else {
                    throw new Error(result.message);
                }
            } catch (error) {
                this.showToast('Error deleting product', 'danger');
            }
        },

        importProducts: function() {
            const input = document.createElement('input');
            input.type = 'file';
            input.accept = '.csv,.xlsx';
            
            input.onchange = async (e) => {
                const file = e.target.files[0];
                if (file) {
                    const formData = new FormData();
                    formData.append('file', file);
                    
                    try {
                        const response = await fetch('/api/inventory/import', {
                            method: 'POST',
                            body: formData
                        });

                        const result = await response.json();

                        if (result.success) {
                            this.showToast(`Imported ${result.count} products successfully`, 'success');
                            window.location.reload();
                        } else {
                            throw new Error(result.message);
                        }
                    } catch (error) {
                        this.showToast('Error importing products', 'danger');
                    }
                }
            };

            input.click();
        },

        exportInventory: async function() {
            try {
                const response = await fetch('/api/inventory/export');
                const blob = await response.blob();
                
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `inventory_export_${this.currentDateTime.replace(/[^0-9]/g, '')}.xlsx`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                window.URL.revokeObjectURL(url);
            } catch (error) {
                this.showToast('Error exporting inventory', 'danger');
            }
        },

        showToast: function(message, type = 'info') {
            const toastEl = document.createElement('div');
            toastEl.className = `toast align-items-center text-white bg-${type} border-0`;
            toastEl.setAttribute('role', 'alert');
            toastEl.setAttribute('aria-live', 'assertive');
            toastEl.setAttribute('aria-atomic', 'true');

            toastEl.innerHTML = `
                <div class="d-flex">
                    <div class="toast-body">${message}</div>
                    <button type="button" class="btn-close btn-close-white me-2 m-auto" 
                            data-bs-dismiss="toast"></button>
                </div>
            `;

            const container = document.createElement('div');
            container.className = 'toast-container position-fixed bottom-0 end-0 p-3';
            container.appendChild(toastEl);
            document.body.appendChild(container);

            const toast = new bootstrap.Toast(toastEl);
            toast.show();

            toastEl.addEventListener('hidden.bs.toast', () => container.remove());
        }
    };

    // Initialize Inventory Management
    Inventory.init();
    window.Inventory = Inventory;
});