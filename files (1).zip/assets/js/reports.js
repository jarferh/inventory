document.addEventListener('DOMContentLoaded', function() {
    const Reports = {
        currentDateTime: '2025-02-16 15:29:27',
        currentUser: 'musty131311',
        charts: {},
        
        init: function() {
            this.initializeDateRange();
            this.initializeCharts();
            this.setupEventListeners();
        },

        initializeDateRange: function() {
            const dateRange = document.getElementById('dateRange');
            dateRange.addEventListener('change', (e) => {
                if (e.target.value === 'custom') {
                    document.getElementById('customDateRange').style.display = 'block';
                } else {
                    document.getElementById('customDateRange').style.display = 'none';
                    this.updateReports(e.target.value);
                }
            });
        },

        initializeCharts: function() {
            this.initializeSalesTrendChart();
            this.initializeCategoryChart();
            this.initializePaymentMethodsChart();
        },

        initializeSalesTrendChart: function() {
            const ctx = document.getElementById('salesTrendChart');
            if (!ctx) return;

            this.charts.salesTrend = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: this.getSalesTrendLabels(),
                    datasets: [{
                        label: 'Sales',
                        data: this.getSalesTrendData(),
                        borderColor: '#0d6efd',
                        backgroundColor: 'rgba(13, 110, 253, 0.1)',
                        fill: true,
                        tension: 0.4,
                        pointRadius: 4,
                        pointBackgroundColor: '#ffffff',
                        pointBorderColor: '#0d6efd',
                        pointBorderWidth: 2
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        },
                        tooltip: {
                            mode: 'index',
                            intersect: false,
                            callbacks: {
                                label: function(context) {
                                    return 'KES ' + context.parsed.y.toLocaleString();
                                }
                            }
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                callback: function(value) {
                                    return 'KES ' + value.toLocaleString();
                                }
                            }
                        }
                    }
                }
            });
        },

        initializeCategoryChart: function() {
            const ctx = document.getElementById('categoryChart');
            if (!ctx) return;

            this.charts.category = new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: this.getCategoryLabels(),
                    datasets: [{
                        data: this.getCategoryData(),
                        backgroundColor: [
                            'rgba(13, 110, 253, 0.8)',
                            'rgba(25, 135, 84, 0.8)',
                            'rgba(255, 193, 7, 0.8)',
                            'rgba(13, 202, 240, 0.8)',
                            'rgba(108, 117, 125, 0.8)'
                        ]
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'right'
                        }
                    }
                }
            });
        },

        initializePaymentMethodsChart: function() {
            const ctx = document.getElementById('paymentMethodsChart');
            if (!ctx) return;

            this.charts.paymentMethods = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: ['Cash', 'M-Pesa', 'Card', 'Bank Transfer'],
                    datasets: [{
                        label: 'Amount',
                        data: this.getPaymentMethodData(),
                        backgroundColor: 'rgba(13, 110, 253, 0.8)'
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                callback: function(value) {
                                    return 'KES ' + value.toLocaleString();
                                }
                            }
                        }
                    }
                }
            });
        },

        setupEventListeners: function() {
            document.querySelectorAll('[data-chart-view]').forEach(button => {
                button.addEventListener('click', (e) => {
                    this.updateChartView(e.target.dataset.chartView);
                });
            });
        },

        updateChartView: function(view) {
            // Update active button state
            document.querySelectorAll('[data-chart-view]').forEach(button => {
                button.classList.remove('active');
                if (button.dataset.chartView === view) {
                    button.classList.add('active');
                }
            });

            // Update chart data based on view
            this.updateSalesTrendChart(view);
        },

        updateSalesTrendChart: async function(view) {
            try {
                const response = await fetch(`/api/reports/sales-trend?view=${view}`);
                const data = await response.json();
                
                this.charts.salesTrend.data.labels = data.labels;
                this.charts.salesTrend.data.datasets[0].data = data.values;
                this.charts.salesTrend.update();
            } catch (error) {
                this.showToast('Error updating chart', 'danger');
            }
        },

        applyDateRange: async function() {
            const startDate = document.getElementById('startDate').value;
            const endDate = document.getElementById('endDate').value;

            if (!startDate || !endDate) {
                this.showToast('Please select both start and end dates', 'warning');
                return;
            }

            if (new Date(startDate) > new Date(endDate)) {
                this.showToast('Start date cannot be after end date', 'warning');
                return;
            }

            await this.updateReports('custom', { startDate, endDate });
        },

        updateReports: async function(range, dates = null) {
            try {
                const params = new URLSearchParams({ range });
                if (dates) {
                    params.append('startDate', dates.startDate);
                    params.append('endDate', dates.endDate);
                }

                window.location.href = `/reports?${params.toString()}`;
            } catch (error) {
                this.showToast('Error updating reports', 'danger');
            }
        },

        exportReport: async function() {
            try {
                const dateRange = document.getElementById('dateRange').value;
                let params = new URLSearchParams({ range: dateRange });

                if (dateRange === 'custom') {
                    params.append('startDate', document.getElementById('startDate').value);
                    params.append('endDate', document.getElementById('endDate').value);
                }

                const response = await fetch(`/api/reports/export?${params.toString()}`);
                const blob = await response.blob();
                
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `sales_report_${this.currentDateTime.replace(/[^0-9]/g, '')}.xlsx`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                window.URL.revokeObjectURL(url);
            } catch (error) {
                this.showToast('Error exporting report', 'danger');
            }
        },

        showToast: function(message, type = 'info') {
            const toastEl = document.createElement('div');
            toastEl.className = `toast align-items-center text-white bg-${type} border-0`;
            toastEl.setAttribute('role', 'alert');
            toastEl.setAttribute('aria-live', 'assertive');
            toastEl.setAttribute('aria-atomic', 'true');

            toastEl.innerHTML = `
                <div class="d-flex">
                    <div class="toast-body">${message}</div>
                    <button type="button" class="btn-close btn-close-white me-2 m-auto" 
                            data-bs-dismiss="toast"></button>
                </div>
            `;

            const container = document.createElement('div');
            container.className = 'toast-container position-fixed bottom-0 end-0 p-3';
            container.appendChild(toastEl);
            document.body.appendChild(container);

            const toast = new bootstrap.Toast(toastEl);
            toast.show();

            toastEl.addEventListener('hidden.bs.toast', () => container.remove());
        }
    };

    // Initialize Reports
    Reports.init();
    window.Reports = Reports;
});