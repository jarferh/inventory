document.addEventListener('DOMContentLoaded', function() {
    const Invoice = {
        currentDateTime: '2025-02-16 15:17:10',
        currentUser: 'musty131311',
        
        init: function() {
            this.initModals();
            this.setupEventListeners();
        },

        initModals: function() {
            this.emailModal = new bootstrap.Modal(document.getElementById('emailModal'));
        },

        setupEventListeners: function() {
            document.getElementById('emailForm').addEventListener('submit', (e) => {
                e.preventDefault();
                this.sendInvoiceEmail();
            });
        },

        downloadPDF: async function() {
            const invoice = document.querySelector('.invoice-card');
            const options = {
                margin: [10, 10],
                filename: `invoice-${document.querySelector('.invoice-title').textContent}.pdf`,
                image: { type: 'jpeg', quality: 0.98 },
                html2canvas: { scale: 2, useCORS: true },
                jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
            };

            // Show loading indicator
            this.showToast('Generating PDF...', 'info');

            try {
                await html2pdf().set(options).from(invoice).save();
                this.showToast('PDF downloaded successfully', 'success');
            } catch (error) {
                console.error('PDF generation error:', error);
                this.showToast('Error generating PDF', 'danger');
            }
        },

        printInvoice: function() {
            window.print();
        },

        showEmailModal: function() {
            this.emailModal.show();
        },

        sendInvoiceEmail: async function() {
            const emailData = {
                recipient: document.getElementById('recipientEmail').value,
                subject: document.getElementById('emailSubject').value,
                message: document.getElementById('emailMessage').value,
                invoiceId: this.getInvoiceIdFromUrl(),
                timestamp: this.currentDateTime,
                user: this.currentUser
            };

            try {
                const response = await fetch('/api/invoice/send-email', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(emailData)
                });

                const result = await response.json();

                if (result.success) {
                    this.emailModal.hide();
                    this.showToast('Invoice sent successfully', 'success');
                } else {
                    throw new Error(result.message);
                }
            } catch (error) {
                console.error('Email sending error:', error);
                this.showToast('Error sending email: ' + error.message, 'danger');
            }
        },

        showToast: function(message, type = 'info') {
            const toastEl = document.createElement('div');
            toastEl.className = `toast align-items-center text-white bg-${type} border-0`;
            toastEl.setAttribute('role', 'alert');
            toastEl.setAttribute('aria-live', 'assertive');
            toastEl.setAttribute('aria-atomic', 'true');

            toastEl.innerHTML = `
                <div class="d-flex">
                    <div class="toast-body">${message}</div>
                    <button type="button" class="btn-close btn-close-white me-2 m-auto" 
                            data-bs-dismiss="toast"></button>
                </div>
            `;

            const container = document.createElement('div');
            container.className = 'toast-container position-fixed bottom-0 end-0 p-3';
            container.appendChild(toastEl);
            document.body.appendChild(container);

            const toast = new bootstrap.Toast(toastEl);
            toast.show();

            toastEl.addEventListener('hidden.bs.toast', () => container.remove());
        },

        getInvoiceIdFromUrl: function() {
            const urlParams = new URLSearchParams(window.location.search);
            return urlParams.get('id');
        }
    };

    // Initialize Invoice functionality
    Invoice.init();
    window.Invoice = Invoice;
});