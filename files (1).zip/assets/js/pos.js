document.addEventListener('DOMContentLoaded', function() {
    const POS = {
        cart: [],
        currentDateTime: '2025-02-16 15:11:59',
        currentUser: 'musty131311',
        
        init: function() {
            this.bindEvents();
            this.loadHeldSales();
            this.updateCartDisplay();
        },
        
        bindEvents: function() {
            // Product search
            document.getElementById('productSearch').addEventListener('input', (e) => {
                this.filterProducts(e.target.value.toLowerCase());
            });
            
            // Category filter
            document.getElementById('categoryFilter').addEventListener('change', (e) => {
                this.filterByCategory(e.target.value);
            });
            
            // Add to cart buttons
            document.querySelectorAll('.btn-add-to-cart').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    const card = e.target.closest('.product-card');
                    this.addToCart(this.getProductFromCard(card));
                });
            });
            
            // Cart actions
            document.getElementById('clearCart').addEventListener('click', () => this.clearCart());
            document.getElementById('holdSale').addEventListener('click', () => this.holdCurrentSale());
            document.getElementById('loadSale').addEventListener('click', () => this.showHeldSales());
            document.getElementById('checkoutBtn').addEventListener('click', () => this.showCheckoutModal());
            
            // Payment method change
            document.querySelectorAll('input[name="paymentMethod"]').forEach(radio => {
                radio.addEventListener('change', (e) => this.togglePaymentFields(e.target.value));
            });
            
            // Amount tendered calculation
            document.getElementById('amountTendered').addEventListener('input', (e) => {
                this.calculateChange(e.target.value);
            });
            
            // Complete payment
            document.getElementById('completePayment').addEventListener('click', () => this.processSale());
        },
        
        getProductFromCard: function(card) {
            return {
                id: card.dataset.id,
                name: card.querySelector('.product-name').textContent,
                price: parseFloat(card.querySelector('.product-price').textContent.replace('KES ', '')),
                stock: parseInt(card.querySelector('.text-muted').textContent.replace('Stock: ', ''))
            };
        },
        
        addToCart: function(product) {
            const existingItem = this.cart.find(item => item.id === product.id);
            
            if (existingItem) {
                if (existingItem.quantity < product.stock) {
                    existingItem.quantity++;
                    existingItem.total = existingItem.quantity * existingItem.price;
                } else {
                    this.showToast('Maximum stock reached for this item', 'warning');
                    return;
                }
            } else {
                this.cart.push({
                    id: product.id,
                    name: product.name,
                    price: product.price,
                    quantity: 1,
                    total: product.price
                });
            }
            
            this.updateCartDisplay();
            this.showToast('Item added to cart', 'success');
        },
        
        updateCartDisplay: function() {
            const cartContainer = document.querySelector('.cart-items');
            const emptyCart = document.querySelector('.empty-cart');
            
            if (this.cart.length === 0) {
                emptyCart.style.display = 'block';
                cartContainer.innerHTML = '';
                document.getElementById('checkoutBtn').disabled = true;
                return;
            }
            
            emptyCart.style.display = 'none';
            document.getElementById('checkoutBtn').disabled = false;
            
            let html = '';
            this.cart.forEach(item => {
                html += `
                    <div class="cart-item" data-id="${item.id}">
                        <div class="cart-item-info">
                            <h6>${item.name}</h6>
                            <p class="cart-item-price">KES ${item.price.toFixed(2)}</p>
                        </div>
                        <div class="cart-item-quantity">
                            <button class="quantity-btn" onclick="POS.updateQuantity('${item.id}', -1)">
                                <i class="fas fa-minus"></i>
                            </button>
                            <span>${item.quantity}</span>
                            <button class="quantity-btn" onclick="POS.updateQuantity('${item.id}', 1)">
                                <i class="fas fa-plus"></i>
                            </button>
                        </div>
                        <div class="cart-item-total">
                            KES ${item.total.toFixed(2)}
                        </div>
                    </div>
                `;
            });
            
            cartContainer.innerHTML = html;
            this.updateTotals();
        },
        
        updateTotals: function() {
            const subtotal = this.cart.reduce((sum, item) => sum + item.total, 0);
            const vat = subtotal * 0.16;
            const total = subtotal + vat;
            
            document.getElementById('subtotal').textContent = `KES ${subtotal.toFixed(2)}`;
            document.getElementById('vat').textContent = `KES ${vat.toFixed(2)}`;
            document.getElementById('total').textContent = `KES ${total.toFixed(2)}`;
        },
        
        showToast: function(message, type = 'info') {
            const toast = document.createElement('div');
            toast.className = `toast align-items-center text-white bg-${type} border-0`;
            toast.setAttribute('role', 'alert');
            toast.setAttribute('aria-live', 'assertive');
            toast.setAttribute('aria-atomic', 'true');
            
            toast.innerHTML = `
                <div class="d-flex">
                    <div class="toast-body">${message}</div>
                    <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
                </div>
            `;
            
            const container = document.createElement('div');
            container.className = 'toast-container position-fixed bottom-0 end-0 p-3';
            container.appendChild(toast);
            document.body.appendChild(container);
            
            const bsToast = new bootstrap.Toast(toast);
            bsToast.show();
            
            toast.addEventListener('hidden.bs.toast', () => container.remove());
        },
        
        processSale: function() {
            const paymentMethod = document.querySelector('input[name="paymentMethod"]:checked').value;
            const total = this.cart.reduce((sum, item) => sum + item.total, 0) * 1.16;
            
            let paymentData = {
                method: paymentMethod,
                amount: total,
                customer: document.getElementById('customerName').value,
                items: this.cart,
                timestamp: this.currentDateTime,
                user: this.currentUser
            };
            
            switch(paymentMethod) {
                case 'cash':
                    const tendered = parseFloat(document.getElementById('amountTendered').value);
                    if (tendered < total) {
                        this.showToast('Insufficient amount tendered', 'danger');
                        return;
                    }
                    paymentData.tendered = tendered;
                    break;
                    
                case 'mpesa':
                    const phone = document.getElementById('mpesaPhone').value;
                    if (!this.validatePhone(phone)) {
                        this.showToast('Invalid phone number', 'danger');
                        return;
                    }
                    paymentData.phone = phone;
                    break;
                    
                case 'card':
                    if (!this.validateCardDetails()) {
                        this.showToast('Invalid card details', 'danger');
                        return;
                    }
                    // Add card details
                    break;
            }
            
            // Send to server
            fetch('/api/pos/process-sale', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(paymentData)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    this.completeSale(data.receipt_id);
                } else {
                    this.showToast(data.message, 'danger');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                this.showToast('An error occurred while processing the sale', 'danger');
            });
        }
    };
    
    // Initialize POS
    POS.init();
    window.POS = POS;
});